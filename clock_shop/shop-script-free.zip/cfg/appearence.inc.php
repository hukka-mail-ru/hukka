<?php
	define('CONF_PRODUCTS_PER_PAGE', '16');
	define('CONF_COLUMNS_PER_PAGE', '1');
	define('CONF_SHOW_ADD2CART', '1');
	define('CONF_SHOW_BEST_CHOICE', '1');
	define('CONF_DARK_COLOR', '4E679F');
	define('CONF_MIDDLE_COLOR', '4E679F');
	define('CONF_LIGHT_COLOR', 'B4CCF1');
?>