// -----------------------------------------------------------------------
// <copyright file="QueryResultBox.xaml.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.GUI
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Data;
    using System.Windows.Documents;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using System.Windows.Navigation;
    using System.Windows.Shapes;
    using TSI.PDM.BL;
    using TSI.PDM.DataStore;
    using TSI.PDM.GUI.Controls.Tree;

    /// <summary>
    /// A control containing a tree of objects
    /// </summary>
    public partial class QueryResultBox : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="QueryResultBox" /> class.
        /// </summary>
        public QueryResultBox()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Handle "Expand" click in context menu
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">Event Args</param>
        private void Expand_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor;

                this.Expand();

                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default;                
            }
            catch (Exception ex)
            {
                Message.Show(ex);
            }            
        }

        /// <summary>
        /// Handle "LoadStructure" click in context menu
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">Event Args</param>
        private void LoadStructure_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor;

                // expand if not yet expanded
                Item responseItem = this.Expand();
               
                // load files and show structure in NX.
                Backend.Instance.DoLoadStructure(responseItem, true);

                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default;
            }
            catch (ExceptionFileAlreadyExists)
            {
                // ARANXI-104: do nothing
            }
            catch (Exception ex)
            {
                
                Message.Show(ex);
            }
        }

        /// <summary>
        /// Handle "Load" click in context menu
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">Event Args</param>
        private void Load_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor;

                Item item = (this.MyTreeList.SelectedItem as TreeNode).Tag as Item;

                Backend.Instance.DoLoadSingleFile(item, true, true);

                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default;
            }
            catch (Exception ex)
            {
                Message.Show(ex);
            }
        }

        /// <summary>
        /// A helper for handlers
        /// </summary>
        /// <returns>an expanded item (with children)</returns>
        private Item Expand()
        {
            Item selectedItem = (this.MyTreeList.SelectedItem as TreeNode).Tag as Item;

            // EXPAND command
            Item newItem = Backend.Instance.DoExpand(selectedItem);

            // Replace the model with a new one. 
            // We need to replace the whole model (instead of replacing only one a node)
            // due to internal implementation of TreeList.
            QueryResultModel oldModel = (QueryResultModel)this.MyTreeList.Model;
            QueryResultModel newModel = new QueryResultModel();

            foreach (Item oldItem in oldModel.Root.Children)
            {
                Item item = (oldItem.item_number == newItem.item_number) ? newItem : oldItem;
                newModel.Root.Children.Add(item);
            }

            this.MyTreeList.Model = newModel;

            return newItem;
        }    
    }
}
