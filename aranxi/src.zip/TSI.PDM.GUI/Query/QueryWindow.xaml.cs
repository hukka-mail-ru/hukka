// -----------------------------------------------------------------------
// <copyright file="QueryWindow.xaml.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.GUI
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Data;
    using System.Windows.Documents;
    using System.Windows.Input;
    using System.Windows.Markup;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using System.Windows.Navigation;
    using System.Windows.Shapes;
    using System.Xml;

    using TSI.PDM.BL;
    using TSI.PDM.DataStore;
    
    /// <summary>
    /// Interaction logic for QueryWindow.xaml
    /// </summary>
    public partial class QueryWindow : Window
    {
        /// <summary>
        /// A flag indicating whether the window is open
        /// </summary>
        private bool opened = true;

        /// <summary>
        /// An array of form controls and their values
        /// </summary>
        private List<FormAttribute> formAttributes;

        /// <summary>
        /// Initializes a new instance of the <see cref="QueryWindow" /> class.
        /// </summary>
        public QueryWindow()
        {
            this.InitializeComponent();

            Common.LoadDataSourceToComboBox(Settings.Instance.ItemTypes, this.itemTypeBox);

            // background thread
            this.backgroundWorker = (BackgroundWorker)this.FindResource("backgroundWoker");
        }

        /// <summary>
        /// Gets a value indicating whether the window is open
        /// </summary>
        public bool Opened
        {
            get { return this.opened; }
        }

        /// <summary>
        /// ItemTypeBox_SelectionChanged event handler
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">Routed Event Args</param>
        private void ItemTypeBox_SelectionChanged(object sender, RoutedEventArgs e)
        {
            try
            {
                // create a new grid
                Grid grid = new Grid();
                grid.HorizontalAlignment = HorizontalAlignment.Stretch;
                grid.VerticalAlignment = VerticalAlignment.Top;

                grid.ColumnDefinitions.Add(new ColumnDefinition());
                grid.ColumnDefinitions.Add(new ColumnDefinition());

                // load Labels and ComboBoxes from Settings
                this.formAttributes =
                    Request.GetFormAttributes("Query", this.itemTypeBox.SelectedItem.ToString());
                int i = 0;
                foreach (var formAttribute in this.formAttributes)
                {
                    // a new row
                    grid.RowDefinitions.Add(new RowDefinition());

                    // Label
                    TextBlock txt = Common.CreateLabel(formAttribute, i, 0); // '0' is the left column of the grid
                    grid.Children.Add(txt);
                    
                    Control control = Common.CreateControl(formAttribute, i, 1); // '1' is the right column of the grid
                    if (control != null)
                    {
                        grid.Children.Add(control);
                        grid.Height += control.Height;
                    }

                    i++;
                }

                // add the created grid to form
                this.InputFieldsCell.Children.Clear();
                this.InputFieldsCell.Children.Add(grid);
            }
            catch (Exception ex)
            {
                Message.Show(ex);
            }
        }

        /// <summary>
        /// Query button event handler.
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">Routed Event Args</param>
        private void QueryButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // disable controls
                this.EnableControls(false);
            
                // retrieve values from controls
                Common.GetValuesOfControls(this.formAttributes);
                
                // Send 'Query' request.
                Request request = new Request();
                request.Attributes = this.formAttributes;

                Item item = request.ToItem();
                item.Class = Request.GetNameByDisplayName(Settings.Instance.ItemTypes, this.itemTypeBox.Text);

                this.backgroundWorker.RunWorkerAsync(item);
                Mouse.OverrideCursor = Cursors.Wait;
            }
            catch (Exception ex)
            {
                Message.Show(ex);
                this.EnableControls(true);
                Mouse.OverrideCursor = null;
            }
        }

        /// <summary>
        /// Enable or disable form controls
        /// </summary>
        /// <param name="enabled">true if to enable</param>
        private void EnableControls(bool enabled)
        {
            this.queryButton.IsEnabled = enabled;
            this.closeButton.IsEnabled = enabled;
            this.itemTypeBox.IsEnabled = enabled;

            foreach (FormAttribute formAttribute in this.formAttributes)
            {
                formAttribute.Control.IsEnabled = enabled;
            }
        }

        /// <summary>
        /// Background operation (Find) completed successfully
        /// </summary>
        /// </summary>
        /// <param name="responseItems">found items</param>
        private void OnSuccess(List<Item> responseItems)
        {
            try
            {
                Mouse.OverrideCursor = null;
                this.EnableControls(true);

                // prepare QueryResultModel
                QueryResultModel model = new QueryResultModel();
                foreach (Item responseItem in responseItems)
                {
                    model.Root.Children.Add(responseItem);
                }

                this.MyQueryResultBox.MyTreeList.Model = model;

                // get list of columns to output and show the gridview
                GridView gridView = new GridView();
                foreach (FormAttribute attribute in this.formAttributes)
                {
                    string columnName = attribute.Name;

                    GridViewColumn column = new GridViewColumn();
                    column.Header = columnName;
                    
                    // The expander is only in the first column  
                    if (gridView.Columns.Count == 0)
                    {
                        string cell =
                             @"<DataTemplate 
                             xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
                             xmlns:tree=""clr-namespace:TSI.PDM.GUI.Controls.Tree;assembly=TSI.PDM.GUI.Controls"">
                                <StackPanel Orientation=""Horizontal"">
                                    <tree:RowExpander/>
                                    <TextBlock Text=""{Binding " + columnName + @"}""></TextBlock>
                                </StackPanel>
                            </DataTemplate>";

                        column.CellTemplate =
                            (DataTemplate)XamlReader.Load(XmlReader.Create(new StringReader(cell)));
                    }
                    else 
                    {
                        // The other columns contain only text
                        column.DisplayMemberBinding = new Binding(columnName);
                    }

                    // DisplayName in header 
                    string header =
                                 @"<DataTemplate
                                    xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation"">
                                <TextBlock>" + attribute.DisplayName + @"</TextBlock>
                             </DataTemplate>";

                    column.HeaderTemplate =
                        (DataTemplate)XamlReader.Load(XmlReader.Create(new StringReader(header))); 
                    
                    gridView.Columns.Add(column);
                }

                this.MyQueryResultBox.MyTreeList.View = gridView;
                          
               // this.Close();
            }
            catch (Exception ex)
            {
                Message.Show(ex);
            }
        }

        /// <summary>
        ///  All operations completed with an error     
        /// </summary>
        private void OnError()
        {
            Mouse.OverrideCursor = null;
            this.EnableControls(true);
        }


        /// <summary>
        /// "Key pressed" event 
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">Event Args</param>
        private void OnKeyDownHandler(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                this.QueryButton_Click(sender, e);
            }
            else if (e.Key == Key.Escape)
            {
                this.CloseButton_Click(sender, e);
            }
        }

        /// <summary>
        /// Close button event handler.
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">Event Args</param>
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// OnClose event
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">Event Args</param>
        private void Window_Closed(object sender, EventArgs e)
        {
            this.opened = false;
        }
    }
}
