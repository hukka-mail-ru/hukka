// -----------------------------------------------------------------------
// <copyright file="QueryResultModel.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.GUI
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Linq;
    using System.Text;
    using Microsoft.Win32;
    using TSI.PDM.DataStore;
    using TSI.PDM.GUI.Controls.Tree;

    /// <summary>
    /// Represents a hirarchy of items (TreeModel)
    /// </summary>
    public class QueryResultModel : ITreeModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="QueryResultModel" /> class.
        /// </summary>
        public QueryResultModel()
        {
            this.Root = new Item();
        }

        /// <summary>
        /// Gets the root item
        /// </summary>
        public Item Root { get; private set; }

        /// <summary>
        /// Gets children of an object
        /// </summary>
        /// <param name="parent">parent object</param>
        /// <returns>an array of children</returns>
        public System.Collections.IEnumerable GetChildren(object parent)
        {
            if (parent == null)
            {
                parent = this.Root;
            }

            return (parent as Item).Children;
        }

        /// <summary>
        /// Defines if an object has children or no
        /// </summary>
        /// <param name="parent">parent object</param>
        /// <returns>true if an object has children or no</returns>
        public bool HasChildren(object parent)
        {
            return (parent as Item).Children.Count > 0;
        }
    }  
}
