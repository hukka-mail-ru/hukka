﻿// -----------------------------------------------------------------------
// <copyright file="OperationStateToBrushConverter.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.GUI
{
    using System;
    using System.Windows.Data;
    using System.Windows.Media;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Converts Item.OperationState to SolidColorBrush
    /// </summary>
    internal class OperationStateToBrushConverter : IValueConverter
    {
        /// <summary>
        /// Converts Item.OperationState to SolidColorBrush
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>A converted value. If the method returns null, the valid null value is used.</returns>
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            Item.OperationState input = (Item.OperationState)value;
            switch (input)
            {
                case Item.OperationState.Skip:
                    return new SolidColorBrush(Color.FromRgb(170, 170, 170)); // light grey
                case Item.OperationState.Create:
                    return Brushes.DarkMagenta;                    
                case Item.OperationState.Update:
                    return new SolidColorBrush(Color.FromRgb(5, 109, 190)); // light blue
                case Item.OperationState.Cancelled:
                    return Brushes.Blue;
                case Item.OperationState.Error:
                    return Brushes.Red;
                case Item.OperationState.Completed:
                    return Brushes.Black;
                default:
                    return null;
            }
        }

        /// <summary>
        /// SolidColorBrush to Item.OperationState
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>A converted value. If the method returns null, the valid null value is used.</returns>
        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}