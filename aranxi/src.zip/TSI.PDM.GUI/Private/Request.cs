// -----------------------------------------------------------------------
// <copyright file="Request.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.GUI
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Xml.Linq;
    using TSI.PDM.DataStore;

    /// <summary>
    /// This class contains attributes of a form
    /// and some static methods to convert displayNames of form controls to Names
    /// </summary>
    internal partial class Request 
    {
        /// <summary>
        /// Gets or sets request attributes
        /// </summary>
        public List<FormAttribute> Attributes { get; set; }

        /// <summary>
        /// Read all the Attributes of a form from XML file by their display names
        /// </summary>
        /// <param name="formName">name of the UI form</param>
        /// <param name="displayName">display name of an attribute</param>
        /// <returns>a list of Attributes</returns>
        public static List<FormAttribute> GetFormAttributes(string formName, string displayName)
        {
            XElement root = XElement.Load(Settings.Instance.SettingsXml);

            // get <object name="Drawing"> or  <object name="Model">...
            XElement obj = (from el in root.Descendants("object")
                            where (string)el.Attribute("displayName") == displayName
                            select el).First();

            // <form name="Query"> or <form name="Register">...
            XElement form = (from el in obj.Descendants("form")
                             where (string)el.Attribute("name") == formName
                             select el).First();

            // get <formAttribute name>
            IEnumerable<XElement> formAttributes =
                from el in form.Descendants("formAttribute")
                select el;

            // add attributes
            List<FormAttribute> res = new List<FormAttribute>();
            foreach (XElement el in formAttributes)
            {
                FormAttribute formAttribute = new FormAttribute();

                formAttribute.Name = (string)el.Attribute("name");
                formAttribute.DisplayName = (string)el.Attribute("displayName");
                formAttribute.ListViewRelevant = (string)el.Attribute("listViewRelevant");
                formAttribute.WidgetType = (string)el.Attribute("widgetType");

                res.Add(formAttribute);
            }

            return res;
        }

        /// <summary>
        /// Get template names by display name
        /// </summary>    
        /// <param name="displayName">display name of an attribute</param>
        /// <returns>
        /// List of template names
        /// </returns> 
        public static List<string> GetTemplateNames(string displayName)
        {
            // e.g. <object displayName="NLS_CATPart">
            //         <form name="Create">
            //               <formAttribute name="CatPrtTemplate">    
            List<string> res = new List<string>();

            try
            {
                XElement root = XElement.Load(Settings.Instance.SettingsXml);

                // get the <object displayName="Model">
                XElement obj = (from el in root.Descendants("object")
                                where (string)el.Attribute("displayName") == displayName
                                select el).First();

                // get the <form name="Create">
                XElement form = (from el in obj.Descendants("form")
                                 where (string)el.Attribute("name") == "Create"
                                 select el).First();

                // get all formAttribute
                IEnumerable<XElement> formAttrs =
                    from el in form.Descendants("formAttribute")
                    select el;

                // add all the formAttribute where name="*Template*"                
                foreach (XElement formAttr in formAttrs)
                {
                    string str = (string)formAttr.Attribute("name");
                    if (str.Contains("Template") || str.Contains("template"))
                    {
                        res.Add(str);
                    }
                }
            }
            catch (Exception)
            {
                // formAttribute list is optional, so
                // nothing to do - just return an empty list.
            }

            return res;
        }

        /// <summary>
        /// Get name of one an Entry of DataSource by its display name
        /// e.g. <value name="Part" displayName="NLS_Part" />
        /// </summary>
        /// <param name="dataSource">the DataSource</param>
        /// <param name="displayName">display name of the DataSourceEntry</param>
        /// <returns>
        /// a name of the DataSource entry
        /// </returns>
        public static string GetNameByDisplayName(DataSource dataSource, string displayName)
        {
            foreach (DataSourceEntry i in dataSource.Entries)
            {
                if (i.DisplayName == displayName)
                {
                    return i.Name;
                }
            }

            return string.Empty;
        }

        /// <summary>
        /// Gets DataSource by name of form attribute name. 
        /// Gets DataSource with an empty set of Entries, if the DataSource is not defined in Settings.xml
        /// </summary>
        /// <param name="formAttributeName">DataSource name</param>
        /// <returns>
        /// a DataSource object
        /// </returns>
        public static DataSource GetDataSource(string formAttributeName)
        {
            DataSource dataSource = new DataSource();

            XElement root = XElement.Load(Settings.Instance.SettingsXml);

            // get <attribute name="unit" displayName="NLS_unit" dataSource="Unit" />
            XElement attr = (from el in root.Descendants("attribute")
                             where (string)el.Attribute("name") == formAttributeName
                             select el).First();

            string dataSourceName = (string)attr.Attribute("dataSource");

            // retrun empty DataSource of not found
            if (dataSourceName == null)
            {
                return dataSource;
            }

            // get the <dataSource name="dataSourceName">
            XElement ds = (from el in root.Descendants("dataSource")
                           where (string)el.Attribute("name") == dataSourceName
                           select el).First();

            // get all dataSourceEntries
            IEnumerable<XElement> entList =
                from el in ds.Descendants("value")
                select el;

            foreach (XElement el in entList)
            {
                DataSourceEntry entry = new DataSourceEntry();
                entry.Name = (string)el.Attribute("name");
                entry.DisplayName = (string)el.Attribute("displayName");
                entry.BooleanValue = (string)el.Attribute("booleanValue");

                dataSource.Entries.Add(entry);
            }

            return dataSource;
        }
    }
}
