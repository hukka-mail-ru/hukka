// -----------------------------------------------------------------------
// <copyright file="FormAttribute.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.GUI
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Windows.Controls;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Form attiribute (a control with a name and value)
    /// </summary>
    public class FormAttribute
    {
        /// <summary>
        /// Gets or sets attribute from settings.xml
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets attribute from settings.xml
        /// </summary>
        public string DisplayName { get; set; }

        /// <summary>
        /// Gets or sets attribute from settings.xml
        /// </summary>
        public string WidgetType { get; set; }

        /// <summary>
        /// Gets or sets attribute from settings.xml
        /// </summary>
        public string ListViewRelevant { get; set; }

        /// <summary>
        /// Gets or sets attribute from settings.xml
        /// </summary>
        public DataSource DataSource { get; set; }

        /// <summary>
        /// Gets or sets the UI control associated with this RequestAttribute
        /// </summary>
        public Control Control { get; set; }

        /// <summary>
        /// Gets or sets the value (which user inputs in UI)
        /// </summary>
        public string Value { get; set; }
    }
}
