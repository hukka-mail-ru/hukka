// -----------------------------------------------------------------------
// <copyright file="Common.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.GUI
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using System.Windows;
    using System.Windows.Controls;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Common methods of the UI
    /// </summary>
    internal class Common
    {
        /// <summary>
        /// A default height for a row
        /// </summary>
        private static int rowHeight = 24;

        /// <summary>
        ///  A  helper which loads DataSource items to ComboBox
        /// </summary>
        /// <param name="dataSource">dataSource object</param>
        /// <param name="comboBox">comboBox control</param>
        public static void LoadDataSourceToComboBox(DataSource dataSource, ComboBox comboBox)
        {
            foreach (DataSourceEntry entry in dataSource.Entries)
            {
                string name = (entry.DisplayName != string.Empty) ? entry.DisplayName : entry.Name;
                comboBox.Items.Add(name);

                Message.Log("name: " + name);
            }

            if (comboBox.Items.Count > 0)
            {
                comboBox.SelectedItem = comboBox.Items[0];
            }
        }

        /// <summary>
        /// Retrieves values from FormAttribute.Control 
        /// and saves them into FormAttribute.Value
        /// </summary>
        /// <param name="formAttributes">the controls</param>
        public static void GetValuesOfControls(List<FormAttribute> formAttributes)
        {
            foreach (FormAttribute attribute in formAttributes)
            {
                if (attribute.WidgetType == "ComboBox")
                {
                    ComboBox box = (ComboBox)attribute.Control;
                    attribute.Value = Request.GetNameByDisplayName(
                                            attribute.DataSource, box.SelectedItem.ToString());
                }
                else if (attribute.WidgetType == "SingleLineEditor" ||
                         attribute.WidgetType == "MultiLineEditor")
                {
                    TextBox box = (TextBox)attribute.Control;
                    attribute.Value = box.Text;
                }
            }

            foreach (FormAttribute attribute in formAttributes)
            {
                Message.Log("attribute Name: " + attribute.Name +
                         " Val : " + attribute.Value);
            }
        }

        /// <summary>
        /// creates a Label (TextBlock) in the given cell of a Grid
        /// </summary>
        /// <param name="formAttribute">the control data</param>
        /// <param name="row">row of the cell</param>
        /// <param name="column">column of the cell</param>
        /// <returns>the control</returns>
        public static TextBlock CreateLabel(FormAttribute formAttribute, int row, int column)
        {
            TextBlock txt = new TextBlock();
            txt.Text = (formAttribute.DisplayName != null) ?
                formAttribute.DisplayName : formAttribute.Name;
            txt.Height = rowHeight;
            txt.Margin = new Thickness(6, 6, 0, -12);
            txt.VerticalAlignment = VerticalAlignment.Top;

            Grid.SetRow(txt, row);
            Grid.SetColumn(txt, column); // '0' is the left column of the grid

            return txt;
        }

        /// <summary>
        /// creates a Control in the given cell of a Grid
        /// </summary>
        /// <param name="formAttribute">the control data</param>
        /// <param name="row">row of the cell</param>
        /// <param name="column">column of the cell</param>
        /// <returns>the control</returns>
        public static Control CreateControl(FormAttribute formAttribute, int row, int column)
        {
            Control control = null;
            
            if (formAttribute.WidgetType == "ComboBox")
            {
                control = new ComboBox();
                control.Height = rowHeight;

                // fill the combo box with a corresponding DataSource 
                formAttribute.DataSource = Request.GetDataSource(formAttribute.Name);
                Common.LoadDataSourceToComboBox(formAttribute.DataSource, (ComboBox)control);
            }
            else if (formAttribute.WidgetType == "SingleLineEditor")
            {
                control = new TextBox();
                control.Height = rowHeight;
            }
            else if (formAttribute.WidgetType == "MultiLineEditor")
            {
                TextBox tb = new TextBox();
                tb.TextWrapping = TextWrapping.Wrap;
                tb.AcceptsReturn = true;

                control = tb;                
                control.Height = rowHeight * 3; // MultiLineEditor is 3 times wider then a "normal" box
            }

            if (control != null)
            {
                control.Margin = new Thickness(3, 3, 3, 3);
                formAttribute.Control = control; // memorize the reference to control

                Grid.SetRow(control, row);
                Grid.SetColumn(control, column);
            }

            return control;
        }
    }
}
