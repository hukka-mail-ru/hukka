// -----------------------------------------------------------------------
// <copyright file="AboutWindow.xaml.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.GUI
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Data;
    using System.Windows.Documents;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using System.Windows.Navigation;
    using System.Windows.Shapes;

    /// <summary>
    /// Interaction logic for AboutWindow.xaml
    /// </summary>
    public partial class AboutWindow : Window
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AboutWindow" /> class.
        /// </summary>
        public AboutWindow()
        {
            // Calling default implementation of parent.
            this.InitializeComponent();
            
            // Retrieve Global AssemblyInfo
            RetrieveAssemblyInfo info = new RetrieveAssemblyInfo(this.GetType());
            this.lblVersion.Content = "Aras-NX-Integration Version: " + info.AssemblyVersion;
            this.lblCopyright.Content = info.Copyright + " " + info.Company;
        }

        /// <summary>
        /// Called when the close-button is clicked.
        /// </summary>
        /// <param name="sender">The close-button</param>
        /// <param name="e">The eventargs</param>
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
