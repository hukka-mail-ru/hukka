// -----------------------------------------------------------------------
// <copyright file="RetrieveAssemblyInfo.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.GUI
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Linq;
    using System.Reflection;
    using System.Text;

    public class RetrieveAssemblyInfo
    {
        // Assembly of given type.
        private static Assembly assembly;

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="type">Type</param>
        public RetrieveAssemblyInfo(Type type)
        {
            assembly = Assembly.GetAssembly(type);
        }

        /// <summary>
        /// Title property.
        /// </summary>
        public string Title
        {
            get
            {
                return this.CustomAttributes<AssemblyTitleAttribute>().Title;
            }
        }

        /// <summary>
        /// Description property.
        /// </summary>
        public string Description
        {
            get
            {
                return this.CustomAttributes<AssemblyDescriptionAttribute>().Description;
            }
        }

        /// <summary>
        /// Company property.
        /// </summary>
        public string Company
        {
            get
            {
                return this.CustomAttributes<AssemblyCompanyAttribute>().Company;
            }
        }

        /// <summary>
        /// Product property.
        /// </summary>
        public string Product
        {
            get
            {
                return this.CustomAttributes<AssemblyProductAttribute>().Product;
            }
        }

        /// <summary>
        /// Copyright property.
        /// </summary>
        public string Copyright
        {
            get
            {
                return this.CustomAttributes<AssemblyCopyrightAttribute>().Copyright;
            }
        }

        /// <summary>
        /// Trademark property.
        /// </summary>
        public string Trademark
        {
            get
            {
                return this.CustomAttributes<AssemblyTrademarkAttribute>().Trademark;
            }
        }

        /// <summary>
        /// AssemblyVersion property.
        /// </summary>
        public string AssemblyVersion
        {
            get
            {
                return assembly.GetName().Version.ToString();
            }
        }

        /// <summary>
        /// FileVersion property.
        /// </summary>
        public string FileVersion
        {
            get
            {
                FileVersionInfo fileInfo = FileVersionInfo.GetVersionInfo(assembly.Location);
                return fileInfo.FileVersion;
            }
        }

        /// <summary>
        /// Returns custom attributes from AssemblyInfo.
        /// </summary>
        /// <typeparam name="T">Type</typeparam>
        /// <returns>Custom attributes</returns>
        private T CustomAttributes<T>() where T : Attribute
        {
            object[] customAttributes = assembly.GetCustomAttributes(typeof(T), false);

            if ((customAttributes != null) && (customAttributes.Length > 0))
            {
                return (T)customAttributes[0];
            }

            throw new InvalidOperationException();
        }
    }
}
