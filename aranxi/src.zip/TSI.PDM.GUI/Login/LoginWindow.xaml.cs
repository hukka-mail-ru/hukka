// -----------------------------------------------------------------------
// <copyright file="LoginWindow.xaml.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.GUI
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Linq;
    using System.Text;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Data;
    using System.Windows.Documents;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using System.Windows.Navigation;
    using System.Windows.Shapes;

    using TSI.PDM.BL;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LoginWindow" /> class.
        /// </summary>
        public LoginWindow()
        {
            this.InitializeComponent();
            Common.LoadDataSourceToComboBox(Settings.Instance.Databases, this.DBList);

#if DEBUG_WITH_CHEAT
            this.login_TextBox.Text = "admin";
            this.password_TextBox.Password = "innovator";
#endif

            this.URL_Hyperlink.Text = Settings.Instance.Server;

            // background thread
            this.backgroundWorker = (BackgroundWorker)this.FindResource("backgroundWoker");
        }

        /// <summary>
        /// Perform login to server
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">Event Args</param>
        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                
                
                this.okButton.IsEnabled = false;
                this.cancelButton.IsEnabled = false;
                this.login_TextBox.IsEnabled = false;
                this.password_TextBox.IsEnabled = false;
                this.DBList.IsEnabled = false;

                Credentials cred = new Credentials(
                    this.login_TextBox.Text,
                    this.password_TextBox.Password,
                    this.DBList.SelectedItem.ToString());

                this.backgroundWorker.RunWorkerAsync(cred);
                Mouse.OverrideCursor = Cursors.Wait;
            }
            catch (Exception ex)
            {
                Message.Show(ex);
                this.Close();
                Mouse.OverrideCursor = null;
            }
        }

        /// <summary>
        ///  All operations completed successfully
        /// </summary>
        private void OnSuccess()
        {
            this.Close();
            Mouse.OverrideCursor = null;
        }

        /// <summary>
        ///  All operations completed with an error     
        /// </summary>
        private void OnError()
        {
            Mouse.OverrideCursor = null;

            this.okButton.IsEnabled = true;
            this.cancelButton.IsEnabled = true;
            this.login_TextBox.IsEnabled = true;
            this.password_TextBox.IsEnabled = true;
            this.DBList.IsEnabled = true;
        }

        /// <summary>
        /// Cancel button event handler.
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">Event Args</param>
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// "Key pressed" event 
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">Event Args</param>
        private void OnKeyDownHandler(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                this.OKButton_Click(sender, e);
            }
            else if (e.Key == Key.Escape)
            {
                this.CancelButton_Click(sender, e);
            }
        }
       
        /// <summary>
        /// Enable OK button if all the required fields are filled
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">Event Args</param>
        private void OnTextChanged(object sender, RoutedEventArgs e)
        {
            this.okButton.IsEnabled =
                this.login_TextBox.Text.Trim().Length > 0 &&
                this.password_TextBox.Password.Trim().Length > 0;
        }

        /// <summary>
        /// Hyperlink_RequestNavigate handler
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">Event Args</param>
        private void Hyperlink_RequestNavigate(object sender, RequestNavigateEventArgs e)
        {
            Process.Start(new ProcessStartInfo(Settings.Instance.Server));
            e.Handled = true;
        }
    }
}
