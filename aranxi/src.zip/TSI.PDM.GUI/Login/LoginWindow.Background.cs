﻿// -----------------------------------------------------------------------
// <copyright file="LoginWindow.Background.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.GUI
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Text;
    using System.Windows.Input;
    using TSI.PDM.BL;
    using TSI.PDM.DataStore;

    /// <summary>
    /// LoginWindow Background thread
    /// </summary>
    public partial class LoginWindow
    {
        /// <summary>
        /// The thread for BackEnd operatios
        /// </summary>
        private BackgroundWorker backgroundWorker;
 
        /// <summary>
        /// A handler to backgroundWorker.RunWorkerAsync
        /// </summary>
        /// <param name="sender">not used</param>
        /// <param name="e">arguments </param>
        private void BackgroundWorker_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            Credentials cred = (Credentials)e.Argument;

            BackgroundWorker worker = sender as BackgroundWorker;

            // exceptions are catched by BackgroundWorker_RunWorkerCompleted
            Backend.Instance.DoLogin(cred);
        }

        /// <summary>
        /// A hander to the end of the BackgroundWorker work
        /// </summary>
        /// <param name="sender">not used</param>
        /// <param name="e">a status</param>
        private void BackgroundWorker_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            Mouse.OverrideCursor = null;

            if (e.Cancelled == true)
            {
                Message.Show("Operation cancelled by user");
                this.OnError();
            }
            else if (!(e.Error == null))
            {
                Message.Show(e.Error);
                this.OnError();
            }
            else
            {
                this.OnSuccess();
            }
        }
    }
}