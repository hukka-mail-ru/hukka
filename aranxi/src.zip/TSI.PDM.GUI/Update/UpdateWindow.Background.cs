// -----------------------------------------------------------------------
// <copyright file="UpdateWindow.Background.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.GUI
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Text;
    using TSI.PDM.BL;
    using TSI.PDM.DataStore;

    /// <summary>
    /// UpdateWindow Background thread
    /// </summary>
    public partial class UpdateWindow 
    {
        /// <summary>
        /// The thread for BackEnd operatios
        /// </summary>
        private BackgroundWorker backgroundWorker;
        
        /// <summary>
        /// A handler to event backgroundWorker.ReportProgress
        /// Accepts an Item as its argument
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">an Item</param>
        private void BackgroundWorker_ProgressChanged(object sender, System.ComponentModel.ProgressChangedEventArgs e)
        {
            Item item = (Item)e.UserState;

            string message = item.ItemOperationState + ": " + item.item_number  + " ...OK!";
            Message.Log(message);

            this.logsToShow.Add(item);

            // update log
            this.LogListView.Items.Refresh();
            this.LogListView.ScrollIntoView(item);

            // update progress Bar
            this.operationsDone++;
            this.MyProgressBar.Value = (this.operationsDone * 100) / this.operationsToDo;

            // update item view
            foreach (Item itemToShow in this.itemsToShow)
            {
                if (itemToShow.item_number == item.item_number)
                {
                    this.MyListView.Items.Refresh();
                    break;
                }
            }
        }

        /// <summary>
        /// A handler to backgroundWorker.RunWorkerAsync
        /// </summary>
        /// <param name="sender">not used</param>
        /// <param name="e">not used also</param>
        private void BackgroundWorker_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            BackgroundWorker worker = sender as BackgroundWorker;

            // exceptions are catched by BackgroundWorker_RunWorkerCompleted
            Backend.Instance.DoUpdateItem(this.stuctureToUpdate);
        }

        /// <summary>
        /// A hander to the end of the BackgroundWorker work
        /// </summary>
        /// <param name="sender">not used</param>
        /// <param name="e">a status</param>
        private void BackgroundWorker_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            // a fake item - just to show the log
            Item item = new Item();

            if (e.Cancelled == true)
            {
                item.ItemOperationState = Item.OperationState.Cancelled;
            }
            else if (!(e.Error == null))
            {
                item.ItemOperationState = Item.OperationState.Error;
                item.item_number = e.Error.Message;                
            }
            else
            {
                item.ItemOperationState = Item.OperationState.Completed;
            }

            this.logsToShow.Add(item);
            this.LogListView.Items.Refresh();
            this.LogListView.ScrollIntoView(item);

            if (!(e.Error == null))
            {
                Message.Show(e.Error);
            }

            // return to the main thread
            this.UpdateCompleted();
        }
    }
}