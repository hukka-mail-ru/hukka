// <copyright company="T-Systems International GmbH">
//    Copyright � T-Systems 2012
// </copyright>

#include "TSI.PDM.MnWrapper.h"
#include "licman.h"

#include <iostream>
#include <string.h>

using namespace System::Runtime::InteropServices;
using namespace TSIPDMMnWrapper;

//-----------------------------------------------------------------------------
// Wrapper function for licman licenseInit. Initialize License Management
// Interface. For details look licman.h
//-----------------------------------------------------------------------------
int Class1::licenseInit_w()
{
    return licenseInit();
}

//-----------------------------------------------------------------------------
// Wrapper function for licman licenseAlloc. Send license allocation request to
// LLD. For details look licman.h
//-----------------------------------------------------------------------------
int Class1::licenseAlloc_w(int key)
{
    return licenseAlloc(key);
}

//-----------------------------------------------------------------------------
// Wrapper function for licman licenseFree. Send license free request to LLD.
// For details look licman.h
//-----------------------------------------------------------------------------
void Class1::licenseFree_w(int key)
{
    licenseFree(key);
}

//-----------------------------------------------------------------------------
// Wrapper function for licman licenseError. Print error message.
// For details look licman.h
//-----------------------------------------------------------------------------
void Class1::licenseError_w(int irc)
{
    licenseError(irc);
}

//-----------------------------------------------------------------------------
// Wrapper function for licman licenseSetVendorKey. Set license vendor key.
// For details look licman.h
//-----------------------------------------------------------------------------
void Class1::licenseSetVendorKey_w(System::String^ vendor)
{
    IntPtr p = Marshal::StringToHGlobalAnsi(vendor);
    char* cVendor = static_cast<char*>(p.ToPointer());
    licenseSetVendorKey(cVendor);
    Marshal::FreeHGlobal(p);
}

//=============================================================================
// Licence allocation verification procedure. For details look licman.h
//=============================================================================
//-----------------------------------------------------------------------------
//                                                                    
// Validate license version                                           
//                                                                    
//  In:     Key      ... License Key (1003)							  
//          Serial   ... Serial Number (not used)					      
//          data     ... version string in license file                
//                                                                     
//  RETURN: 0        ... license OK                                    
//          1        ... license not OK                                
//                                                                     
//-----------------------------------------------------------------------------
//                                                                    
//  Format of version string "data" and "version":                    
//     <Version>[.<SubVersion>[.<SubSubVersion>[...]]]                
//                                                                    
//  Format of "Version", "SubVersion", ...:                           
//     <[e]<int> | n>                                                 
//     where:                                                        
//        <int>   ... [Sub]Version number                             
//        e<int>  ... exaxt [Sub]Version number                       
//        n       ... any [Sub]Version number (only used in "data")   
//                                                                    
//  Samples:                                                          
//  1) data    = "5.n"                                                
//     version = "5.3"                                                
//     ==> license OK                                                 
//  2) data    = "5.4"                                                
//     version = "5.3"                                                
//     ==> license OK                                                 
//  3) data    = "5.n"                                                
//     version = "e5.3"                                               
//     ==> license OK                                                 
//  4) data    = "5.n"                                                
//     version = "e5.e3"                                              
//     ==> license Not OK                                             
//  5) data    = "5.3"                                                
//     version = "e5.e3"                                              
//     ==> license OK                                                 
//  6) data    = "e5.e3"                                              
//     version = "e5.3"                                               
//     ==> license OK                                                 
//  7) data    = "e6.n"                                               
//     version = "5.3"                                                
//     ==> license Not OK                                             
//  8) data    = "e6.n"                                               
//     version = "e6.5.5"                                             
//     ==> license OK                                                 
//  9) data    = "6.5"                                                
//     version = "6.5.0"                                              
//     ==> license Not OK                                             
//                                                                    
//-----------------------------------------------------------------------------
int ValidateLicenseVersion_t (int key, char* serial, char* data)
{
#define NXLICVERSION "10n"
    char  *sLicenseVersion = NULL;
    char  sTokenLicVer[256];
    char  sTokenAppVer[256];
    int   iLicVer          = 0;
    int   iAppVer          = 0;
    int   iExactLicVer     = 0;       /* 0..not exact, 1..exact, -1..any */
    int   iExactAppVer     = 0;       /* 0..not exact, 1..exact */
    int   iLicOK           = 0;
    size_t i               = 0;
    size_t iLicVerStart    = 0;
    size_t iAppVerStart    = 0;
    int   iAppVersion      = 0;
    float fAppVersion      = 0.0;
    const int icBufSize    = 32;
    char  sAppVersion[icBufSize];

    memset(sAppVersion,0,icBufSize * sizeof(char));
    if (NXLICVERSION)
    {
        iAppVersion = atoi(NXLICVERSION);
        fAppVersion = ((float) iAppVersion) / 10;
    }
    _snprintf(sAppVersion,icBufSize * sizeof(char), "%6.1f", fAppVersion);

    if (data)
    {
        sLicenseVersion = strdup(data);
    }
    else
    {
        sLicenseVersion = strdup("n");
    }

    std::cout << "Checking license -> key: " << key << ", version: " << data << std::endl;
    std::cout << "Try to allocate license for NX Version: " << sAppVersion << std::endl;

    memset(sTokenLicVer,0,sizeof(sTokenLicVer));
    for (i=0 ; i<strlen(sLicenseVersion);i++)
    {
        if (sLicenseVersion[i] == '.')
        {
            memcpy(sTokenLicVer, sLicenseVersion, i);
            iLicVerStart = i+1;
            break;
        }
    }
    if ((i != iLicVerStart) && (i==strlen(sLicenseVersion)))
    {
        memcpy(sTokenLicVer, sLicenseVersion, i);
        iLicVerStart = i+1;
    }

    memset(sTokenAppVer,0,sizeof(sTokenAppVer));
    for (i=0 ; i<strlen(sAppVersion);i++)
    {
        if (sAppVersion[i] == '.')
        {
            memcpy(sTokenAppVer, sAppVersion, i);
            iAppVerStart = i+1;
            break;
        }
    }
    if ((i != iAppVerStart) && (i==strlen(sAppVersion)))
    {
        memcpy(sTokenAppVer, sAppVersion, i);
        iAppVerStart = i+1;
    }

    while((strlen(sTokenLicVer) != 0) && (strlen(sTokenAppVer) != 0))
    {
        iLicVer      = 0;
        iAppVer      = 0;
        iExactLicVer = 0;
        iExactAppVer = 0;
        if (sTokenLicVer[0] == 'e') 
        {
            iExactLicVer = 1;
            sTokenLicVer[0] = '0';
        }
        if (sTokenLicVer[0] == 'n')
        {
            iExactLicVer = -1;
        }
        else
        {
            iLicVer = atoi(sTokenLicVer);
        }

        if (sTokenAppVer[0] == 'e') 
        {
            iExactAppVer = 1;
            sTokenAppVer[0] = '0';
        }
        iAppVer = atoi(sTokenAppVer);

        if ((iExactLicVer == 1) || (iExactAppVer))
        {
            if (iLicVer == iAppVer)
            {
                iLicOK = 1;
            } 
            else 
            {
                iLicOK = 0;
                break;
            }
        }
        if ((iLicVer > iAppVer) || (iExactLicVer == -1))
        {
            iLicOK = 1;
            break;
        } 
        else if (iLicVer < iAppVer)
        {
            iLicOK = 0;
            break;
        } 
        else 
        {
            iLicOK = 1;
        }

        sTokenLicVer[0] = 0;
        for (i=iLicVerStart ; i<strlen(sLicenseVersion);i++)
        {
            if (sLicenseVersion[i] == '.')
            {
                memcpy(sTokenLicVer, (char*)sLicenseVersion+iLicVerStart, i-iLicVerStart);
                sTokenLicVer[i  - iLicVerStart] = 0;
                iLicVerStart = i+1;
                break;
            }
        }
        if ((i != iLicVerStart) && (i==strlen(sLicenseVersion)))
        {
            memcpy(sTokenLicVer,(char*) sLicenseVersion+iLicVerStart, strlen(sLicenseVersion)-iLicVerStart);
            sTokenLicVer[i  - iLicVerStart] = 0;
            iLicVerStart=i+1;
        }

        sTokenAppVer[0] = 0;
        for (i=iAppVerStart ; i<strlen(sAppVersion);i++)
        {
            if (sAppVersion[i] == '.')
            {
                memcpy(sTokenAppVer, (char*)sAppVersion+iAppVerStart, i-iAppVerStart);
                sTokenAppVer[i  - iAppVerStart] = 0;
                iAppVerStart = i+1;
                break;
            }
        }
        if ((i != iAppVerStart) && (i==strlen(sAppVersion)))
        {
            memcpy(sTokenAppVer,(char*) sAppVersion+iAppVerStart, strlen(sAppVersion)-iAppVerStart);
            sTokenAppVer[i - iAppVerStart] = 0;
            iAppVerStart=i+1;
        }

        if ((strlen(sTokenAppVer) != 0) && (strlen(sTokenLicVer) == 0))
        {
            iLicOK = 0;
        }
        if ((strlen(sTokenAppVer) == 0) && (strlen(sTokenLicVer) != 0))
        {
            if (sTokenLicVer[0] == 'e')
            {
                iLicOK = 0;
            }
        }
    }
    if (iLicOK == 0)
    {
        std::cout << "Failed to allocate license for NX Version" << std::endl;
    }

    free(sLicenseVersion);

    return (iLicOK != 1);
}

//-----------------------------------------------------------------------------
// Wrapper function for licman licenseSetVerifyProc. Set licence allocation
// verification procedure. For details look licman.h
//-----------------------------------------------------------------------------
void Class1::licenseSetVerifyProc_w()
{
    licenseSetVerifyProc(ValidateLicenseVersion_t);
}