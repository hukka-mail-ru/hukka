// <copyright company="T-Systems International GmbH">
//    Copyright � T-Systems 2012
// </copyright>

#pragma once

using namespace System;

namespace TSIPDMMnWrapper {

    public ref class Class1
    {
    public:
		//---------------------------------------------------------------------
		// Wrapper functions for licman.
		//---------------------------------------------------------------------
        int licenseInit_w(void);
        int licenseAlloc_w(int key);
        void licenseFree_w(int key);
        void licenseError_w(int irc);
        void licenseSetVendorKey_w(System::String^ vendor);
        void licenseSetVerifyProc_w();
    };
}
