/* ----------------------------------------------------------------------------
** LICMAN license manager API functions
** ----------------------------------------------------------------------------
*/

#ifndef LICMAN_API_H
#define LICMAN_API_H

#ifdef  __cplusplus
extern "C" {
#endif

/* =======================================================================

Function:	Initialize License Management Interface

Parameter:      -
Return code:	(int)		...  0 Initialization successful
				... -1 Initialization not successful

======================================================================= */

int licenseInit (void);

/* =======================================================================

Function:	Send license allocation request to LLD

Parameter:	(int) key	License key
Return code:	(int)		LLD response to allocation request
				... 0 License allocation successful
				... 1 No more license for this key
				... 2 License expired for this key
				... 3 No license found for this key
				... 4 Inconsistent GLD/LLD times
				... 5 LLD communication error
				... 6 GLD communication error

======================================================================= */

int licenseAlloc (int key);

/* =======================================================================

Function:	Send license free request to LLD

Parameter:	(int) key	License key
Return code:	-

======================================================================= */

void licenseFree (int key);

/* =======================================================================

Function:	Print error message to "stderr"

Parameter:	(int) irc	 != 0 ... License allocation error
Return code:     -

======================================================================= */

void licenseError (int irc);

/* =======================================================================

Function:	Get information of all allocated
		- nodelock license entries on this LLD client
		- floating license entries on all available GLD servers

Parameter:	(int*) key		License key
		(int*) uid		Numerical user id
		(int*) pid		Numerical process id
		(int*) seq		Sequence no. of redundant license
		(int*) time		License allocation time in sec
		(unsigned int*) client	IP address of LLD client
		(unsigned int*) server	IP address of GLD server
		(char**) user		User name
		(char**) serial         Serial number of the used license

Return code:	(int)			= 0 ... License entry returned
					= 1 ... No more license entries

======================================================================= */

int licenseQuery (int* key,int* uid, int* pid,int* seq,
		  int* time, unsigned int* client, unsigned int* server, 
		  char** user, char** serial);

/* =======================================================================

Function:	Get information of licensed products
                - nodelock products on this LLD client
                - floating products on all available GLD servers

Parameter:	(int*) type             = 0 ... nodlocked license
                                        = 1 ... floating license
                (int*) key              License key
		(unsigned int*) count   Number of licenses
		(int*) starts           License start date   
		(int*) expires          License expiration date
		(char**) serial         Serial number
                (char**) data           Additional Version information
		(char**) comment        Comment
		(unsigned int*) used    Number of used licenses
		(char**) server         Server name
		(char**) address        Server IP address

Return code:	(int)			= 0 ... Product entry returned
					= 1 ... No more product entries

======================================================================= */

int licenseQueryProducts(int* type, int* key, unsigned int* count, 
			 int* starts, int* expires, char** serial, 
			 char** data, char** comment, unsigned int* used, 
			 char** server, char** address);

/* =======================================================================

Function:       Set licence allocation verification procedure

Parameters:     int (*proc)     ... Procedure pointer
Return value:   -

Note:           The licence allocation verification procedure has
                to be declared as follows:

                int (*proc) (int key,char* serial,char* data)

                key     ... License key
                serial  ... Serial data string
                data    ... License data string

                return code 0 ... Proposed license is to be accepted
                return code 1 ... Proposed license is to be refused

======================================================================= */

void licenseSetVerifyProc (int (*proc)(int,char*,char*));

/* =======================================================================

Function:       Set license vendor key

Parameters:     char* vendor	... Vendor key
Return value:   -

======================================================================= */

void licenseSetVendorKey (char* vendor);

/**********************************************************************
 *                                                                    *
 * Validate license version                                           *
 *                                                                    *
 *  In:     data     ... version string in license file               *
 *          version  ... version string of application                *
 *                                                                    *
 *  RETURN: 0        ... license OK                                   *
 *          1        ... license not OK                               *
 *                                                                    *
 *--------------------------------------------------------------------*
 *                                                                    *
 *  Format of version string "data" and "version":                    *
 *     <Version>[.<SubVersion>[.<SubSubVersion>[...]]]                *
 *                                                                    *
 *  Format of "Version", "SubVersion", ...:                           *
 *     <[e]<int> | n>                                                 *
 *     where:                                                         *
 *        <int>   ... [Sub]Version number                             *
 *        e<int>  ... exaxt [Sub]Version number                       *
 *        n       ... any [Sub]Version number (only used in "data")   *
 *                                                                    *
 *  Samples:                                                          *
 *  1) data    = "5.n"                                                *
 *     version = "5.3"                                                *
 *     ==> license OK                                                 *
 *  2) data    = "5.4"                                                *
 *     version = "5.3"                                                *
 *     ==> license OK                                                 *
 *  3) data    = "5.n"                                                *
 *     version = "e5.3"                                               *
 *     ==> license OK                                                 *
 *  4) data    = "5.n"                                                *
 *     version = "e5.e3"                                              *
 *     ==> license Not OK                                             *
 *  5) data    = "5.3"                                                *
 *     version = "e5.e3"                                              *
 *     ==> license OK                                                 *
 *  6) data    = "e5.e3"                                              *
 *     version = "e5.3"                                               *
 *     ==> license OK                                                 *
 *  7) data    = "e6.n"                                               *
 *     version = "5.3"                                                *
 *     ==> license Not OK                                             *
 *  8) data    = "e6.n"                                               *
 *     version = "e6.5.5"                                             *
 *     ==> license OK                                                 *
 *  9) data    = "6.5"                                                *
 *     version = "6.5.0"                                              *
 *     ==> license Not OK                                             *
 *                                                                    *
 **********************************************************************/

int licenseCheckVersion (char* data,char* version);

#ifdef  __cplusplus
} /* extern c*/
#endif

#endif
