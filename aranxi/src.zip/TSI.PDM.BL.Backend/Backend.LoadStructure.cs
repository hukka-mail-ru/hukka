// -----------------------------------------------------------------------
// <copyright file="Backend.LoadStructure.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.BL
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Load a hierarchical structure
    /// </summary>
    public partial class Backend
    {
        /// <summary>
        /// Load all the items and show structure of parts/assemblies in NX
        /// </summary>
        /// <param name="rootItem">an item with children</param>
        /// <param name="showInNX">true if it's needed to open the structure in NX</param>
        public void DoLoadStructure(Item rootItem, bool showInNX)
        {
            // TODO temporary all files are in XmapDir
            rootItem.FolderName = Settings.Instance.XmapDir;

            // load root item
            this.DoLoadSingleFile(rootItem, false, false);

            // load child items
            this.LoadChildFiles(rootItem);

            // show the structure
            if (showInNX)
            {
                this.ShowStructureInNX(rootItem);
            }            
        }

        /// <summary>
        /// Recursively load all the children files of Item
        /// </summary>
        /// <param name="item">an item with children</param>
        private void LoadChildFiles(Item item)
        {
            foreach (Item child in item.Children)
            {
                this.DoLoadSingleFile(child, false, false);
                this.LoadChildFiles(child);
            }
        }

        /// <summary>
        /// Show structure of parts/assemblies in NX Part Navigator
        /// </summary>
        /// <param name="rootItem">an item with children</param>
        private void ShowStructureInNX(Item rootItem)
        {
            // show all rootItem.children
            string path = Path.Combine(rootItem.FolderName, rootItem.native_file);
            if (File.Exists(path))
            {
                NXOpen.Session theSession = NXOpen.Session.GetSession();
                NXOpen.PartLoadStatus status;
                try
                {
                    theSession.Parts.OpenBaseDisplay(path, out status);
                }
                catch(NXOpen.NXException)
                {
                    throw new ExceptionFileAlreadyExists();
                }

                // ARANXI-66 (if wrong file - throw exception)
                if (status.NumberUnloadedParts > 0)
                {
                    for (int i = 0; i < status.NumberUnloadedParts; i++)
                    {
                        throw new MyException("Cannot open " + status.GetPartName(i));
                    }
                }
            }
        }
    }
}
