// -----------------------------------------------------------------------
// <copyright file="Backend.Create.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.BL
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Create an item
    /// </summary>
    public partial class Backend
    {
        /// <summary>
        /// Function which closes new file in case of error and deletes it if there is no already existing one.
        /// </summary>
        /// <param name="ex">Exception from create file dialog</param>
        private void CloseAndDeleteIfError(Exception ex)
        {
            // Error happened during creation of new file - so close it in NX
            NXOpen.Session session = NXOpen.Session.GetSession();
            NXOpen.PartCollection parts = session.Parts;
            NXOpen.Part workPart = parts.Work;
            string path = workPart.FullPath;
            workPart.Close(NXOpen.BasePart.CloseWholeTree.True, NXOpen.BasePart.CloseModified.CloseModified, null);

            // If not NXException "File already exists" - delete created file
            try
            {
                NXOpen.NXException nxEx = (NXOpen.NXException)ex;
            }
            catch
            {
                System.IO.File.Delete(path);
            }
        }

        /// <summary>
        /// Create a file and upload it to ARAS server
        /// </summary>
        /// <param name="item">item to create</param>
        /// <param name="templateName">e.g. "default"</param>
        /// <param name="dir">directory with the file</param>
        /// <param name="showInNX">true if it's needed to show the file in NX</param>
        public void DoCreateSingleFile(Item item, string templateName, string dir, bool showInNX)
        {
            Message.Log("BusinessLogic.DoCreateSingleFile");

            // Check that a Aras-session is existing.
            if (!this.session.IsSessionOpen())
            {
                throw new MyException("Session is not open.");
            }

            // ARANXI-93
            if (item.item_number == string.Empty)
            {
                throw new MyException("Can't create a new file: item name is not set.");
            }

            // Load template
            if (templateName != "default")
            {
                Item template = new Item
                {
                    item_number = templateName,
                    Class = item.Class
                };

                this.LoadTemplate(template);
            }

            try
            {
                // Show file in NX if needed
                if (showInNX)
                {
                    this.ShowFileInNX(templateName, item.item_number, item.GetFileName(), dir);
                }

                // Create item on server
                item.NeedToUploadFile = true;

                this.DoQueryItem(item);
                this.DoUpdateItem(item);
            }
            catch (Exception ex)
            {
                // ARANXI-84: close and delete (if no existing file) a new file in case of error
                CloseAndDeleteIfError(ex);
            }
        }

        /// <summary>
        /// Shows a file in NX
        /// </summary>
        /// <param name="templateName">template name</param>
        /// <param name="itemNumber">item name (item_number)</param>
        /// <param name="cadPartFileName">file name</param>
        /// <param name="dir">directory with the file</param>
        private void ShowFileInNX(string templateName, string itemNumber, string cadPartFileName, string dir)
        {
            // Create NX part
            if (templateName != "default")
            {
                if (!Settings.Instance.UnitTest)
                {
                    NXOpen.Part part = this.CreateNewPart(cadPartFileName, templateName);

                    //part.SaveAs(Path.Combine(dir, cadPartFileName));
                }
            }
            else
            {
                if (!Settings.Instance.UnitTest)
                {
                    // Show the part in NX and save it
                    NXOpen.Session session = NXOpen.Session.GetSession();
                    NXOpen.PartCollection parts = session.Parts;
                    NXOpen.Part part = parts.NewDisplay(itemNumber, NXOpen.Part.Units.Millimeters);
                    part.SaveAs(Path.Combine(dir, cadPartFileName));
                }
                else
                {
                    // UNIT TESTS: create a fake file
                    /*
                    using (FileStream fs = File.Create(Path.Combine(dir, cadPartFileName)))
                    {
                        for (byte i = 0; i < 100; i++)
                        {
                            fs.WriteByte(i);
                        }
                    }
                     */
                }
            }
        }

        /// <summary>
        /// A helper: Create a new NX part
        /// </summary>  
        /// <param name="fileName">file name</param>
        /// <param name="template">template name</param>
        /// <returns>
        /// Created NX Part object
        /// </returns>
        /*
        private NXOpen.Part CreateNewPart(string fileName, string template)
        {
            NXOpen.Session session = NXOpen.Session.GetSession();
            NXOpen.PartCollection parts = session.Parts;
            NXOpen.FileNew fileNew = parts.FileNew();
            fileNew.TemplateFileName = template + ".prt";
            fileNew.Application = NXOpen.FileNewApplication.Modeling;
            fileNew.Units = NXOpen.Part.Units.Millimeters;
            fileNew.NewFileName = fileName;
            fileNew.MasterFileName = string.Empty;
            fileNew.UseBlankTemplate = false;
            fileNew.MakeDisplayedPart = true;
            NXOpen.NXObject obj = fileNew.Commit();
            NXOpen.Part workPart = parts.Work;
            fileNew.Destroy();
            return workPart;
        }
        */

        /// <summary>
        /// A helper: Create a new NX part
        /// </summary>
        /// <param name="fileName">file name</param>
        /// <param name="template">template name</param>
        /// <returns></returns>
        private NXOpen.Part CreateNewPart(string fileName, string template)
        {
            NXOpen.Session session = NXOpen.Session.GetSession();
            NXOpen.PartCollection parts = session.Parts;

            System.IO.File.Copy(Settings.Instance.XmapDir + "\\" + template + ".prt", Settings.Instance.XmapDir + "\\" + fileName);
            NXOpen.PartLoadStatus partLoadStatus;
            NXOpen.BasePart part = session.Parts.OpenBaseDisplay(Settings.Instance.XmapDir + "\\" + fileName, out partLoadStatus);
            NXOpen.Part workPart = session.Parts.Work;
            NXOpen.Part displayPart = session.Parts.Display;
            partLoadStatus.Dispose();
            
            return workPart;
        }

        /// <summary>
        /// Load template from server 
        /// Template is an ordinary CAD Part document on ARAS server
        /// (but with enabled "Template" checkbox).
        /// We can find examples of templates in C:\Program Files\Siemens\NX 8.0\UGII\templates.
        /// </summary>  
        /// <param name="template">template item</param>
        private void LoadTemplate(Item template)
        {
            this.DoQueryItem(template);

            this.DoLoadSingleFile(template, false, true);
        }
    }
}
