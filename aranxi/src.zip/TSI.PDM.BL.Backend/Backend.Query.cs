// -----------------------------------------------------------------------
// <copyright file="Backend.Query.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.BL
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Query an item
    /// </summary>
    public partial class Backend
    {
        /// <summary>
        /// Finds items matching the criteria.
        /// </summary>
        /// <param name="criteria">the criteria</param>
        /// <returns>a list of items matching the query</returns>
        public List<Item> DoFindItems(Item criteria)
        {
            // Check of Aras-NX-Integration license. In case there is no license show error and abort.
            Message.Log("criteria: " + criteria.item_number);

            // Check that a Aras-session is existing.
            if (!this.session.IsSessionOpen())
            {
                throw new MyException("Session is not open.");
            }

            // NX-User defines the search criteria.
            // Query-button starts the search on the Aras Innovator database. When the result is received it is shown in the dialog. Till receiving the data the NX-dialog �Work in progress� is shown. See also chapter 3.1.4 with some additional remarks on the dialog functions.

            // get credentials of current session
            Credentials cred = this.session.GetCurrentCredentials();

            // perform command
            Response response = this.client.Query(cred, criteria);

            return response.Items;
        }

        /// <summary>
        /// Gets the item properties.
        /// Memorize the result in the item itself
        /// </summary>
        /// <param name="item">the item</param>
        public void DoQueryItem(Item item)
        {                      
            //////////////////////////////
            ////  QUERY
            //////////////////////////////
            Message.Log("Item: " + item.item_number + " " + item.Class);

            // Check that a Aras-session is existing.
            if (!this.session.IsSessionOpen())
            {
                throw new MyException("Session is not open.");
            }

            // get credentials of current session
            Credentials cred = this.session.GetCurrentCredentials();

            // perform command
            Response res = this.client.QueryItemByName(cred, item);

            //////////////////////////////
            ////  QUERY RESULT
            //////////////////////////////

            // Check that all selected items are yet existing in Aras. 
            if (res.Items.Count < 1)
            {
                item.ItemServerState = Item.ServerState.New;
                item.RelationServerState = Item.ServerState.New;
                item.ItemOperationState = Item.OperationState.Create;

                Message.Log("Item NOT FOUND (marked as NEW): " + item.item_number);
            }
            else
            {
                // Copy PDM attributes from res.RootItem
                item.Copy(res.RootItem);
                
                item.PwbIsCheckedOutBy  = res.RootItem.PwbIsCheckedOutBy;
                item.PwbFileObjectId    = res.RootItem.PwbFileObjectId;

                item.ItemServerState = Item.ServerState.Existing;
                item.RelationServerState = Item.ServerState.Existing;
                item.ItemOperationState = Item.OperationState.Update;

                Message.LogHi("Item EXISTS: " + item.item_number);
                Message.LogHi(" " + item.item_number);
            }
        }
    }
}
