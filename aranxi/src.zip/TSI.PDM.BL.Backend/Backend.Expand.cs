// -----------------------------------------------------------------------
// <copyright file="Backend.Expand.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.BL
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Expand a structure
    /// </summary>
    public partial class Backend
    {
        /// <summary>
        /// Expand an assembly 
        /// (retrieve all its childs and place a hierarchy of them into Response.Items)
        /// </summary>
        /// <param name="item">the item to expand</param>
        /// <returns>the expanded item (which contains children)</returns>     
        public Item DoExpand(Item item)
        {
            Credentials cred = this.session.GetCurrentCredentials();

            Response response = this.client.MultiExpand(cred, item);

            // bind Items together, depending on their relations
            foreach (Relation r in response.Relations)
            {
                Item parent = this.FindItem(response.Items, r.SourceId);
                Item child = this.FindItem(response.Items, r.RelatedId);

                child.HasParent = true;
                child.Parent = parent;
                parent.Children.Add(child);
            }

            // Find the root of in the hierarchy of Items. 
            foreach (Item resItem in response.Items)
            {
                if (!item.HasParent)
                {
                    response.RootItem = resItem;
                    break;
                }
            }

            if (response.RootItem == null)
            {
                throw new ExceptionItemNotExpandable(item);
            }
                     
            foreach (Item resitem in response.Items)
            {
                Message.Log(" item " + resitem.item_number +
                    ". HasParent: " + resitem.HasParent + " Children: " + resitem.Children.Count);
            }
            
            return response.RootItem;
        }

        /// <summary>
        /// Find an Item in the list by its itemNumber
        /// </summary>
        /// <param name="items">where to find</param>
        /// <param name="itemNumber">what to find</param>
        /// <returns>Found item</returns>
        private Item FindItem(List<Item> items, string itemNumber)
        {
            foreach (Item item in items)
            {
                if (item.item_number == itemNumber)
                {
                    return item;
                }
            }

            throw new MyException("Item '" + itemNumber + "' not found");
        }
    }
}
