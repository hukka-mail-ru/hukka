// -----------------------------------------------------------------------
// <copyright file="Backend.Login.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.BL
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Login/Logout to the ARAS server
    /// </summary>
    public partial class Backend
    {
        /// <summary>
        /// Perform login to ARAS server
        /// </summary>
        /// <param name="cred">user credentials</param>
        public void DoLogin(Credentials cred)
        {
            Message.Log("Login: " + cred.UserName + " " + cred.PasswordMD5 + " " + cred.Database);

            if (this.session.IsLoggedIn())
            {
                return;
            }

            // Perform login to the Aras Innovator Server with the credentials provided.
            Response res = this.client.Login(cred);
            Message.Log(res.Message);

            // open a new session
            this.session.NewSession(cred, SessionMode.CleanStart);

            // Enable the buttons of the Aras-NX-Integration de-pending on a Aras-session. 
            if (!Settings.Instance.UnitTest)
            {
                NXOpen.UI theUI = NXOpen.UI.GetUI();
                theUI.MenuBarManager.GetButtonFromName("PDM_WORKBENCH_LOGOUT").ButtonSensitivity = NXOpen.MenuBar.MenuButton.SensitivityStatus.Sensitive;
                theUI.MenuBarManager.GetButtonFromName("PDM_WORKBENCH_QUERY").ButtonSensitivity = NXOpen.MenuBar.MenuButton.SensitivityStatus.Sensitive;
                theUI.MenuBarManager.GetButtonFromName("PDM_WORKBENCH_CREATEFILE").ButtonSensitivity = NXOpen.MenuBar.MenuButton.SensitivityStatus.Sensitive;
                theUI.MenuBarManager.GetButtonFromName("PDM_WORKBENCH_UPDATE").ButtonSensitivity = NXOpen.MenuBar.MenuButton.SensitivityStatus.Sensitive;
                theUI.MenuBarManager.GetButtonFromName("PDM_WORKBENCH_LOCK").ButtonSensitivity = NXOpen.MenuBar.MenuButton.SensitivityStatus.Sensitive;
                theUI.MenuBarManager.GetButtonFromName("PDM_WORKBENCH_UNLOCK").ButtonSensitivity = NXOpen.MenuBar.MenuButton.SensitivityStatus.Sensitive;
                theUI.MenuBarManager.GetButtonFromName("PDM_WORKBENCH_LOGIN").ButtonSensitivity = NXOpen.MenuBar.MenuButton.SensitivityStatus.Insensitive;
            }
        }

        /// <summary>
        /// Perform login to ARAS server
        /// </summary>   
        public void DoLogout()
        {
            Message.Log("BusinessLogic.DoLogout");

            // TODO
            // Check of Aras-NX-Integration license. 
            // In case there is no license show warning message and proceed.

            // Check that a Aras-session is existing.     
            if (!this.session.IsSessionOpen())
            {
                throw new MyException("Session is not open");
            }

            // get credentials of current session
            Credentials cred = this.session.GetCurrentCredentials();

            // perform Logout command
            Response res = this.client.Logout(cred);
            Message.Log(res.Message);

            // close current session
            this.session.Close(cred);

            // Deactivate/Activate buttons in menu and toolbar.
            if (!Settings.Instance.UnitTest)
            {
                NXOpen.UI theUI = NXOpen.UI.GetUI();
                theUI.MenuBarManager.GetButtonFromName("PDM_WORKBENCH_LOGOUT").ButtonSensitivity = NXOpen.MenuBar.MenuButton.SensitivityStatus.Insensitive;
                theUI.MenuBarManager.GetButtonFromName("PDM_WORKBENCH_QUERY").ButtonSensitivity = NXOpen.MenuBar.MenuButton.SensitivityStatus.Insensitive;
                theUI.MenuBarManager.GetButtonFromName("PDM_WORKBENCH_CREATEFILE").ButtonSensitivity = NXOpen.MenuBar.MenuButton.SensitivityStatus.Insensitive;
                theUI.MenuBarManager.GetButtonFromName("PDM_WORKBENCH_UPDATE").ButtonSensitivity = NXOpen.MenuBar.MenuButton.SensitivityStatus.Insensitive;
                theUI.MenuBarManager.GetButtonFromName("PDM_WORKBENCH_LOCK").ButtonSensitivity = NXOpen.MenuBar.MenuButton.SensitivityStatus.Insensitive;
                theUI.MenuBarManager.GetButtonFromName("PDM_WORKBENCH_UNLOCK").ButtonSensitivity = NXOpen.MenuBar.MenuButton.SensitivityStatus.Insensitive;
                theUI.MenuBarManager.GetButtonFromName("PDM_WORKBENCH_LOGIN").ButtonSensitivity = NXOpen.MenuBar.MenuButton.SensitivityStatus.Sensitive;
            }

            // The license of the Aras-NX-Integration is kept! Free all the other data (documents, …).
        }
    }
}
