// -----------------------------------------------------------------------
// <copyright file="Backend.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.BL
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Backend is the lower level of the application.
    /// It takes requests from the UI and sends them to the ARAS server.
    /// </summary>
    public partial class Backend
    {
        /// <summary>
        /// Singleton instance
        /// </summary>
        private static Backend instance = new Backend();

        /// <summary>
        /// The network client
        /// </summary>
        private Client client = new Client();

        /// <summary>
        /// The server session
        /// </summary>
        private Session session = new Session();

        /// <summary>
        /// TODO: this is redundant
        /// </summary>
        private bool initialized = false;

        /// <summary>
        /// Prevents a default instance of the <see cref="Backend" /> class from being created.
        /// </summary>
        private Backend()
        {
        }
               
        /// <summary>
        /// Gets sigleton instance
        /// </summary>
        public static Backend Instance
        {
            get
            {
                return instance;
            }
        }

        /// <summary>
        /// Unloads the image when the NX session terminates.
        /// </summary>
        /// <param name="arg">not used</param>
        /// <returns>NX AtTermination status</returns>
        public static int GetUnloadOption(string arg)
        {
            // Unloads the image when the NX session terminates
            return System.Convert.ToInt32(NXOpen.Session.LibraryUnloadOption.AtTermination);
        }
        
        /// <summary>
        /// Check license and read settings.xml
        /// </summary>       
        public void Startup()
        {
            Message.Log("Business logic Initialize.");

            // Only one time 
            if (this.initialized)
            {
                Message.Log("Business logic already initialized.");
                return;
            }

            this.initialized = true;

            // Check for open NX sessions
            if (!this.session.IsSessionOpen() && !Settings.Instance.UnitTest)
            {
                /* TODO correct Button Names from Menu file
                NXOpen.UI theUI = NXOpen.UI.GetUI();
                theUI.MenuBarManager.GetButtonFromName("TSI.PDM.GUI.Logout").ButtonSensitivity = NXOpen.MenuBar.MenuButton.SensitivityStatus.Insensitive;
                theUI.MenuBarManager.GetButtonFromName("TSI.PDM.GUI.Query").ButtonSensitivity = NXOpen.MenuBar.MenuButton.SensitivityStatus.Insensitive;
                theUI.MenuBarManager.GetButtonFromName("TSI.PDM.GUI.CreateFile").ButtonSensitivity = NXOpen.MenuBar.MenuButton.SensitivityStatus.Insensitive;
                //theUI.MenuBarManager.GetButtonFromName("TSI.PDM.GUI.Update").ButtonSensitivity = NXOpen.MenuBar.MenuButton.SensitivityStatus.Insensitive;
                theUI.MenuBarManager.GetButtonFromName("TSI.PDM.GUI.Login").ButtonSensitivity = NXOpen.MenuBar.MenuButton.SensitivityStatus.Sensitive;
                 */ 
            }
        }

        /// <summary>
        /// a method for DEBUG
        /// </summary> 
        public void DisableButton()
        {
            NXOpen.UI theUI = NXOpen.UI.GetUI();
            theUI.MenuBarManager.GetButtonFromName("TSI.PDM.GUI.Login").ButtonSensitivity = NXOpen.MenuBar.MenuButton.SensitivityStatus.Insensitive;
        }

        /// <summary>
        /// Get the logged-in user name 
        /// </summary>
        /// <returns>the name</returns>
        public string GetUserName()
        {
            return session.GetCurrentCredentials().UserName;
        }
    }
}