// -----------------------------------------------------------------------
// <copyright file="Backend.Delete.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.BL
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Delete Item
    /// </summary>
    public partial class Backend
    {
        /// <summary>
        /// Deletes an item from ARAS server
        /// </summary>
        /// <param name="item">the item</param>
        public void DoDeleteItem(Item item)
        {
            Message.Log("delete item on server: " + item.item_number);

            // Check that a Aras-session is existing.
            if (!this.session.IsSessionOpen())
            {
                throw new MyException("Session is not open.");
            }

            // get credentials of current session
            Credentials cred = this.session.GetCurrentCredentials();

            Response res = this.client.DeleteItem(cred, item);

            item.ItemServerState = Item.ServerState.Unknown;
            item.generation = "0";
        }
    }
}
