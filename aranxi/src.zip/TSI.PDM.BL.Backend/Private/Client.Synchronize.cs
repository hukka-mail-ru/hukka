﻿// -----------------------------------------------------------------------
// <copyright file="Client.Synchronize.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.BL
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Xml;
    using System.Xml.Linq;

    using TSI.PDM.DataStore;

    /// <summary>
    /// The part of Client, responsible to the Synchronize
    /// </summary>
    internal partial class Client
    {
        /// <summary>
        /// Types of PsnNodeForSync XML element
        /// </summary>
        private enum PsnNodeForSync
        {
            /// <summary>
            /// a type of the XML element
            /// </summary>
            MainPsnNodeForSync,

            /// <summary>
            /// a type of the XML element
            /// </summary>
            AuxPsnNodeForSync
        }

        /// <summary>
        /// Transfer an item and its relations to the ARAS server    
        /// </summary>
        /// <param name="cred">User credentials</param>
        /// <param name="item">the item (probably, with a hierarchical structure)</param>
        /// <returns>server Response</returns>
        public Response Synchronize(Credentials cred, Item item)
        {
            Message.Log("item: " + item.item_number);

            // ARANXI-33 (sc. 10) - all files to update must be in XmapDir 
            this.CheckFileExistsInXmapDir(item);

            string command = "SynchronizePart";

            string requestFile = Path.Combine(Settings.Instance.XmapDir, this.GetRequestFileName(command));
            string responseFile = Path.Combine(Settings.Instance.XmapDir, this.GetResponseFileName(command));

            File.Delete(responseFile); // Zeroize Response file if exists.

            //////////////////////////////////////////
            // Main NODE
            //////////////////////////////////////////
            XElement mainPsnNodeForSync = this.GetPsnNodeForSync(PsnNodeForSync.MainPsnNodeForSync, item);

            //////////////////////////////////////////
            // Aux NODES
            //////////////////////////////////////////
            XElement auxPsnNodesForSync = new XElement("auxPsnNodesForSync");
            foreach (Item child in item.Children)
            {
                if (this.NeedToSynchronize(child))
                {
                    // ARANXI-33 (sc. 10) - all files to update must be in XmapDir 
                    this.CheckFileExistsInXmapDir(child);

                    bool childrenExist = child.Children.Count > 0;

                    XElement auxNode = this.GetPsnNodeForSync(PsnNodeForSync.AuxPsnNodeForSync, child);
                    auxPsnNodesForSync.Add(auxNode);
                }
            }

            //////////////////////////////////////////
            // refCatiaFileNodesForSync NODES
            //////////////////////////////////////////
            XElement refCatiaFileNodesForSync = new XElement("refCatiaFileNodesForSync");

            refCatiaFileNodesForSync.Add(this.GetCatiaFileNodeForSync(item));

            foreach (Item child in item.Children)
            {
                if (this.NeedToSynchronize(child))
                {
                    XElement catiaNode = this.GetCatiaFileNodeForSync(child);
                    refCatiaFileNodesForSync.Add(catiaNode);
                }
            }

            //////////////////////////////////////////
            // Request
            //////////////////////////////////////////
            XElement requestElement =
                new XElement("request", new XAttribute("customization", "Aras"),
                    new XElement("function", new XAttribute("name", "synchronizePart"), new XAttribute("information", "true"),
                        new XElement("partNumber", item.item_number),
                        mainPsnNodeForSync,
                        auxPsnNodesForSync,
                        new XElement("auxDrwNodesForSync"),
                        new XElement("bomChildPsnNodesForSync"),
                        refCatiaFileNodesForSync
                    )
                );

            requestElement.Save(requestFile);
            
#if DEBUG
            // save the xml file separately, for debug
            string time = string.Format("{0:HH-mm-ss-fff}", DateTime.Now);
            requestElement.Save(Path.Combine(Settings.Instance.DebugDir, 
                "Synchronize_" + time + ".xml"));
#endif

            // Send request to server
            this.ExecuteServerRequest(command, cred);

            //////////////////////////////////////////
            // Response
            //////////////////////////////////////////
            // this must go before the "additional check" section because
            // we need to catch a server error first, if it exists in the response file.
            Response response = this.GetServerResponse(responseFile, "synchronizePart");

            // additional check
            string successStatus = XML.GetValue(responseFile, "transactionStatus");
            if (successStatus != "SUCCEEDED")
            {
                throw new ExceptionServerError("successStatus = " + successStatus);
            }

            return response;
        }

        /// <summary>
        /// Creates an XML element  
        /// </summary>
        /// <param name="item">the item</param>
        /// <returns>XML element</returns>
        private XElement GetPsnNode(Item item)
        {
            XElement psnNode =
                new XElement("psnNode", new XAttribute("modified", "true"),
                        new XElement("catiaProperties",
                            new XElement("a", new XAttribute("name", "CatiaPartNumber"), item.item_number),
                            new XElement("a", new XAttribute("name", "CatiaNomenclature")),
                            new XElement("a", new XAttribute("name", "CatiaDefinition")),
                            new XElement("a", new XAttribute("name", "CatiaDescriptionReference")),
                            new XElement("a", new XAttribute("name", "CatiaRevision")),
                            new XElement("a", new XAttribute("name", "CatiaFileName"), item.GetFileName()),
                            new XElement("a", new XAttribute("name", "CatiaUDPDisplayNames")),
                            new XElement("a", new XAttribute("name", "CatiaUDPNames")),
                            new XElement("a", new XAttribute("name", "CatiaUDPValues"))
                        )
                    );

            return psnNode;
        }

        /// <summary>
        /// Creates an XML element  
        /// </summary>
        /// <param name="nodeType">node type</param>
        /// <param name="item">the item</param>
        /// <returns>XML element</returns>
        private XElement GetPsnNodeForSync(PsnNodeForSync nodeType, Item item)
        {
            /////////////////////////////////////////////
            // Main or Aux nodes
            /////////////////////////////////////////////
            string nodeName = (nodeType == PsnNodeForSync.MainPsnNodeForSync) ?
                  "mainPsnNodeForSync" : "auxPsnNodeForSync";

            XElement psnNodeForSync = new XElement(nodeName);
            XElement psnNode = this.GetPsnNode(item);
            XElement filePdmNodeForSync = this.GetFilePdmNode(item, "filePdmNodeForSync");

            if (nodeType == PsnNodeForSync.MainPsnNodeForSync)
            {
                /////////////////////////////////////////////
                // MainPsnNodeForSync
                /////////////////////////////////////////////
                XElement partPdmNodeForSync =
                        new XElement("partPdmNodeForSync",
                            new XAttribute("pdmInfo", "-"),
                            new XAttribute("pdmClass", item.Class),
                            new XAttribute("pdmStatus", "NOT_IN_PDM") // this.GetItemPdmStatus(item))
                        );

                XAttribute isBom = new XAttribute("isBom", "false");

                XElement d = item.ToXML("d");
                d.Add(new XAttribute("class", item.Class));

                psnNodeForSync.Add(isBom);
                psnNodeForSync.Add(d);
                psnNodeForSync.Add(psnNode);
                psnNodeForSync.Add(partPdmNodeForSync);
                psnNodeForSync.Add(filePdmNodeForSync);
            }
            else if (nodeType == PsnNodeForSync.AuxPsnNodeForSync)
            {
                /////////////////////////////////////////////
                // AuxPsnNodeForSync
                /////////////////////////////////////////////
                // set relations
                XElement structRelPdmNodeForSync =
                        new XElement("structRelPdmNodeForSync",
                            new XAttribute("pdmInfo", "-"),
                            new XAttribute("pdmClass", "/CAD Structure/Structure"),
                            new XAttribute("pdmStatus", this.GetRelationPdmStatus(item))
                        );

                // set catia info
                XElement psnInstanceInformation =
                    new XElement("psnInstanceInformation",
                        new XElement("catiaProperties",
                             new XElement("a", new XAttribute("name", "CatiaInstanceName"), item.item_number + ".1"),
                             new XElement("a", new XAttribute("name", "CatiaUnit"), "1.0"),
                             new XElement("a", new XAttribute("name", "CatiaInstanceDescription"))
                        )
                     );

                psnNodeForSync.Add(psnNode);
                psnNodeForSync.Add(psnInstanceInformation);
                psnNodeForSync.Add(filePdmNodeForSync);
                psnNodeForSync.Add(structRelPdmNodeForSync);
            }

            return psnNodeForSync;
        }

        /// <summary>
        /// Creates an XML element  
        /// </summary>
        /// <param name="item">the item</param>
        /// <param name="nodeName">the node name</param>
        /// <returns>XML element</returns>
        private XElement GetFilePdmNode(Item item, string nodeName)
        {
            if (item.ItemServerState != Item.ServerState.New &&
                item.ItemServerState != Item.ServerState.Existing)
            {
                throw new MyException("ServerState of item " + item.item_number +
                    " must be New or Existing only");
            }

            XElement fileNode = new XElement(nodeName);

            if (item.ItemServerState == Item.ServerState.New)
            {
                fileNode.Add(new XAttribute("pdmInfo", "-"));
                fileNode.Add(new XAttribute("pdmClass", item.Class));
                fileNode.Add(new XAttribute("pdmStatus", "NOT_IN_PDM"));
            }
            else
            {
                fileNode.Add(new XAttribute("pdmInfo", "RELATED_TO_PART"));
                fileNode.Add(new XAttribute("pdmClass", item.Class));
                fileNode.Add(new XAttribute("pdmStatus", "EXISTING"));

                string createNewVersion = item.NeedToUploadFile ? "true" : "False";
                
                if (item.Versioning)
                {
                    Message.Log("createNewVersion " + createNewVersion);
                    fileNode.Add(new XAttribute("createNewVersion", createNewVersion));
                }

                XElement pdmNode =
                   new XElement("pdmNode",
                           new XElement("a", new XAttribute("name", "Class"), item.Class),
                           new XElement("a", new XAttribute("name", "OBID"), item.OBID)
                       );

                fileNode.Add(pdmNode);
            }

            return fileNode;
        }

        /// <summary>
        /// Creates an XML element  
        /// </summary>
        /// <param name="item">the item</param>
        /// <returns>XML element</returns>
        private XElement GetCatiaFileNodeForSync(Item item)
        {
            XElement catiaFileNodeForSync =
                   new XElement("refCatiaFileNodeForSync",
                       this.GetPsnNode(item),
                       this.GetFilePdmNode(item, "filePdmObj"),
                       new XElement("designTableMgrForSync",
                           new XElement("designTableInfosForSync_New"),
                           new XElement("designTableInfosForSync_NewlyRelated"),
                           new XElement("designTableInfosForSync_Deleted"),
                           new XElement("designTableInfosForSync_Untouched")
                       )
                   );

            return catiaFileNodeForSync;
        }

        /// <summary>
        /// Checks and returns the PDM status of an item
        /// </summary>
        /// <param name="item">the item</param>
        /// <returns>the PDM status</returns>
        private string GetItemPdmStatus(Item item)
        {
            if (item.ItemServerState != Item.ServerState.New &&
                item.ItemServerState != Item.ServerState.Existing)
            {
                throw new MyException("ServerState of item " + item.item_number +
                    " must be New or Existing only");
            }

            return (item.ItemServerState == Item.ServerState.New) ?
                    "NOT_IN_PDM" : "EXISTING";
        }

        /// <summary>
        /// Checks and returns the PDM status of a relation between an item and its parent
        /// </summary>
        /// <param name="item">the item</param>
        /// <returns>the PDM status</returns>
        private string GetRelationPdmStatus(Item item)
        {
            if (!item.HasParent || item.Parent == null)
            {
                throw new MyException("Parent of item " + item.item_number + " is NULL");
            }

            if (item.RelationServerState != Item.ServerState.New &&
                item.RelationServerState != Item.ServerState.Existing)
            {
                throw new MyException("RelationServerState of item " + item.item_number +
                    " must be New or Existing only");
            }

            if (item.RelationServerState != Item.ServerState.New &&
                item.RelationServerState != Item.ServerState.Existing)
            {
                throw new MyException("RelationServerState of item " + item.Parent.item_number +
                    " (parent of item " + item.item_number + " ) must be New or Existing only");
            }

            return (item.RelationServerState == Item.ServerState.New ||
                    item.Parent.RelationServerState == Item.ServerState.New) ?
                      "NOT_IN_PDM" : "EXISTING";
        }

        /// <summary>
        /// Returns a boolean indicating if we need to synchronize an item 
        /// </summary>
        /// <param name="item">the item</param>
        /// <returns>true if we need to synchronize an item </returns>
        private bool NeedToSynchronize(Item item)
        {
            return
                (item.ItemServerState != Item.ServerState.Unknown &&
                 item.ItemOperationState != Item.OperationState.Skip)
                                            ||
                (item.ItemServerState == Item.ServerState.Existing &&
                 item.ItemOperationState == Item.OperationState.Skip);
        }

        /// <summary>
        /// Checks if a file exists in the XmapDir
        /// </summary>
        /// <param name="item">the item</param>
        private void CheckFileExistsInXmapDir(Item item)
        {
            if (item.NeedToUploadFile && 
                !File.Exists(item.GetFullLocalFileName(Settings.Instance.XmapDir)))
            {
                throw new ExceptionFileNotFound(item, Settings.Instance.XmapDir);
            }
        }
    }
}
