// -----------------------------------------------------------------------
// <copyright file="Session.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.BL
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Xml.Linq;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Session is attached to a Aras session - which itself is bound to 
    /// a PwbArasCommon.exe-process to a specific XMAP.
    /// </summary>
    internal class Session
    {
        /// <summary>
        /// Have we already logged in.
        /// </summary>
        private bool loggedIn = false;

        /// <summary>
        /// Current user credentials
        /// </summary>
        private Credentials credentials;

        /// <summary>
        /// A flag: true if the current session is open
        /// </summary>
        private bool isSessionOpen;

        /// <summary>
        /// Use it only from BL.DoLogin(). For other cases, use IsSessionOpen().
        /// </summary>
        /// <returns>
        /// true if a user has logged in
        /// </returns>
        public bool IsLoggedIn()
        {
            if (this.isSessionOpen)
            {
                // Session is open, but it may be the result of incorrect logout.
                // So, need to see, if we haven't looged in yet.
                if (this.loggedIn)
                {
                    Message.Log("We have already logged in.");
                }
                else
                {
                    Message.Log("Warning: The previous session was not correctly closed.");
                }

                return this.loggedIn;
            }
            else
            {
                // the previous session was correctly closed 
                return false;
            }
        }

        /// <summary>
        /// Creates a new session by login on to the Aras Innovator Server. If this fails a exception are thrown.
        /// </summary>
        /// <param name="cred">User credentials</param>
        /// <param name="mode">session mode</param>
        public void NewSession(Credentials cred, SessionMode mode)
        {
            this.credentials = cred;
            this.isSessionOpen = true;

            this.loggedIn = true; 
        }

        /// <summary>
        /// Closes the session.
        /// </summary>
        /// <param name="cred">User credentials</param>
        public void Close(Credentials cred)
        {
            // save the results
            this.credentials = cred;
            this.isSessionOpen = false;
        }

        /// <summary>
        /// Get credentials of current session
        /// </summary>
        /// <returns>
        /// a Credentials object
        /// </returns>
        public Credentials GetCurrentCredentials()
        {
            return this.credentials;
        }

        /// <summary>
        /// get session info from session.xml
        /// </summary>
        /// <returns>
        /// true if current session is open
        /// </returns>
        public bool IsSessionOpen()
        {
            return this.isSessionOpen;
        }

        /// <summary>
        /// In case the XMAP is not empty this method reconstructs the PDM-status of the last session or throws a exception.
        /// </summary>
        private void RecoverLastSession()
        {
            throw new System.NotImplementedException();
        }
    }
}
