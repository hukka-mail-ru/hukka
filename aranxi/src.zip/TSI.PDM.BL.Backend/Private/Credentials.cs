// -----------------------------------------------------------------------
// <copyright file="Credentials.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.BL
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Cryptography;
    using System.Text;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Stores user's credentials to login to a database on ARAS server
    /// </summary>
    public class Credentials
    {
        /// <summary>
        /// User name (login)
        /// </summary>
        private string username;

        /// <summary>
        /// Encripted password
        /// </summary>
        private string passwordMD5;

        /// <summary>
        /// Database name
        /// </summary>
        private string database;

        /// <summary>
        /// Initializes a new instance of the <see cref="Credentials" /> class.
        /// </summary>
        /// <param name="username">User name</param>
        /// <param name="password">Password in plain text form</param>
        /// <param name="database">Database name</param>
        public Credentials(string username, string password, string database)
        {
            this.username = username;
            this.passwordMD5 = this.GetMD5Hash(password);
            this.database = database;
        }

        /// <summary>
        /// Gets user name (login)
        /// </summary>
        public string UserName
        {
            get
            {
                return this.username;
            }
        }

        /// <summary>
        /// Gets encripted password
        /// </summary>
        public string PasswordMD5
        {
            get
            {
                return this.passwordMD5;
            }
        }

        /// <summary>
        /// Gets Database name
        /// </summary>
        public string Database
        {
            get
            {
                return this.database;
            }
        }    

        /// <summary>
        /// returns an MD5 hash of the given string
        /// </summary>
        /// <param name="input">a string to be hashed, e.g. a password</param>
        /// <returns>Encripted string</returns>
        private string GetMD5Hash(string input)
        {
            try
            {
                // step 1, calculate MD5 hash from input
                MD5 md5 = System.Security.Cryptography.MD5.Create();
                byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
                byte[] hash = md5.ComputeHash(inputBytes);

                // step 2, convert byte array to hex string
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < hash.Length; i++)
                {
                    sb.Append(hash[i].ToString("X2"));
                }

                return sb.ToString();
            }
            catch (Exception e)
            {
                throw new MyException("Error calculating MD5 hash." + e.Message);
            }
        }
    }
}
