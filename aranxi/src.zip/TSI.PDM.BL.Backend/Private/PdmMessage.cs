// -----------------------------------------------------------------------
// <copyright file="PdmMessage.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.DataStore
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// Log messages which are in server responses
    /// </summary>
    internal class PdmMessage
    {
        /// <summary>
        /// Types of messages
        /// </summary>
        public enum PdmMessageType
        {
            /// <summary>
            /// An ordinary message
            /// </summary>
            Information,

            /// <summary>
            /// An error
            /// </summary>
            Error
        }

        /// <summary>
        /// Gets or sets class of the Item (Part or Assembly)
        /// </summary>
        public PdmMessageType Type { get; set; }

        /// <summary>
        /// Gets or sets class of the Item (Part or Assembly)
        /// </summary>
        public string Content { get; set; }
    }
}
