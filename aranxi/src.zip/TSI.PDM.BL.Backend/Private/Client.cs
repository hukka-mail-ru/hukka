// -----------------------------------------------------------------------
// <copyright file="Client.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.BL
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Xml;
    using System.Xml.Linq;
    using PwbArasClientsCommon;
    using TSI.PDM.DataStore;

    /// <summary>
    /// This class sends various commands to the ARAS server. Implementation: singleton.
    /// </summary>
    internal partial class Client
    {        
        /// <summary> This member holds a PwbClient-instance during the lifetime of the this instance.
        /// The PwbClient holds the connection to the IpcServer which makes it impossible for a second
        /// ArasCommonClient to connect to this IpcServer. As for one Xmap only one IpcServer exists for
        /// each Xmap only one session of ArasCommonClient is possible. This is wanted to protect against
        /// unwanted side-effects when multipe ArasCommonClients are using the same Xmap.</summary>
        /// private PwbClient pwbclient = new PwbClient();

        /// <summary>
        /// Authorize a user on the ARAS server using given credentials.
        /// </summary>
        /// <param name="cred">User credentials</param>
        /// <returns>Server response</returns>
        public Response Login(Credentials cred)
        {
            string command = "Login";

            string requestFile = Path.Combine(Settings.Instance.XmapDir, this.GetRequestFileName(command));
            string responseFile = Path.Combine(Settings.Instance.XmapDir, this.GetResponseFileName(command));

            File.Delete(responseFile); // Zeroize Response file if exists.

            //////////////////////////////////////////
            // Request
            //////////////////////////////////////////
            XElement requestElement = new XElement("request",
                                    new XElement("function",
                                        new XAttribute("name", "login")
                                    )
                                );
            requestElement.Save(requestFile);

            // Send request to server
            this.ExecuteServerRequest(command, cred);

            //////////////////////////////////////////
            // Response
            //////////////////////////////////////////
            Response response = this.ReadLoginLogoutResponse(command, responseFile);

            if (response.SuccessStatus != "true")
            {
                this.Logout(cred);

                throw new ExceptionServerError(response.Message);
            }

            return response;
        }

        /// <summary>
        /// Logout from the ARAS server
        /// </summary>
        /// <param name="cred">User credentials</param>
        /// <returns>Server response</returns>
        public Response Logout(Credentials cred)
        {
            string command = "Logout";

            string requestFile = Path.Combine(Settings.Instance.XmapDir, this.GetRequestFileName(command));
            string responseFile = Path.Combine(Settings.Instance.XmapDir, this.GetResponseFileName(command));

            File.Delete(responseFile); // Zeroize Response file if exists.

            // Request "Logout"
            XElement requestElement = new XElement("request",
                    new XElement("function",
                        new XAttribute("name", "logout")
                    )
                );
            requestElement.Save(requestFile);

            // Send request to server
            this.ExecuteServerRequest(command, cred);

            // Read server response
            Response response = this.ReadLoginLogoutResponse(command, responseFile);
            if (response.SuccessStatus != "true")
            {
                if (response.Message.Contains("SOAP-ENV:ServerAuthentication failed for"))
                {
                    response.Message = "Authentication failed";
                }

                throw new ExceptionServerError(response.Message);
            }

            return response;
        }

        /// <summary>
        /// Queries an item in the ARAS server by its name and class only
        /// </summary>
        /// <param name="cred">User credentials</param>
        /// <param name="item">the Item</param>
        /// <returns>Server response</returns>
        public Response QueryItemByName(Credentials cred, Item item)
        {
            Item itemToQuery = new Item();
            itemToQuery.item_number = item.item_number;
            itemToQuery.Class = item.Class;

            return this.Query(cred, itemToQuery);
        }

        /// <summary>
        /// Queries an item in the ARAS server 
        /// </summary>
        /// <param name="cred">User credentials</param>
        /// <param name="item">the Item</param>
        /// <returns>Server response</returns>
        public Response Query(Credentials cred, Item item)
        {
            string command = "Query";

            string requestFile = Path.Combine(Settings.Instance.XmapDir, this.GetRequestFileName(command));
            string responseFile = Path.Combine(Settings.Instance.XmapDir, this.GetResponseFileName(command));

            File.Delete(responseFile); // Zeroize Response file if exists.

            //////////////////////////////////////////
            // Request
            //////////////////////////////////////////
            XElement requestElement =
                new XElement("request", new XAttribute("customization", "Aras"),
                    new XElement("function", new XAttribute("name", "query"), new XAttribute("information", "-"),
                        new XElement("o",
                            new XElement("a", new XAttribute("name", "Class"), item.Class),
                            item.ToXML("d")
                            )
                       )
                );

            requestElement.Save(requestFile);

            // Send request to server
            this.ExecuteServerRequest(command, cred);

            //////////////////////////////////////////
            // Response
            //////////////////////////////////////////

            Response response = this.GetServerResponse(responseFile, "query");

            foreach (Item resItem in response.Items)
            {
                resItem.ItemServerState = Item.ServerState.Existing;
            }

            return response;
        }
   
        /// <summary>
        /// Perform a 'Lock' or 'Unlock' request to the ARAS server
        /// </summary>
        /// <param name="cred">User credentials</param>
        /// <param name="item">Item to lock/unlock</param>
        /// <param name="dolock">True if the lock is needed, false if unlock</param>
        /// <returns>Server response</returns>
        public Response LockUnlock(Credentials cred, Item item, bool dolock)
        {
            string command = (dolock == true) ? "CheckOut" : "CheckIn";

            string requestFile = Path.Combine(Settings.Instance.XmapDir, this.GetRequestFileName(command));
            string responseFile = Path.Combine(Settings.Instance.XmapDir, this.GetResponseFileName(command));

            File.Delete(responseFile); // Zeroize Response file if exists.

            //////////////////////////////////////////
            // Request
            //////////////////////////////////////////
            string function = (dolock == true) ? "checkOut" : "checkIn";

            XElement requestElement =
                new XElement("request", new XAttribute("customization", "Aras"),
                    new XElement("function", new XAttribute("name", function), new XAttribute("information", "-"),
                        new XElement("o", new XAttribute("PwbCreateNewVersion", "false"),
                            new XElement("a", new XAttribute("name", "Class"), item.Class),
                            new XElement("a", new XAttribute("name", "OBID"), item.OBID),
                            new XElement("a", new XAttribute("name", "NodeType"), "OBJECT")
                        )
                    )
                );

            requestElement.Save(requestFile);

            // Send request to server
            this.ExecuteServerRequest(command, cred);

            //////////////////////////////////////////
            // Response
            //////////////////////////////////////////
            Response res = this.GetServerResponse(responseFile, function);

            // check if we are not unlocking an alien item
            if (res.Items.Count > 0)
            {
                if (dolock == false &&
                    res.Items[0].PwbIsCheckedOutBy != null &&
                    res.Items[0].PwbIsCheckedOutBy.Length > 0 &&
                    res.Items[0].PwbIsCheckedOutBy != cred.UserName)
                {
                    throw new ExceptionItemLockedBySomeoneElse();
                }
            }
            
            return res;
        }
      
        /// <summary>
        /// Updates items data on the ARAS server
        /// </summary>
        /// <param name="cred">User credentials</param>
        /// <param name="items">items to update</param>
        /// <returns>server Response</returns>
        public Response UpdateItemsData(Credentials cred, List<Item> items)
        {
            string command = "UpdatePdmFileData";

            string requestFile = Path.Combine(Settings.Instance.XmapDir, this.GetRequestFileName(command));
            string responseFile = Path.Combine(Settings.Instance.XmapDir, this.GetResponseFileName(command));

            File.Delete(responseFile); // Zeroize Response file if exists.

            XElement function =
                new XElement("function",
                    new XAttribute("name", "updatePdmFileData"),
                    new XAttribute("information", "UpdateAfterFileUpload")
                 );

            foreach (Item item in items)
            {
                Message.Log("item: " + item.item_number);

                string versioning = (item.ItemServerState == Item.ServerState.Existing) ? "true" : "false";

                if (!item.Versioning)
                {
                    versioning = "false";
                }

                Message.Log("versioning: " + versioning);

                XElement o = new XElement("o", new XAttribute("PwbCreateNewVersion", "false"),
                                 new XElement("a", new XAttribute("name", "Class"), item.Class),
                                 new XElement("a", new XAttribute("name", "OBID"), item.OBID),
                                 new XElement("d",
                                     new XElement("a", new XAttribute("name", "Versioning"), versioning),
                                     new XElement("a", new XAttribute("name", "WorkspaceName")),
                                     new XElement("a", new XAttribute("name", "FolderName")),
                                     new XElement("a", new XAttribute("name", "PwbLinkTargetKeys"))
                                     ),
                                 new XElement("a", new XAttribute("name", "NodeType"), "OBJECT")
                             );

                function.Add(o);
            }          

            //////////////////////////////////////////
            // Request
            //////////////////////////////////////////
            XElement request =
                new XElement("request", new XAttribute("customization", "Aras"),
                    function
                );

            request.Save(requestFile);

            // Send request to server
            this.ExecuteServerRequest(command, cred);

            //////////////////////////////////////////
            // Response
            //////////////////////////////////////////

            return this.GetServerResponse(responseFile, "updatePdmFileData");
        }

        /// <summary>
        /// Perform a 'MultiExpand' request to the ARAS server    
        /// </summary>
        /// <param name="cred">User credentials</param>
        /// <param name="item">item to expand</param>
        /// <returns>server Response</returns>
        public Response MultiExpand(Credentials cred, Item item)
        {
            string command = "MultiExpand";

            string requestFile = Path.Combine(Settings.Instance.XmapDir, this.GetRequestFileName(command));
            string responseFile = Path.Combine(Settings.Instance.XmapDir, this.GetResponseFileName(command));

            File.Delete(responseFile); // Zeroize Response file if exists.

            //////////////////////////////////////////
            // Request
            //////////////////////////////////////////
            XElement requestElement =
                new XElement("request", new XAttribute("customization", "Aras"),
                    new XElement("function", new XAttribute("name", "multiExpand"), new XAttribute("information", "-"),
                        new XElement("o",
                            new XElement("a", new XAttribute("name", "OBID"), item.OBID),
                            new XElement("a", new XAttribute("name", "Class"), item.Class),
                            new XElement("r",
                                new XElement("a", new XAttribute("name", "Class"), "/CAD Structure/Structure"),
                                new XElement("a", new XAttribute("name", "Relationship"), "/CAD Structure/Structure_LeftToRight"),
                                new XElement("a", new XAttribute("name", "ExpectedObjectClass")),
                                new XElement("a", new XAttribute("name", "AdditionalInfo"), "AsSaved")
                            )
                        )
                    )
                );

            requestElement.Save(requestFile);

            // Send request to server
            this.ExecuteServerRequest(command, cred);

            //////////////////////////////////////////
            // Response
            //////////////////////////////////////////

            return this.GetServerResponse(responseFile, "multiExpand");
        }

        /// <summary>
        /// Deletes an item from ARAS server
        /// </summary>
        /// <param name="cred">User creadentials</param>
        /// <param name="item">the item</param>
        /// <returns>server response</returns>
        public Response DeleteItem(Credentials cred, Item item)
        {
            string command = "Delete";

            string requestFile = Path.Combine(Settings.Instance.XmapDir, this.GetRequestFileName(command));
            string responseFile = Path.Combine(Settings.Instance.XmapDir, this.GetResponseFileName(command));

            File.Delete(responseFile); // Zeroize Response file if exists.

            //////////////////////////////////////////
            // Request
            //////////////////////////////////////////
            XElement requestElement =
                new XElement("request", new XAttribute("customization", "Aras"),
                    new XElement("function", new XAttribute("name", "delete"), new XAttribute("information", "-"),
                        new XElement("o",
                            new XElement("a", new XAttribute("name", "OBID"), item.OBID),
                            new XElement("a", new XAttribute("name", "Class"), item.Class),
                            new XElement("a", new XAttribute("name", "NodeType"), "OBJECT")

                            // TODO Delete request can have relations
                            /*
                            new XElement("r",
                                new XElement("a", new XAttribute("name", "Class"), "/CAD Structure/Structure"),
                                new XElement("a", new XAttribute("name", "Relationship"), "/CAD Structure/Structure_LeftToRight"),
                                new XElement("a", new XAttribute("name", "ExpectedObjectClass")),
                                new XElement("a", new XAttribute("name", "AdditionalInfo"), "AsSaved")
                            )
                             */
                        )
                    )
                );

            requestElement.Save(requestFile);

            // Send request to server
            this.ExecuteServerRequest(command, cred);

            //////////////////////////////////////////
            // Response
            //////////////////////////////////////////

            return this.GetServerResponse(responseFile, "delete");
        }

        /// <summary>
        /// Upload files to server
        /// </summary>
        /// <param name="cred">User creadentials</param>
        /// <param name="items">files to upload</param>
        /// <param name="dir">local dirrectory with the files</param>
        public void UploadFiles(Credentials cred, List<Item> items, string dir)
        {
            string command = "upload";
            string resultFile = Settings.Instance.XmapDir + "\\" + this.GetResultFileName(command);
            File.Delete(resultFile); // Zeroize Response file if exists.

            string filesToTransfer = Path.Combine(Settings.Instance.XmapDir, "FilesToTransfer.txt");
            System.IO.StreamWriter file = new System.IO.StreamWriter(filesToTransfer);

            foreach (Item item in items)
            {
                Message.Log("item: " + item.item_number);

                Message.Log("item.ItemServerState: " + item.ItemServerState);
                string newVersion = (item.ItemServerState == Item.ServerState.Existing) ? "true" : "false";

                if (!item.Versioning)
                {
                    newVersion = "false";
                }

                Message.Log("newVersion: " + newVersion);

                // create XMAP/FilesToTransfer.txt: OBID|-|prtFileName|False|false
                string lines = item.OBID + "|-|" +
                               Path.Combine(dir, item.GetFileName()) +
                               "|False|" + newVersion;
                
                file.WriteLine(lines);
            }

            file.Close();

            this.ExecuteServerFileOperation(command, filesToTransfer, cred);
        }

        /// <summary>
        /// Download a file from server
        /// </summary>
        /// <param name="cred">User creadentials</param>
        /// <param name="item">file to download</param>
        public void DownloadFile(Credentials cred, Item item)
        {
            string fileName = Path.Combine(item.FolderName, item.native_file);

            Message.Log("Download File: " + fileName);

            string command = "download";
            string resultFile = Path.Combine(Settings.Instance.XmapDir, this.GetResultFileName(command));
            File.Delete(resultFile); // Zeroize Response file if exists.

            string filesToTransferTxt = Path.Combine(Settings.Instance.XmapDir, "FilesToTransfer.txt");

            Message.Log("files To Transfer: " + filesToTransferTxt);

            // create XMAP/FilesToTransfer.txt: OBID|PwbFileObjectId|prtFileName            
            string lines = item.OBID + "|" + item.PwbFileObjectId + "|" +
                           fileName;

            System.IO.StreamWriter file = new System.IO.StreamWriter(filesToTransferTxt);
            file.WriteLine(lines);

            file.Close();

            this.ExecuteServerFileOperation(command, filesToTransferTxt, cred);

            // check
            if (!File.Exists(fileName))
            {
                throw new MyException("File '" + fileName + "' was not downloaded");
            }
        }

        /// <summary>
        /// Execute a server operation with a file
        /// </summary>
        /// <param name="command">Upload, Download, etc..</param>
        /// <param name="filesToTransfer">file to be uploaded (downloaded)</param>
        /// <param name="cred">User Credentials</param>
        private void ExecuteServerFileOperation(string command, string filesToTransfer, Credentials cred)
        {
            PwbArasClientsCommon.PwbArasFileClient.FileClient.FileClientCallState methodState = new PwbArasClientsCommon.PwbArasFileClient.FileClient.FileClientCallState();

            // Create additional arguments XML
            XElement additionalArguments =
                        new XElement("request", new XAttribute("customization", "Aras"),
                            new XElement("languageID", "en_us"),
                            new XElement("function", new XAttribute("name", "Login"),
                                new XElement("o",
                                    new XElement("a", new XAttribute("name", "User"), cred.UserName),
                                    new XElement("a", new XAttribute("name", "Password"), cred.PasswordMD5),
                                    new XElement("a", new XAttribute("name", "LoginDatabase"), cred.Database)
                                )
                            )
                        );

            methodState.Action = command;
            methodState.ExMapDir = Settings.Instance.XmapDir;
            methodState.FileListFile = filesToTransfer;
            methodState.LogDirectory = Settings.Instance.LogDir;
            methodState.Password = cred.PasswordMD5;
            methodState.SoapTargetUrl = Settings.Instance.Server;
            methodState.AdditionalLoginArgumentsXml = additionalArguments.ToString();
            methodState.Debug = "yes";
            methodState.CheckInOutFormat = "-|-|-|-|-|-|<none>|<none>";
            methodState.CatiaFileClass = "CAD";
            methodState.Method = PwbArasClientsCommon.PwbArasFileClient.FileClient.Execute;

            Message.Log("Action: " + methodState.Action);
            
            try
            {
                using (var pwbclient = new PwbClient())
                {
                    pwbclient.Execute(methodState);
                }
            }
            catch (System.Exception e)
            {
                throw new ExceptionClientError(e.Message);
            }

            // Message.Log("MethodState.Result: " + methodState.Result);
        }

        /// <summary>
        /// Execute a server request 
        /// </summary>
        /// <param name="command">Login, Logout, etc..</param>
        /// <param name="cred">User Credentials</param>
        private void ExecuteServerRequest(string command, Credentials cred)
        {
            Debug.Assert(cred.UserName != null, "No UserName");
            Debug.Assert(cred.PasswordMD5 != null, "No Password");
            Debug.Assert(cred.Database != null, "No Database");

            // Create additional arguments XML
            XElement additionalArguments =
                        new XElement("request", new XAttribute("customization", "Aras"),
                            new XElement("languageID", "en_us"),
                            new XElement("function", new XAttribute("name", "Login"),
                                new XElement("o",
                                    new XElement("a", new XAttribute("name", "User"), cred.UserName),
                                    new XElement("a", new XAttribute("name", "Password"), cred.PasswordMD5),
                                    new XElement("a", new XAttribute("name", "LoginDatabase"), cred.Database)
                                )
                            )
                        );

            // SOAP client to call
            PwbArasClientsCommon.PwbArasSoapClient.SoapClient.SoapClientCallState methodState =
                new PwbArasClientsCommon.PwbArasSoapClient.SoapClient.SoapClientCallState();

            Message.Log("ExecuteServerRequest: " + command);

            // Prepare request parameters
            methodState.Action = command;
            methodState.AdditionalLoginArgumentsXml = additionalArguments.ToString();
            methodState.Debug = "true";
            methodState.ExMapDir = Settings.Instance.XmapDir;
            methodState.LogDirectory = Settings.Instance.LogDir;
            methodState.Password = cred.PasswordMD5;
            methodState.SoapTargetUrl = Settings.Instance.Server;
            methodState.User = cred.UserName;
            methodState.State = string.Empty;
            methodState.RequestFileName = this.GetRequestFileName(command);
            methodState.Method = PwbArasClientsCommon.PwbArasSoapClient.SoapClient.Execute;
            methodState.Result = -1;
            /*
            Message.Log("MethodState.Action  " + methodState.Action);
            Message.Log("MethodState.AdditionalLoginArgumentsXml " + methodState.AdditionalLoginArgumentsXml);
            Message.Log("MethodState.Debug " + methodState.Debug);
            Message.Log("MethodState.ExMapDir " + methodState.ExMapDir);
            Message.Log("MethodState.Password " + methodState.Password);
            Message.Log("MethodState.SoapTargetUrl " + methodState.SoapTargetUrl);
            Message.Log("MethodState.User " + methodState.User);
            */

            // Execute the request
            try
            {
                using (var pwbclient = new PwbClient())
                {
                    pwbclient.Execute(methodState);

                    if (methodState.Action == "Logout")
                    {
                        pwbclient.Execute(new PwbIpcServerShutdown());
                    }
                }
            }
            catch (System.Exception e)
            {
                throw new ExceptionClientError(e.Message);
            }

            // Kill process if bad login. 
            // Warning! This doesn't seem to work when connection is too slow.  
            // Need to be tested on slow connection. 
            /*
                        else if (MethodState.Action == "Login")
                        {
                            if (MethodState.Result == -1)
                            {
                                Message.Show("Wrong login -> no session to hold!");
                                try
                                {                                
                                    sc.Execute(new PwbIpcServerShutdown());
                                    Message.Show("Process killed.");
                                }
                                catch (Exception)
                                {
                                    // Nothing to do, server seams down.
                                    Message.Show("Nothing to do, server seams down.");
                                }
                            }
                        }
            */
        }

        /// <summary>
        /// A helper: read server response of Login/Logout operation
        /// </summary>
        /// <param name="command">Login, Logout, etc...</param>
        /// <param name="responseFile">response XML file</param>
        /// <returns>Server response</returns>
        private Response ReadLoginLogoutResponse(string command, string responseFile)
        {
            Response response = new Response();

            this.CheckResponseFile(responseFile);

            // check the server response
            if (XML.GetRootName(responseFile) != "error")
            {
                // success?
                response.SuccessStatus = XML.GetAttribute(responseFile, "status", "success");
                if (response.SuccessStatus == "true")
                {
                    if (command == "Login")
                    {
                        response.Message = "Welcome to ARAS server";
                    }
                    else if (command == "Logout")
                    {
                        response.Message = XML.GetValue(responseFile, "message");
                    }
                }
                else
                {
                    response.Message = "Please check you credentials";
                }
            }
            else
            {
                // server reports an error
                response.SuccessStatus = "false";
                response.Message = XML.GetValue(responseFile, "responseFromServer");
            }

            return response;
        }

        /// <summary>
        /// return a full name of XML request file, e.g. "PwbLoginRequest.xml"
        /// </summary>
        /// <param name="command">e.g. "Login"</param>
        /// <returns>The file name</returns>
        private string GetRequestFileName(string command)
        {
            return "Pwb" + command + "Request.xml";
        }

        /// <summary>
        /// Gets a full name of XML response file, e.g. "PwbLoginResponse.xml"
        /// </summary>
        /// <param name="command">e.g. "Login"</param>
        /// <returns>a full name of XML response file</returns>
        private string GetResponseFileName(string command)
        {
            return "Pwb" + command + "Response.xml";
        }

        /// <summary>
        /// Gets a full name of XML result file, e.g. "downloadResult.xml"
        /// </summary>
        /// <param name="command">e.g. "Login"</param>
        /// <returns>the file name</returns>
        private string GetResultFileName(string command)
        {
            return command + "Result.xml";
        }

        /// <summary>
        /// Try to load a file. If its content is missing, return false.
        /// </summary>
        /// <param name="fileName">file to load</param>
        private void CheckResponseFile(string fileName)
        {
            try
            {
                XElement root = XElement.Load(fileName);
            }
            catch (Exception)
            {
                throw new ExceptionServerError("invalid or empty. Please check log file.");
            }
        }

        /// <summary>
        /// Extract objects (o-elements) from file
        /// </summary>
        /// <param name="responseFile">XML file with server response</param>
        /// <param name="functionName">e.g. "multiExpand", etc..</param>
        /// <returns>An array of objects (o-elements)</returns>
        private List<Item> ExtractItems(string responseFile, string functionName)
        {
            Message.Log("Extract Items: " + responseFile + " "  + functionName);

            XElement root = XElement.Load(responseFile);

            // get <object name="function">
            XElement function = (from el in root.Descendants("function")
                                 where (string)el.Attribute("name") == functionName
                                 select el).First();

            // get <o>
            IEnumerable<XElement> objects =
                    from el in function.Descendants("o")
                    select el;

            List<Item> items = new List<Item>();
            foreach (XElement o in objects)
            {
                // Message.Show("XElement o " + o.Name);
                // get all values <a>
                IEnumerable<XElement> attrs =
                    from el in o.Descendants("a")
                    select el;

                Item item = new Item();
                
                foreach (XElement a in attrs)
                {
                    // copy PDM attributes from XElement to Item
                    item.FromXML(a);

                    string name = (string)a.Attribute("name");
                    string value = (string)a;

                    switch (name)
                    {                     
                        case "PwbInfo":
                            {
                                IEnumerable<XElement> vs =
                                                from el in a.Descendants("v")
                                                select el;

                                /* ARANXI-47: 
                                 * Query must not be aborted when one of the CAD Documents in the database 
                                 * has no file attached.*/
                                foreach (XElement v in vs)
                                {
                                    switch ((string)v.Attribute("name"))
                                    {
                                        case "PwbFileObjectId": item.PwbFileObjectId = (string)v; 
                                            break;
                                        case "PwbIsCheckedOutBy": item.PwbIsCheckedOutBy = (string)v; 
                                            break;
                                        default: break;
                                    }
                                }
                            }

                            break;
                        default: break;
                    }
                }

                Message.Log(item.item_number);
                Message.Log(item.OBID);
                Message.Log(item.Class);

                items.Add(item);
            }

            return items;
        }

        /// <summary>
        /// Extract relations (r-elements) from file
        /// </summary>
        /// <param name="responseFile">XML file with server response</param>
        /// <param name="functionName">e.g. "multiExpand", etc..</param>
        /// <returns>the array of the Relation objects</returns>
        private List<Relation> ExtractRelations(string responseFile, string functionName)
        {
            XElement root = XElement.Load(responseFile);

            // get <object name="function">
            XElement function = (from el in root.Descendants("function")
                                 where (string)el.Attribute("name") == functionName
                                 select el).First();

            // get <r>
            IEnumerable<XElement> rs =
                    from el in function.Descendants("r")
                    select el;

            List<Relation> relations = new List<Relation>();
            foreach (XElement r in rs)
            {
                // get all values <a>
                IEnumerable<XElement> attrs =
                    from el in r.Descendants("a")
                    select el;

                Relation relation = new Relation();
                foreach (XElement a in attrs)
                {
                    switch ((string)a.Attribute("name"))
                    {
                        case "source_id": relation.SourceId = (string)a; 
                            break;
                        case "related_id": relation.RelatedId = (string)a; 
                            break;
                        case "Left": relation.Left = (string)a; 
                            break;
                        case "Right": relation.Right = (string)a; 
                            break;
                        case "Class1": relation.Class1 = (string)a; 
                            break;
                        case "Class2": relation.Class2 = (string)a; 
                            break;
                        case "OBID": relation.OBID = (string)a; 
                            break;
                        default: break;
                    }
                }

                relations.Add(relation);
            }

            return relations;
        }

        /// <summary>
        /// Extract Pdm messages (pdmMessage-elements)
        /// </summary>
        /// <param name="responseFile">XML file with server response</param>
        /// <returns>the array of the Pdm messages</returns>
        private List<PdmMessage> ExtractPdmMessages(string responseFile)
        {
            XElement root = XElement.Load(responseFile);

            IEnumerable<XElement> ms = from el in root.Descendants("pdmMessage") select el;
            
            List<PdmMessage> pdmMessages = new List<PdmMessage>();
            foreach (XElement m in ms)
            {
                PdmMessage message = new PdmMessage();
                switch ((string)m.Attribute("type"))
                {
                    case "ERROR": message.Type = PdmMessage.PdmMessageType.Error;
                        break;
                    default: message.Type = PdmMessage.PdmMessageType.Information;
                        break;
                }

                message.Content = (string)m;

                pdmMessages.Add(message);
            }

            return pdmMessages;
        }

        /// <summary>
        /// Parse server response from file
        /// </summary>
        /// <param name="responseFile">XML file with server response</param>
        /// <param name="functionName">e.g. "multiExpand", etc..</param>
        /// <returns>parsed server response</returns>
        private Response GetServerResponse(string responseFile, string functionName)
        {
            Response response = new Response();
            this.CheckResponseFile(responseFile);

            // read the server response
            if (XML.GetRootName(responseFile) == "response")
            {
                response.Items = this.ExtractItems(responseFile, functionName);
                response.Relations = this.ExtractRelations(responseFile, functionName);
                response.PdmMessages = this.ExtractPdmMessages(responseFile);

                this.CheckResponse(response.PdmMessages);

                if (response.Items.Count == 1)
                {
                    response.RootItem = response.Items[0];
                }
            }
            else if (XML.GetRootName(responseFile) == "error")
            {
                string message = XML.GetValue(responseFile, "responseFromServer");

                // make a human-read message
                if (message == "Aras.Server.Core.ItemIsLockedBySomeoneElseException")
                {
                    throw new ExceptionItemLockedBySomeoneElse();
                }

                throw new ExceptionServerError(message);
            }

            return response;
        }

        /// <summary>
        /// Throws an exception if server response contains an error
        /// </summary>
        /// <param name="pdmMessages">list of response messages</param>
        private void CheckResponse(List<PdmMessage> pdmMessages)
        {
            foreach (PdmMessage pdmMessage in pdmMessages)
            {
                if (pdmMessage.Type == PdmMessage.PdmMessageType.Error)
                {
                    throw new ExceptionServerError(pdmMessage.Content);
                }
                else
                {
                    Message.Log("PdmMessage:  " + pdmMessage.Content);
                }
            }
        }
    }
}