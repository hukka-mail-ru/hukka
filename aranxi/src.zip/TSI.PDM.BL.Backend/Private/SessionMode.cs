// -----------------------------------------------------------------------
// <copyright file="SessionMode.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.BL
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using TSI.PDM.DataStore;

    /// <summary>
    /// SessionMode of a Session.
    /// </summary>
    internal enum SessionMode
    {
        /// <summary>
        /// This session-mode describes a session which deletes the XMAP before starting.
        /// </summary>
        CleanStart,

        /// <summary>
        /// This session-mode describes a session which doesn´t try to recover the last PDMSession.
        /// </summary>
        NoRecovering,

        /// <summary>
        /// This session-mode describes a session which tries to recover the last PDMSession from the data available in the XMAP.
        /// </summary>
        Recovering,
    }
}
