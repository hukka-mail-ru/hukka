// -----------------------------------------------------------------------
// <copyright file="Response.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.DataStore
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// Server response
    /// </summary>
    internal class Response
    {
        /// <summary>
        /// All the items in the responce
        /// </summary>
        private List<Item> items = new List<Item>();

        /// <summary>
        /// All the relations between items in the responce
        /// </summary>
        private List<Relation> relations = new List<Relation>();

        /// <summary>
        /// All the Pdm messages (log messages)
        /// </summary>
        private List<PdmMessage> pdmMessages = new List<PdmMessage>();

        /// <summary>
        /// Root item of assembly (if the response contains an assembly)
        /// </summary>
        private Item rootItem = null;

        /// <summary>
        /// Gets or sets status of Login and Logout
        /// </summary>
        public string SuccessStatus { get; set; }

        /// <summary>
        /// Gets or sets human-read status of Logout
        /// </summary>
        public string Message { get; set; }    

        /// <summary>
        /// Gets or sets a reference to the root item in the hierarchy (e.g. for Expand request)
        /// </summary>
        public Item RootItem
        {
            get { return this.rootItem; }
            set { this.rootItem = value; }
        }

        /// <summary>
        /// Gets or sets all the items in the responce
        /// </summary>
        public List<Item> Items
        {
            get { return this.items; }
            set { this.items = value; }
        }

        /// <summary>
        /// Gets or sets all the Pdm messages in the responce
        /// </summary>
        public List<PdmMessage> PdmMessages
        {
            get { return this.pdmMessages; }
            set { this.pdmMessages = value; }
        }

        /// <summary>
        /// Gets or sets all the relations between items in the responce
        /// </summary>
        public List<Relation> Relations
        {
            get { return this.relations; }
            set { this.relations = value; }
        }
    }
}
