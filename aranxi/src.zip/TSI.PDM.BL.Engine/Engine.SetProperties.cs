﻿// -----------------------------------------------------------------------
// <copyright file="Engine.SetProperties.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.BL
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using TSI.PDM.DataStore;

    /// <summary>
    /// Engine part - prepares the hierarchical structure
    /// for dispaying in UpdateWindow and uploading to the ARAS server
    /// </summary>
    public partial class Engine
    {
#if DEBUG_WITH_CHEAT
        /// <summary>
        /// Only for UnitTests: Sets private "saved" flag
        /// </summary>
        /// <param name="value">flag value</param>
        public static void SetSaved(bool value)
        {
            saved = value;
        }
#endif

        /// <summary>
        /// set properties to the Items in the hierarchical structure (root)
        /// </summary>
        /// <param name="localRoot">the root of the NX hierarchical structure</param>
        /// <param name="selectedItems">selected Items</param>
        public static void SetProperties(
            Item localRoot,
            List<Item> selectedItems)
        {
            Message.Log("selectedItems ... " + selectedItems.Count);
            foreach (Item selectedItem in selectedItems)
            {
                Message.Log("selectedItem: " + selectedItem.item_number);
            }

            // set parent references and "selected" and "upload" flags
            SetParents(localRoot);
            SetStructureDescriptions(localRoot);
            SetSelectionsAndNeedToUpload(localRoot, selectedItems);

            // all items
            List<Item> localItems = new List<Item>();
            Item.GetAllItems(localRoot, localItems);

            if (saved)
            {
                Message.Log("user saved everything -> define if the files modified or up-to-date");

                // get modification state for all the items            
                MetaDataXmlFile uploadedFilesXml = new MetaDataXmlFile(Settings.Instance.UploadedFilesXml);
                uploadedFilesXml.Load();
                foreach (Item item in localItems)
                {
                    item.ItemModifyState = uploadedFilesXml.IsModifiedLocally(item) ?
                        Item.ModifyState.ChangedLocally :
                        Item.ModifyState.UpToDate;
                }
            }           

            // Select also parents of the selected Items. 
            foreach (Item item in localItems)
            {
                if (item.Selected && item.ItemModifyState != Item.ModifyState.UpToDate)
                {
                    SelectAllParents(item);
                }
            }

            Message.Log("Define new and deleted items");

            // query the root: does it exist or no?
            Backend.Instance.DoQueryItem(localRoot);

            if (localRoot.ItemServerState == Item.ServerState.Existing)
            {
                // the root exists - expand it and check:
                // if any items was deleted locally by user 
                // (in this case we need to delete them on server also)
                try
                {
                    Item serverRoot = Backend.Instance.DoExpand(localRoot);
                    CompareRoots(localRoot, serverRoot);

                    // Items, which have been newly added by user, may exist on server (test 09)
                    foreach (Item localItem in localItems)
                    {
                        if (localItem.ItemServerState == Item.ServerState.New)
                        {
                            Backend.Instance.DoQueryItem(localItem);
                        }
                    }
                }
                catch (ExceptionItemNotExpandable)
                {
                    // the root doesn't linked to any items on server - 
                    // but these items may exist on server (test 07)
                    foreach (Item localItem in localItems)
                    {
                        Backend.Instance.DoQueryItem(localItem);
                    }
                }
            }
            else
            {
                // the root doesn't exist on server - but may be its children exist (test 09)
                foreach (Item localItem in localItems)
                {
                    Backend.Instance.DoQueryItem(localItem);
                }
            }

            // set Skipped items
            foreach (Item item in localItems)
            {
                if (!item.Selected || 
                    item.ItemModifyState == Item.ModifyState.UpToDate ||
                    IsLockedByAnotherUser(item))
                {
                    item.ItemOperationState = Item.OperationState.Skip;
                }
            }

            foreach (Item item in localItems)
            {
                Message.Log("item : " + item.item_number +
                            " : " + item.ItemServerState +
                            " : " + item.ItemOperationState +
                            " : " + item.ItemModifyState);

                foreach (Item child in item.Children)
                {
                    Message.Log("child : " + child.item_number +
                        " : " + child.ItemServerState +
                        " : " + child.ItemOperationState +
                        " : " + child.ItemModifyState);
                }
            }
        }

        /// <summary>
        /// Compares two hierarchical structures, finding new, existing and deleted items
        /// </summary>
        /// <param name="localRoot">Root of the local structure</param>
        /// <param name="serverRoot">Root of the server structure</param>
        public static void CompareRoots(Item localRoot, Item serverRoot)
        {
            List<Item> localItems = new List<Item>();
            Item.GetAllItems(localRoot, localItems);

            // an item is New by default
            foreach (Item localItem in localItems)
            {
                localItem.ItemServerState = Item.ServerState.New;
                localItem.RelationServerState = Item.ServerState.New;
                localItem.ItemOperationState = Item.OperationState.Create;
            }
            
            List<Item> serverItems = new List<Item>();
            Item.GetAllItems(serverRoot, serverItems);

            // item is Existing if it is found on server and has the same parents
            foreach (Item localItem in localItems)
            {
                Item serverItem = serverItems.Find(i => i.item_number == localItem.item_number);

                if (serverItem == null)
                {
                    continue;
                }

                bool equal = true;
                CompareParents(localItem, serverItem, ref equal);

                if (equal)
                {
                    // Copy PDM attributes 
                    localItem.Copy(serverItem);

                    localItem.PwbIsCheckedOutBy = serverItem.PwbIsCheckedOutBy;
                    localItem.PwbFileObjectId = serverItem.PwbFileObjectId;

                    localItem.ItemServerState = Item.ServerState.Existing;
                    localItem.RelationServerState = Item.ServerState.Existing;
                    localItem.ItemOperationState = Item.OperationState.Update;

                    Message.Log("Item EXISTS: " + localItem.item_number);
                }
            }

            // If a server item absents locally, mark it as deleted
            MarkDeleted(localRoot, serverRoot);
        }

        /// <summary>
        /// Define parents of items
        /// </summary>
        /// <param name="item">an item</param>
        public static void SetParents(Item item)
        {
            // find each child recursively
            foreach (Item child in item.Children)
            {
                SetParents(child);
            }

            // initially item has no parent
            item.Parent = null;
            item.HasParent = false;

            foreach (Item child in item.Children)
            {
                child.Parent = item;
                child.HasParent = true;
            }
        }

        /// <summary>
        /// Checks if an item is locked by somebody, except the current user
        /// </summary>
        /// <param name="item">an item</param>
        /// <returns>true if locked</returns>
        private static bool IsLockedByAnotherUser(Item item)
        {
            return item.PwbIsCheckedOutBy != null &&
                   item.PwbIsCheckedOutBy.Length > 0 &&
                   item.PwbIsCheckedOutBy != Backend.Instance.GetUserName();
        }

        /// <summary>
        /// Compare parents of two items
        /// </summary>
        /// <param name="first">the first item</param>
        /// <param name="second">the second item</param>
        /// <param name="equal">the result</param>
        private static void CompareParents(Item first, Item second, ref bool equal)
        {
            if (first.Parent == null && second.Parent == null)
            {
                equal = true;
                return;
            }

            if ((first.Parent == null && second.Parent != null) ||
                (first.Parent != null && second.Parent == null) ||

                (first.Parent != null && second.Parent != null &&
                first.Parent.item_number != second.Parent.item_number))
            {
                equal = false;
                return;
            }

            // repeat for upper parents
            CompareParents(first.Parent, second.Parent, ref equal);
        }

        /// <summary>
        /// Marks items, which don't exist locally as "deleted"
        /// </summary>
        /// <param name="localAssembly">local Assembly</param>
        /// <param name="serverAssembly">server Assembly</param>
        private static void MarkDeleted(Item localAssembly, Item serverAssembly)
        {
            foreach (Item serverItem in serverAssembly.Children)
            {
                Item localItem = localAssembly.Children.ToList().Find(i => i.item_number == serverItem.item_number);

                if (localItem == null)
                {
                    serverItem.RelationServerState = Item.ServerState.ToDelete;
                    localAssembly.Children.Add(serverItem);
                }
            }

            // repeat for each not deleted assembly
            foreach (Item localItem in localAssembly.Children)
            {
                if (localItem.Class == Settings.Instance.CadAssembly &&
                    localItem.RelationServerState != Item.ServerState.ToDelete)
                {
                    Item serverItem = serverAssembly.Children.ToList().Find(i => i.item_number == localItem.item_number);

                    if (serverItem != null)
                    {
                        MarkDeleted(localItem, serverItem);
                    }
                }
            }
        }

        /// <summary>
        /// recursively find and select all parents of an item
        /// </summary>
        /// <param name="item">the item</param>
        private static void SelectAllParents(Item item)
        {
            if (item.Parent != null)
            {
                item.Parent.Selected = true;
                item.Parent.ItemModifyState = Item.ModifyState.ChangedLocally;
                SelectAllParents(item.Parent);
            }
        }

        /// <summary>
        /// Define PDM structure of items
        /// </summary>
        /// <param name="item">an item</param>
        private static void SetStructureDescriptions(Item item)
        {
            if (item.Parent == null)
            {
                item.Structure = "/";
            }

            // find each child recursively
            foreach (Item child in item.Children)
            {
                if (item.Parent == null)
                {
                    child.Structure += "/" + item.item_number;
                }
                else
                {
                    child.Structure += item.Structure + "/" + item.item_number;
                }

                SetStructureDescriptions(child);
            }
        }

        /// <summary>
        /// Set "Selected" flag for items
        /// </summary>
        /// <param name="item">an item</param>
        /// <param name="selectedItems">a list of selections from NX</param>
        private static void SetSelectionsAndNeedToUpload(Item item, List<Item> selectedItems)
        {
            // find each child recursively
            foreach (Item child in item.Children)
            {
                SetSelectionsAndNeedToUpload(child, selectedItems);
            }

            // initially item is not selected
            item.Selected = false;

            foreach (Item selectedItem in selectedItems)
            {
                if (selectedItem.item_number == item.item_number)
                {
                    item.Selected = true;
                    item.NeedToUploadFile = true;
                    item.Versioning = true; // TODO true/false depending on check-box

                    if (!saved)
                    {
                        Message.Log("item " + item.item_number + " not saved -> marked 'ChangedLocally'");
                        item.ItemModifyState = Item.ModifyState.ChangedLocally;
                    }
                }
            }
        }
    }
}
