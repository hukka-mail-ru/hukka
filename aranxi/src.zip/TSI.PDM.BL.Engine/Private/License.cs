// -----------------------------------------------------------------------
// <copyright file="License.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.BL
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using TSI.PDM.DataStore;
    using TSIPDMMnWrapper;

    /// <summary>
    /// Verification of the License
    /// </summary>
    internal class License
    {
        /// <summary>
        /// A helper: shows a human-read message
        /// </summary>
        /// <param name="moduleNumber">module number</param>
        /// <param name="rc">return code</param>
        /// <returns>true if it's a known error, false otherwise</returns>
        private static bool CheckLicmanRetCode(int moduleNumber, int rc)
        {
            switch (rc)
            {
                case 0:
                    Message.Log("License successfully allocated.");
                    return true;
                case 1:
                    Message.Log("No more licenses for this module available.");
                    return false;
                case 2:
                    Message.Log("License of this module has expired.");
                    return false;
                case 3:
                    Message.Log("Module not licensed.");
                    return false;
                case 4:
                    Message.Log("LLD-time abd GLD-time different.");
                    return false;
                case 5:
                    Message.Log("No connect to LLD.");
                    return false;
                case 6:
                    Message.Log("No connect to GLD.");
                    return false;
                default:
                    Message.Log("Unknown error.");
                    return false;
            }
        }

        /// <summary>
        /// Check the license
        /// </summary>
        public static void Check()
        {
            TSIPDMMnWrapper.Class1 licman = new TSIPDMMnWrapper.Class1();

            int retCode = licman.licenseInit_w();

            if (retCode != 0)
            {
                Message.Log("License init failed.");

                // Console.WriteLine("License init failed with return code: {0}", retCode);
                licman.licenseError_w(-1);
            }

            licman.licenseSetVendorKey_w("215A1BD8B1E1E22CB06FB3C");
            licman.licenseSetVerifyProc_w();

            int moduleNumber_RII = 1040;
            licman.licenseFree_w(moduleNumber_RII);
            retCode = licman.licenseAlloc_w(moduleNumber_RII);

            bool licRetCode = CheckLicmanRetCode(moduleNumber_RII, retCode);

            if (licRetCode != true)
            {
                // Throw exception
                throw new MyException("License allocation failed.");
            }
        }
    }
}
