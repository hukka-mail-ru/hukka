// -----------------------------------------------------------------------
// <copyright file="Engine.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.BL
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using NXOpen;
    using TSI.PDM.DataStore;
    using TSI.PDM.GUI;

    /// <summary>
    /// The FrontEnd: interact with NX
    /// </summary>
    public partial class Engine
    {
        /// <summary>
        /// True if all the files in the NX assembly are saved (before update)
        /// </summary>
        private static bool saved = false;

        /// <summary>
        /// Variable used in Startup() - represents Aranxi toolbar application
        /// </summary>
        private static Engine engine;

        /// <summary>
        /// Variable to control if NX is closed - used to add custom dispose code
        /// </summary>
        private static bool isDisposeCalled;

        /// <summary>
        /// NX session handler
        /// </summary>
        private static NXOpen.Session theSession;

        /// <summary>
        /// NX User Interface handler
        /// </summary>
        private static UI theUI;

        /// <summary>
        /// Variable to control license allocation
        /// </summary>
        private static bool isLicenseAllocated;

        /// <summary>
        /// Initializes a new instance of the <see cref="Engine" /> class.
        /// </summary>
        public Engine()
        {
            try
            {
                theSession = NXOpen.Session.GetSession();
                theUI = UI.GetUI();
                isLicenseAllocated = false;
                isDisposeCalled = false;
            }
            catch (NXOpen.NXException)
            {
                // ---- Enter your exception handling code here -----
                // Message.Show(ex);
            }
        }

        /// <summary>
        /// Executed when the application is entered. It's used to initialize the application's data.
        /// </summary>
        /// <returns>Error code: 0 - no errors</returns>
        public static int ApplicationInit()
        {
            return 0;
        }

        /// <summary>
        /// Executed when the application is selected (activated) from the pulldown menu.
        /// </summary>
        /// <returns>Error code: 0 - no errors</returns>
        public static int ApplicationEnter()
        {
            return 0;
        }

        /// <summary>
        /// Executed when the application is exited. It's used to free (clean up) the application's data.
        /// </summary>
        /// <returns>Error code: 0 - no errors</returns>
        public static int ApplicationExit()
        {
            return 0;
        }

        /// <summary>
        /// Checks license and set the flag
        /// </summary>
        public static void CheckLicense()
        {
            License.Check();
            isLicenseAllocated = true;
        }

        /// <summary>
        /// "Login" user command
        /// </summary>
        /// <param name="buttonEvent">Event object for menu buttons</param>
        /// <returns>Value for action callbacks</returns>
        public static NXOpen.MenuBar.MenuBarManager.CallbackStatus Login(NXOpen.MenuBar.MenuButtonEvent buttonEvent)
        {
            try
            {
                if (isLicenseAllocated)
                {
                    GUI.Toolbar.Instance.ShowLoginWindow();
                }
                else
                {
                    CheckLicense();
                }
            }
            catch (Exception ex)
            {
                Message.Show(ex);
            }

            return NXOpen.MenuBar.MenuBarManager.CallbackStatus.Continue;
        }

        /// <summary>
        /// "Logout" user command
        /// </summary>
        /// <param name="buttonEvent">button Event</param>
        /// <returns>Callback Status</returns>
        public static NXOpen.MenuBar.MenuBarManager.CallbackStatus Logout(NXOpen.MenuBar.MenuButtonEvent buttonEvent)
        {
            try
            {
                Backend.Instance.DoLogout();
            }
            catch (Exception ex)
            {
                Message.Show(ex);
            }
            return NXOpen.MenuBar.MenuBarManager.CallbackStatus.Continue;
        }

        /// <summary>
        /// "Query" user command
        /// </summary>
        /// <param name="buttonEvent">Event object for menu buttons</param>
        /// <returns>Value for action callbacks</returns>
        public static NXOpen.MenuBar.MenuBarManager.CallbackStatus Query(NXOpen.MenuBar.MenuButtonEvent buttonEvent)
        {
            try
            {
                if (isLicenseAllocated)
                {
                    GUI.Toolbar.Instance.ShowQueryWindow();
                }
                else
                {
                    CheckLicense();
                }
            }
            catch (Exception ex)
            {
                Message.Show(ex);
            }
            
            return NXOpen.MenuBar.MenuBarManager.CallbackStatus.Continue;
        }

        /// <summary>
        /// "CreateFile" user command
        /// </summary>
        /// <param name="buttonEvent">Event object for menu buttons</param>
        /// <returns>Value for action callbacks</returns>
        public static NXOpen.MenuBar.MenuBarManager.CallbackStatus CreateFile(NXOpen.MenuBar.MenuButtonEvent buttonEvent)
        {
            try
            {
                if (isLicenseAllocated)
                {
                    GUI.Toolbar.Instance.ShowCreateWindow();
                }
                else
                {
                    CheckLicense();
                }
            }
            catch (Exception ex)
            {
                Message.Show(ex);
            }
            
            return NXOpen.MenuBar.MenuBarManager.CallbackStatus.Continue;
        }

        /// <summary>
        /// "Update" user command
        /// </summary>
        /// <param name="buttonEvent">Event object for menu buttons</param>
        /// <returns>Value for action callbacks</returns>
        public static NXOpen.MenuBar.MenuBarManager.CallbackStatus Update(NXOpen.MenuBar.MenuButtonEvent buttonEvent)
        {
            try
            {
                if (isLicenseAllocated)
                {
                    // ARANXI-92: check if there are unsaved (modified) parts
                    List<Item> selectedItems = GetModifiedItems();

                    // Set "saved" flag
                    if (selectedItems.Count > 0)
                    {
                        // Unsaved items are already in selectedItems
                        saved = false;
                    }
                    else
                    {
                        saved = true;

                        // Put all displayed parts into selectedItems
                        selectedItems = GetAllItems();
                    }

                    // Get the whole assembly tree from NX displayed part
                    Item root = GetRootAssemblyStructure();

                    // Prepare root before sending it to the UpdateWindow
                    SetProperties(root, selectedItems);

                    // Show UI and proceed
                    GUI.Toolbar.Instance.ShowUpdateWindow(root, saved);
                }
                else
                {
                    CheckLicense();
                }
            }
            catch (Exception ex)
            {
                Message.Show(ex);
            }

            return NXOpen.MenuBar.MenuBarManager.CallbackStatus.Continue;
        }

        /// <summary>
        /// "Lock" user command
        /// </summary>
        /// <param name="buttonEvent">Event object for menu buttons</param>
        /// <returns>Value for action callbacks</returns>
        public static NXOpen.MenuBar.MenuBarManager.CallbackStatus Lock(NXOpen.MenuBar.MenuButtonEvent buttonEvent)
        {
            try
            {
                if (isLicenseAllocated)
                {
                    LockUnlockSelectedItems(true);
                }
                else
                {
                    CheckLicense();
                }
            }
            catch (Exception ex)
            {
                Message.Show(ex);
            }

            return NXOpen.MenuBar.MenuBarManager.CallbackStatus.Continue;
        }

        /// <summary>
        /// "Unlock" user command
        /// </summary>
        /// <param name="buttonEvent">Event object for menu buttons</param>
        /// <returns>Value for action callbacks</returns>
        public static NXOpen.MenuBar.MenuBarManager.CallbackStatus Unlock(NXOpen.MenuBar.MenuButtonEvent buttonEvent)
        {
            try
            {
                if (isLicenseAllocated)
                {
                    LockUnlockSelectedItems(false);
                }
                else
                {
                    CheckLicense();
                }
            }
            catch (Exception ex)
            {
                Message.Show(ex);
            }

            return NXOpen.MenuBar.MenuBarManager.CallbackStatus.Continue;
        }

        /// <summary>
        /// "About" user command 
        /// </summary>
        /// <param name="buttonEvent">Event object for menu buttons</param>
        /// <returns>Value for action callbacks</returns>
        public static NXOpen.MenuBar.MenuBarManager.CallbackStatus About(NXOpen.MenuBar.MenuButtonEvent buttonEvent)
        {
            try
            {
                GUI.Toolbar.Instance.ShowAboutWindow();
            }
            catch (Exception ex)
            {
                Message.Show(ex);
            }

            return NXOpen.MenuBar.MenuBarManager.CallbackStatus.Continue;
        }

        /// <summary>
        /// This entry point activates the application at NX startup.
        /// </summary>
        /// <returns>Error code: 0 - no errors</returns>
        public static int Startup()
        {
            int retValue = 0;
            try
            {
                engine = new Engine();

                if (theSession == null) 
                {
                    theSession = NXOpen.Session.GetSession(); 
                }

                /*
                theUI.MenuBarManager.RegisterApplication("PDM_WORKBENCH_APP",
                    new NXOpen.MenuBar.MenuBarManager.InitializeMenuApplication(Program.ApplicationInit),
                    new NXOpen.MenuBar.MenuBarManager.EnterMenuApplication(Program.ApplicationEnter),
                    new NXOpen.MenuBar.MenuBarManager.ExitMenuApplication(Program.ApplicationExit), true, true, true);
                */

                theUI.MenuBarManager.AddMenuAction("BL_login", new NXOpen.MenuBar.MenuBarManager.ActionCallback(Engine.Login));
                theUI.MenuBarManager.AddMenuAction("BL_logout", new NXOpen.MenuBar.MenuBarManager.ActionCallback(Engine.Logout));
                theUI.MenuBarManager.AddMenuAction("BL_query", new NXOpen.MenuBar.MenuBarManager.ActionCallback(Engine.Query));
                theUI.MenuBarManager.AddMenuAction("BL_createfile", new NXOpen.MenuBar.MenuBarManager.ActionCallback(Engine.CreateFile));
                theUI.MenuBarManager.AddMenuAction("BL_update", new NXOpen.MenuBar.MenuBarManager.ActionCallback(Engine.Update));
                theUI.MenuBarManager.AddMenuAction("BL_lock", new NXOpen.MenuBar.MenuBarManager.ActionCallback(Engine.Lock));
                theUI.MenuBarManager.AddMenuAction("BL_unlock", new NXOpen.MenuBar.MenuBarManager.ActionCallback(Engine.Unlock));
                theUI.MenuBarManager.AddMenuAction("BL_about", new NXOpen.MenuBar.MenuBarManager.ActionCallback(Engine.About));

                License.Check();
                isLicenseAllocated = true;
            }
            catch (NXOpen.NXException)
            {
                // ---- Enter your exception handling code here -----
                // Message.Show(ex);
            }

            return retValue;
        }

        /// <summary>
        /// Unloads the image when the NX session terminates.
        /// </summary>
        /// <param name="arg">Command line arguments</param>
        /// <returns>Error code: 0 - no errors</returns>
        public static int GetUnloadOption(string arg)
        {
            // Unloads the image when the NX session terminates
            return System.Convert.ToInt32(NXOpen.Session.LibraryUnloadOption.AtTermination);
        }

        /// <summary>
        /// Disposes all the class members.
        /// </summary>
        public void Dispose()
        {
            try
            {
                if (isDisposeCalled == false)
                {
                    // TODO: Add your application code here 
                }

                isDisposeCalled = true;
            }
            catch (NXOpen.NXException)
            {
                // ---- Enter your exception handling code here -----
                // Message.Show(ex);
            }
        }

        /// <summary>
        /// Function does lock or unlock based on doLock argument.
        /// </summary>
        /// <param name="doLock">true - do lock, false - do unlock</param>
        private static void LockUnlockSelectedItems(bool doLock)
        {
            Selection selection = theUI.SelectionManager;
            int selCount = selection.GetNumSelectedObjects();

            System.Collections.Specialized.StringCollection typesToSelect = new System.Collections.Specialized.StringCollection() { "NXOpen.Assemblies.Component", "NXOpen.Assemblies.ComponentAssembly" };

            string exceptions = string.Empty;

            if (selCount <= 0)
            {
                throw new MyException("No items were selected.");
            }
            else
            {
                for (int i = 0; i < selCount; i++)
                {
                    if (typesToSelect.Contains(selection.GetSelectedTaggedObject(i).GetType().ToString()))
                    {
                        if ("NXOpen.Assemblies.ComponentAssembly" == selection.GetSelectedTaggedObject(i).GetType().ToString())
                        {
                            NXOpen.Assemblies.ComponentAssembly cass = (NXOpen.Assemblies.ComponentAssembly)selection.GetSelectedTaggedObject(i);
                            if (cass.RootComponent != null)
                            {
                                if (!cass.IsOccurrence)
                                {
                                    BasePart basePart = cass.OwningPart;
                                    Item item = new Item
                                    {
                                        item_number = basePart.Leaf,
                                        Class = Settings.Instance.CadAssembly
                                    };

                                    // ARANXI-87: list of errors
                                    try
                                    {
                                        GUI.Toolbar.Instance.OnLockUnlockButton(item, doLock);
                                    }
                                    catch (Exception ex)
                                    {
                                        exceptions += ex.Message + ": " + item.item_number + "\n";
                                    }
                                }
                            }
                            else
                            {
                                BasePart basePart = cass.OwningPart;
                                Item item = new Item
                                {
                                    item_number = basePart.Leaf,
                                    Class = Settings.Instance.CadPart
                                };

                                // ARANXI-87: list of errors
                                try
                                {
                                    GUI.Toolbar.Instance.OnLockUnlockButton(item, doLock);
                                }
                                catch (Exception ex)
                                {
                                    exceptions += ex.Message + ": " + item.item_number + "\n";
                                }
                            }
                        }

                        if ("NXOpen.Assemblies.Component" == selection.GetSelectedTaggedObject(i).GetType().ToString())
                        {
                            NXOpen.Assemblies.Component c = (NXOpen.Assemblies.Component)selection.GetSelectedTaggedObject(i);
                            NXOpen.Assemblies.Component[] subassemblyParts = c.GetChildren();

                            Item item = new Item();
                            item.item_number = c.DisplayName;

                            if (subassemblyParts.Length > 0)
                            {
                                item.Class = Settings.Instance.CadAssembly;

                                // ARANXI-87: list of errors
                                try
                                {
                                    GUI.Toolbar.Instance.OnLockUnlockButton(item, doLock);
                                }
                                catch (Exception ex)
                                {
                                    exceptions += ex.Message + ": " + item.item_number + "\n";
                                }
                            }
                            else
                            {
                                item.Class = Settings.Instance.CadPart;

                                // ARANXI-87: list of errors
                                try
                                {
                                    GUI.Toolbar.Instance.OnLockUnlockButton(item, doLock);
                                }
                                catch (Exception ex)
                                {
                                    exceptions += ex.Message + ": " + item.item_number + "\n";
                                }
                            }
                        }
                    }
                }
            }

            // ARANXI-87: list of errors
            if (exceptions != string.Empty)
            {
                Message.Show(exceptions);
            }
        }

        /// <summary>
        /// Function checks for modified parts in displayed assembly and put them into array.
        /// </summary>
        /// <param name="root">Root component</param>
        /// <param name="modifiedComponents">Array of modified components</param>
        private static void GetModifiedComponents(NXOpen.Assemblies.Component root, List<NXOpen.Assemblies.Component> modifiedComponents)
        {
            NXOpen.UF.UFSession ufs = NXOpen.UF.UFSession.GetUFSession();

            foreach (NXOpen.Assemblies.Component c in root.GetChildren())
            {
                NXOpen.BasePart part = (BasePart)c.Prototype;
                if (ufs.Part.IsModified(part.Tag))
                {
                    modifiedComponents.Add(c);
                }
                GetModifiedComponents(c, modifiedComponents);
            }
        }

        /// <summary>
        /// Function which returns array of all modified items in displayed part.
        /// </summary>
        /// <returns>Array of modified items (assemblies, sub-assemblies and parts)</returns>
        private static List<Item> GetModifiedItems()
        {
            List<Item> modifiedItems = new List<Item>();

            PartCollection partCollection = theSession.Parts;
            Part displayPart = partCollection.Display;

            NXOpen.Assemblies.ComponentAssembly cass = displayPart.ComponentAssembly;

            //=================================================================
            // Root assembly with children
            //=================================================================
            if (cass.RootComponent != null)
            {
                NXOpen.Assemblies.Component comp = cass.RootComponent;

                //-------------------------------------------------------------
                // Create a list of all modified parts
                //-------------------------------------------------------------
                List<NXOpen.BasePart> modifiedParts = new List<BasePart>();
                List<NXOpen.Assemblies.Component> modifiedComponents = new List<NXOpen.Assemblies.Component>();

                NXOpen.UF.UFSession ufs = NXOpen.UF.UFSession.GetUFSession();
                NXOpen.BasePart part = (BasePart)comp.Prototype;
                if (ufs.Part.IsModified(part.Tag))
                {
                    modifiedComponents.Add(comp);
                }

                GetModifiedComponents(comp, modifiedComponents);

                foreach (NXOpen.Assemblies.Component c in modifiedComponents)
                {
                    Item item = new Item();
                    item.item_number = c.DisplayName;
                    if (c.GetChildren().Length > 0)
                    {
                        item.Class = Settings.Instance.CadAssembly;
                    }
                    else
                    {
                        item.Class = Settings.Instance.CadPart;
                    }

                    modifiedItems.Add(item);
                }
            }
            //=================================================================
            // One-part assembly
            //=================================================================
            else
            {
                NXOpen.BasePart part = (NXOpen.BasePart)cass.OwningPart;
                NXOpen.Assemblies.Component comp = cass.RootComponent;
                NXOpen.UF.UFSession ufs = NXOpen.UF.UFSession.GetUFSession();
                if (ufs.Part.IsModified(part.Tag))
                {
                    Item item = new Item();
                    item.item_number = cass.OwningPart.Leaf;
                    item.Class = Settings.Instance.CadPart;
                    modifiedItems.Add(item);
                }
            }

            return modifiedItems;
        }

        /// <summary>
        /// Function builds tree structure of selected assembly.
        /// </summary>
        /// <param name="item">Root assembly item</param>
        /// <param name="rootComponent">Root assembly component</param>
        private static void BuiltTree(Item item, NXOpen.Assemblies.Component rootComponent)
        {
            foreach (NXOpen.Assemblies.Component c in rootComponent.GetChildren())
            {
                Item child = new Item();
                child.item_number = c.DisplayName;
                if (c.GetChildren().Length > 0)
                {
                    child.Class = Settings.Instance.CadAssembly;
                }
                else
                {
                    child.Class = Settings.Instance.CadPart;
                }

                item.Children.Add(child);
                BuiltTree(child, c);
            }
        }

        /// <summary>
        /// Function builds tree structure of selected assembly and returns root assembly as an Item.
        /// </summary>
        /// <returns>Root assembly</returns>
        private static Item GetRootAssemblyStructure()
        {
            // Build tree
            Item tree = new Item();
            bool isTreeBuilt = false;

            PartCollection partCollection = theSession.Parts;
            Part displayPart = partCollection.Display;

            NXOpen.Assemblies.ComponentAssembly cass = displayPart.ComponentAssembly;

            //=================================================================
            // Root assembly with children
            //=================================================================
            if (cass.RootComponent != null)
            {
                NXOpen.Assemblies.Component rootComponent = cass.RootComponent;

                if (rootComponent.GetChildren().Length > 0)
                {
                    tree.item_number = rootComponent.DisplayName;
                    tree.Class = Settings.Instance.CadAssembly;

                    if (!isTreeBuilt)
                    {
                        BuiltTree(tree, rootComponent);
                        isTreeBuilt = true;
                    }
                }
            }
            //=================================================================
            // One-part assembly
            //=================================================================
            else
            {
                if (!cass.IsOccurrence)
                {
                    BasePart part = cass.OwningPart;
                    tree.item_number = part.Leaf;
                    tree.Class = Settings.Instance.CadPart;
                }
            }

            return tree;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="root"></param>
        /// <param name="allComponents"></param>
        private static void GetAllComponents(NXOpen.Assemblies.Component root, List<NXOpen.Assemblies.Component> allComponents)
        {
            foreach (NXOpen.Assemblies.Component c in root.GetChildren())
            {
                NXOpen.BasePart part = (BasePart)c.Prototype;
                allComponents.Add(c);
                GetAllComponents(c, allComponents);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private static List<Item> GetAllItems()
        {
            List<Item> allItems = new List<Item>();

            PartCollection partCollection = theSession.Parts;
            Part displayPart = partCollection.Display;

            NXOpen.Assemblies.ComponentAssembly cass = displayPart.ComponentAssembly;

            //=================================================================
            // Root assembly with children
            //=================================================================
            if (cass.RootComponent != null)
            {
                List<NXOpen.Assemblies.Component> allComponents = new List<NXOpen.Assemblies.Component>();
                NXOpen.Assemblies.Component comp = cass.RootComponent;
                allComponents.Add(comp);
                GetAllComponents(comp, allComponents);

                foreach (NXOpen.Assemblies.Component c in allComponents)
                {
                    Item item = new Item();
                    item.item_number = c.DisplayName;
                    if (c.GetChildren().Length > 0)
                    {
                        item.Class = Settings.Instance.CadAssembly;
                    }
                    else
                    {
                        item.Class = Settings.Instance.CadPart;
                    }

                    allItems.Add(item);
                }
            }
            //=================================================================
            // One-part assembly
            //=================================================================
            else
            {
                NXOpen.Assemblies.Component comp = cass.RootComponent;

                Item item = new Item();
                item.item_number = cass.OwningPart.Leaf;
                item.Class = Settings.Instance.CadPart;
                allItems.Add(item);
            }

            return allItems;
        }
    }
}