// -----------------------------------------------------------------------
// <copyright file="Backend.LoadSingleFile.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.BL
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Load a file
    /// </summary>
    public partial class Backend
    {
        /// <summary>
        /// Represents the file DownloadedFiles.xml
        /// </summary> 
        private MetaDataXmlFile downloadedFilesXml = new MetaDataXmlFile(Settings.Instance.DownloadedFilesXml);

        /// <summary>
        /// A status of file download
        /// </summary> 
        public enum DownloadStatus
        {
            /// <summary>
            /// File was not downloaded
            /// </summary> 
            NotDownloaded,

            /// <summary>
            /// File was downloaded
            /// </summary> 
            Downloaded
        }

        /// <summary>
        /// Download a file from ARAS server (corresponding to a given item).
        /// Open the file in NX if needed.
        /// </summary>
        /// <param name="item">the item</param>
        /// <param name="showInNX">true if it's needed to open the file in NX</param>
        /// <param name="ask">true if it's needed to ask use to load the file</param>
        /// <returns>A status of the download operation</returns>
        public DownloadStatus DoLoadSingleFile(Item item, bool showInNX, bool ask)
        {
            // TODO temporary all files are in XmapDir
            item.FolderName = Settings.Instance.XmapDir;

            Message.Log("item.NativeFile " + item.NativeFile);
            Message.Log("item.LocalDir " + item.FolderName);
            Message.Log("item.modified_on " + item.ModifiedOn);

            if (item.NativeFile == null)
            {
                throw new MyException("The CAD document has no native file");
            }

            DownloadStatus res = DownloadStatus.NotDownloaded;

            this.downloadedFilesXml.Load();

            // don't ask anything if the file does not exist
            if (!File.Exists(item.GetFullLocalFileName(Settings.Instance.XmapDir)))
            {
                ask = false;
            }

            if (this.downloadedFilesXml.IsModifiedLocally(item) ||
                this.downloadedFilesXml.IsModifiedOnServer(item))
            {
                if (!ask || 
                   (ask && Message.Question("Do you want to load the last server version of " +
                                             item.NativeFile + " ?")))
                {
                    res = this.Download(item);
                }
            }

            if (showInNX)
            {
                if (this.CheckFileOpenInNX(item))
                {
                    this.ShowFileInNX(item);
                    this.ReopenFileInNX();
                }
                else
                {
                    this.OpenFileInNX(item);
                }
            }

            return res;
        }

        /// <summary>
        /// Download file and update DownloadedFiles.xml
        /// </summary>  
        /// <param name="item">a file to download</param>
        /// <returns>
        /// A status of the download operation 
        /// </returns>
        private DownloadStatus Download(Item item)
        {
            // Invoke Client.DownloadFile
            Credentials cred = this.session.GetCurrentCredentials();

            this.client.DownloadFile(cred, item);

            // Add the file to DownloadedFiles.xml
            this.downloadedFilesXml.AddEntry(new MetaDataEntry()
                {
                    Name = item.NativeFile,
                    LocalModificationTime = MetaDataEntry.GetCurrentLocalModificationTime(item.FolderName, item.NativeFile),
                    ServerModificationTime = item.ModifiedOn
                }

            );

            this.downloadedFilesXml.Save(); 

            return DownloadStatus.Downloaded;
        }

        /// <summary>
        /// open file  in the NX-session.
        /// </summary>  
        /// <param name="item">a file to open</param>
        private void OpenFileInNX(Item item)
        {
            if (Settings.Instance.UnitTest)
            {
                return;
            }

            string path = Path.Combine(item.FolderName, item.NativeFile);
            if (!File.Exists(path))
            {
                return;
            }

            NXOpen.Session theSession = NXOpen.Session.GetSession();
            NXOpen.PartLoadStatus status;
            theSession.Parts.OpenBaseDisplay(path, out status);

            // ARANXI-66 (if wrong file - throw exception)
            if (status.NumberUnloadedParts > 0)
            {
                throw new MyException("The file " + item.NativeFile + " from the folder '" + item.FolderName + "' can't be opened with NX.");
                /*
                for (int i = 0; i < status.NumberUnloadedParts; i++)
                {
                    // throw new MyException("Cannot open file " + status.GetPartName(i));
                    throw new MyException("The file " + item.native_file + " from the folder '" + item.FolderName + "' can't be opened with NX.");
                }
                */
            }
        }

        /// <summary>
        /// show opened file  in the NX-session.
        /// </summary>  
        /// <param name="item">a file to show</param>
        private void ShowFileInNX(Item item)
        {
            if (Settings.Instance.UnitTest)
            {
                return;
            }

            NXOpen.Session theSession = NXOpen.Session.GetSession();
            NXOpen.PartCollection parts = theSession.Parts;

            foreach (NXOpen.Part p in parts)
            {
                if (item.NativeFile == Path.GetFileName(p.FullPath))
                {
                    NXOpen.PartLoadStatus status;
                    parts.SetDisplay(p, false, false, out status);
                    break;
                }
            }
        }

        /// <summary>
        /// Re-reads the current open file from hard drive
        /// </summary>  
        private void ReopenFileInNX()
        {
            if (Settings.Instance.UnitTest)
            {
                return;
            }

            NXOpen.Session theSession = NXOpen.Session.GetSession();
            NXOpen.PartCollection parts = theSession.Parts;
            NXOpen.Part part = parts.Work;
            NXOpen.PartReopenReport rep;
            part.Reopen(NXOpen.BasePart.CloseWholeTree.True, NXOpen.BasePart.CloseModified.DontCloseModified, null, out rep);
        }

        /// <summary>
        /// Check if file is already open in NX
        /// </summary>  
        /// <param name="item">a file to check</param>
        /// <returns>True if the file is open</returns> 
        private bool CheckFileOpenInNX(Item item)
        {
            if (Settings.Instance.UnitTest)
            {
                return false;
            }

            NXOpen.Session theSession = NXOpen.Session.GetSession();
            NXOpen.PartCollection parts = theSession.Parts;
            bool isFileInNX = false;

            foreach (NXOpen.Part p in parts)
            {
                if (item.NativeFile == Path.GetFileName(p.FullPath))
                {
                    isFileInNX = true;
                }
            }

            return isFileInNX;
        }
    }
}
