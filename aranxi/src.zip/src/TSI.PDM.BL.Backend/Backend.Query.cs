// -----------------------------------------------------------------------
// <copyright file="Backend.Query.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.BL
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Query an item
    /// </summary>
    public partial class Backend
    {
        /// <summary>
        /// Finds items matching the criteria.
        /// </summary>
        /// <param name="criteria">the criteria</param>
        /// <returns>a list of items matching the query</returns>
        public List<Item> DoFindItems(Item criteria)
        {
            // Check of Aras-NX-Integration license. In case there is no license show error and abort.
            Message.Log("criteria: " + criteria.ItemNumber);

            // Check that a Aras-session is existing.
            if (!this.session.IsSessionOpen())
            {
                throw new MyException("Session is not open.");
            }

            // NX-User defines the search criteria.
            // Query-button starts the search on the Aras Innovator database. When the result is received it is shown in the dialog. Till receiving the data the NX-dialog �Work in progress� is shown. See also chapter 3.1.4 with some additional remarks on the dialog functions.

            // get credentials of current session
            Credentials cred = this.session.GetCurrentCredentials();

            // perform command
            Response response = this.client.Query(cred, criteria);

            return response.Items;
        }

        /// <summary>
        /// Gets the item properties.
        /// Memorize the result in the item itself
        /// </summary>
        /// <param name="item">the item</param>
        public void DoQueryItem(Item item)
        {                      
            //////////////////////////////
            ////  QUERY
            //////////////////////////////
            Message.Log("Item: " + item.ItemNumber + " " + item.Class);

            // Check that a Aras-session is existing.
            if (!this.session.IsSessionOpen())
            {
                throw new MyException("Session is not open.");
            }

            // get credentials of current session
            Credentials cred = this.session.GetCurrentCredentials();

            // perform command
            Response res = this.client.QueryItemByName(cred, item);

            //////////////////////////////
            ////  QUERY RESULT
            //////////////////////////////

            // Check that all selected items are yet existing in Aras. 
            if (res.Items.Count < 1)
            {
                item.ItemServerState = Item.ServerState.New;
                item.RelationServerState = Item.ServerState.New;
                item.ItemOperationState = Item.OperationState.Create;

                Message.Log("Query res: " + item.ItemNumber +
                    " NOT FOUND (marked as NEW). Class=" + item.Class);

                this.CheckClassChanged(item);
            }
            else
            {
                // Copy PDM attributes from res.RootItem
                item.Copy(res.RootItem);
                
                item.PwbIsCheckedOutBy  = res.RootItem.PwbIsCheckedOutBy;
                item.PwbFileObjectId    = res.RootItem.PwbFileObjectId;

                item.ItemServerState = Item.ServerState.Existing;
                item.RelationServerState = Item.ServerState.Existing;
                item.ItemOperationState = Item.OperationState.Update;

                Message.Log("Query res: " + item.ItemNumber + " EXISTS. Class=" + item.Class);
            }
        }

        /// <summary>
        /// Check if an item of another class with the same name exist on server.
        /// Throws an exception if so.
        /// </summary>
        /// <param name="item">the item</param>
        private void CheckClassChanged(Item item)
        {                       
            if (item.Class == Settings.Instance.CadAssembly)
            {
                this.CheckClassEquality(item, Settings.Instance.CadPart);
                this.CheckClassEquality(item, Settings.Instance.CadDrawing);
            }
            else if (item.Class == Settings.Instance.CadPart)
            {
                this.ChangeClassIfNotEqual(item, Settings.Instance.CadAssembly);
                this.ChangeClassIfNotEqual(item, Settings.Instance.CadDrawing);
            }
        }

        /// <summary>
        /// if an item exists on server as Cad/Part we must show an error/warning
        /// </summary>
        /// <param name="item">the item</param>
        /// <param name="classOnServer">class of the item on server with the same item_number</param>
        private void CheckClassEquality(Item item, string classOnServer)
        {
            Credentials cred = this.session.GetCurrentCredentials();

            Response res = this.client.QueryItemByName(cred,
                new Item
                {
                    ItemNumber = item.ItemNumber,
                    Class = classOnServer
                });

            if (res.Items.Count > 0)
            {
                throw new ExceptionItemNameNotUnique(item);
            }
        }

        /// <summary>
        ///  if an item exists on server as Cad/Assembly (or Cad/Drawing), 
        ///  it should remain Cad/Assembly (or Cad/Drawing)
        /// </summary>
        /// <param name="item">the item</param>
        /// <param name="classOnServer">class of the item on server with the same item_number</param>
        private void ChangeClassIfNotEqual(Item item, string classOnServer)
        {
            Credentials cred = this.session.GetCurrentCredentials();

            // if an item exists on server as Cad/Assembly, it should remain Cad/Assembly 
            Response res = this.client.QueryItemByName(cred,
                new Item
                {
                    ItemNumber = item.ItemNumber,
                    Class = classOnServer
                });

            if (res.Items.Count > 0)
            {
                Message.Log("Class of " + item.ItemNumber + " is " + classOnServer + " on server => change its class to " + classOnServer);
                item.Class = classOnServer;
                this.DoQueryItem(item);
            }
        }
    }
}
