// -----------------------------------------------------------------------
// <copyright file="Backend.Expand.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.BL
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Expand a structure
    /// </summary>
    public partial class Backend
    {
        /// <summary>
        /// Expand an assembly 
        /// (retrieve all its childs and place a hierarchy of them into Response.Items)
        /// </summary>
        /// <param name="item">the item to expand</param>
        /// <returns>the expanded item (which contains children)</returns>     
        public Item DoExpand(Item item)
        {
            Credentials cred = this.session.GetCurrentCredentials();

            Response response = this.client.MultiExpand(cred, item);

            // bind Items together, depending on their relations
            foreach (Relation r in response.Relations)
            {
                Item parent = response.Items.Find(i => i.ItemNumber == r.SourceId);
                Item child = response.Items.Find(i => i.ItemNumber == r.RelatedId);

                child.RelationToParent = new Relation()
                {
                    Left = r.Left,
                    Right = r.Right,
                    OBID = r.OBID,
                    Class = r.Class
                };

                child.HasParent = true;
                child.Parent = parent;
                parent.Children.Add(child);
            }

            // Find the root of in the hierarchy of Items. 
            foreach (Item resItem in response.Items)
            {
                if (!resItem.HasParent)
                {
                    response.RootItem = resItem;
                    break;
                }
            }

            if (response.RootItem == null)
            {
                Message.Log("Expand res: " + item.ItemNumber + " has 0 children");
                throw new ExceptionItemNotExpandable(item);
            }
            else
            {
                Message.Log("Expand res: " + item.ItemNumber + " has "
                          + response.RootItem.Children.Count + " children");
            }
          
            /*
            foreach (Item resitem in response.Items)
            {
                Message.Log(" item " + resitem.item_number +
                    ". HasParent: " + resitem.HasParent + " Children: " + resitem.Children.Count);
            }*/
            
            return response.RootItem;
        }
    }
}
