// -----------------------------------------------------------------------
// <copyright file="Backend.Lock.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.BL
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Lock/Unlock an item
    /// </summary>
    public partial class Backend
    {
        /// <summary>
        /// Lock/Unlock an item
        /// </summary>
        /// <param name="item">the item</param>
        /// <param name="dolock">True if the lock is needed, false if unlock</param>
        public void DoLockUnlock(Item item, bool dolock)
        {
            DoQueryItem(item);
            
            if (item.ItemServerState == Item.ServerState.New)
            {
                throw new ExceptionItemNotFound(item);
            }
          
            Credentials cred = this.session.GetCurrentCredentials();
            Response response = this.client.LockUnlock(cred, item, dolock);
        }
    }
}
