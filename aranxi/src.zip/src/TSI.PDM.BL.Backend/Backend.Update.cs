// -----------------------------------------------------------------------
// <copyright file="Backend.Update.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.BL
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Update an item or a hierarchical structure
    /// </summary>
    public partial class Backend
    {
        /// <summary>
        /// Represents the file UploadedFiles.xml
        /// </summary> 
        private MetaDataXmlFile uploadedFilesXml = new MetaDataXmlFile(Settings.Instance.UploadedFilesXml);

        /// <summary>
        /// Handles any item  event 
        /// </summary>
        /// <param name="item">the item</param>
        public delegate void EventHandler(Item item);

        /// <summary>
        /// An event "Item updated"
        /// </summary>
        public event EventHandler EventItemSynchronized;

        /// <summary>
        /// Function which performs save before update
        /// </summary>
        /// <param name="dir">directory for saved files</param>
        public void SaveBeforeUpdate(string dir)
        {
            ///////////////////////////////////////////////////////////////////
            // Get displayed part
            ///////////////////////////////////////////////////////////////////
            NXOpen.Session theSession = NXOpen.Session.GetSession();
            NXOpen.PartCollection partCollection = theSession.Parts;
            NXOpen.Part displayPart = partCollection.Display;

            NXOpen.Assemblies.ComponentAssembly cass = displayPart.ComponentAssembly;

            ///////////////////////////////////////////////////////////////////
            // Root assembly with children
            ///////////////////////////////////////////////////////////////////
            if (cass.RootComponent != null)
            {
                NXOpen.Assemblies.Component comp = cass.RootComponent;

                ///////////////////////////////////////////////////////////////
                // Create a list of all modified parts
                ///////////////////////////////////////////////////////////////
                List<NXOpen.BasePart> modifiedParts = new List<NXOpen.BasePart>();

                NXOpen.UF.UFSession ufs = NXOpen.UF.UFSession.GetUFSession();
                NXOpen.BasePart part = (NXOpen.BasePart)comp.Prototype;
                if (ufs.Part.IsModified(part.Tag))
                {
                    modifiedParts.Add(part);
                }

                GetModifiedParts(comp, modifiedParts);

                // NX saves from bottom to top - reverse them in array
                modifiedParts.Reverse();

                ///////////////////////////////////////////////////////////////
                // Save all modified files
                ///////////////////////////////////////////////////////////////
                foreach (NXOpen.BasePart p in modifiedParts)
                {
                    NXOpen.PartSaveStatus saveStatus = p.Save(NXOpen.BasePart.SaveComponents.True, NXOpen.BasePart.CloseAfterSave.False);

                    theSession.LogFile.WriteLine(saveStatus.ToString());

                    ///////////////////////////////////////////////////////////
                    // If wasn't save before - assign permanent name and save
                    ///////////////////////////////////////////////////////////
                    if (saveStatus.NumberUnsavedParts > 0)
                    {
                        for (int index = 0; index < saveStatus.NumberUnsavedParts; index++)
                        {
                            NXOpen.BasePart prt = saveStatus.GetPart(index);
                            prt.AssignPermanentName(dir + "\\" + prt.Leaf + ".prt");
                            prt.Save(NXOpen.BasePart.SaveComponents.True, NXOpen.BasePart.CloseAfterSave.False);
                        }
                    }
                }
            }
            else
            {
                ///////////////////////////////////////////////////////////////
                // One-part assembly
                ///////////////////////////////////////////////////////////////
                NXOpen.BasePart part = (NXOpen.BasePart)cass.OwningPart;
                NXOpen.UF.UFSession ufs = NXOpen.UF.UFSession.GetUFSession();
                if (ufs.Part.IsModified(part.Tag))
                {
                    NXOpen.PartSaveStatus saveStatus = part.Save(NXOpen.BasePart.SaveComponents.True, NXOpen.BasePart.CloseAfterSave.False);
                    if (saveStatus.NumberUnsavedParts > 0)
                    {
                        for (int index = 0; index < saveStatus.NumberUnsavedParts; index++)
                        {
                            NXOpen.BasePart prt = saveStatus.GetPart(index);
                            prt.AssignPermanentName(dir + "\\" + prt.Leaf + ".prt");
                            prt.Save(NXOpen.BasePart.SaveComponents.True, NXOpen.BasePart.CloseAfterSave.False);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Create or update an item, which can be a part or an assembly
        /// </summary>
        /// <param name="item">the item</param>
        /// <returns>root item of server response</returns>
        public Item DoUpdateItem(Item item)
        {
            Message.Log("item: " + item.ItemNumber + 
                        "; state : " + item.ItemServerState.ToString());

            // load metadata file
            this.uploadedFilesXml.Load();

            Item resItem = null;

            if (item.Children.Count > 0)
            {
                // if the item is new, we have to update its parent,
                // in order to create relations between the parent and the item
                if (item.ItemServerState == Item.ServerState.New && item.HasParent)
                {
                    this.DoUpdateItem(item.Parent);
                }

                resItem = this.DoUpdateStructure(item).RootItem;
            }
            else
            {
                Response response = this.DoUpdateAssembly(item, Settings.Instance.XmapDir);
                resItem = (response == null) ? null : response.RootItem;
            }

            // save matadata
            this.uploadedFilesXml.Save();

            return resItem;
        }

        /// <summary>
        /// Function builds a list of all modified parts.
        /// </summary>
        /// <param name="root">root part</param>
        /// <param name="modified">list of all modified parts</param>
        private static void GetModifiedParts(NXOpen.Assemblies.Component root, List<NXOpen.BasePart> modified)
        {
            NXOpen.UF.UFSession ufs = NXOpen.UF.UFSession.GetUFSession();

            foreach (NXOpen.Assemblies.Component c in root.GetChildren())
            {
                NXOpen.BasePart part = (NXOpen.BasePart)c.Prototype;
                if (ufs.Part.IsModified(part.Tag))
                {
                    modified.Add(part);
                }

                GetModifiedParts(c, modified);
            }
        }

        /// <summary>
        /// Create or update a hierarchy of selected items on server, recursively, bottom-to-top
        /// </summary>
        /// <param name="item">the root item</param>
        /// <returns>server response</returns>
        private Response DoUpdateStructure(Item item)
        {
            Message.Log("item: " + item.ItemNumber + "; state : " + item.ItemServerState.ToString());

            Response res = new Response();

            if (item.Children.Count > 0)
            {
                // recursively find all children
                foreach (Item child in item.Children)
                {
                    this.DoUpdateStructure(child);
                }

                // update 
                res = Backend.Instance.DoUpdateAssembly(item, Settings.Instance.XmapDir);

                // memorize returned OBID
                if (res != null)
                {
                    foreach (Item resItem in res.Items)
                    {
                        if (item.ItemNumber == resItem.ItemNumber)
                        {
                            item.OBID = resItem.OBID;
                        }
                    }
                }
            }

            return res;
        }

        /// <summary>
        /// Create or update an assembly and its relations in ARAS server
        /// </summary>
        /// <param name="assembly">the assembly</param>
        /// <param name="dir">directory with the file</param>
        /// <returns>server respons</returns>
        private Response DoUpdateAssembly(Item assembly, string dir)
        {
            if (assembly.ItemOperationState != Item.OperationState.Create &&
                assembly.ItemOperationState != Item.OperationState.Update)
            {
                Message.Log("item: " + assembly.ItemNumber + " Operation " + assembly.ItemOperationState);
                return null;
            }

            Message.Log("item : " + assembly.ItemNumber +
                          " ItemServerState : " + assembly.ItemServerState +
                          " ItemModifyState : " + assembly.ItemModifyState);
            foreach (Item item in assembly.Children)
            {
                Message.LogHi("child " + item.ItemNumber + " rel=" + item.RelationServerState);
            }

            // Check that a Aras-session is existing.
            if (!this.session.IsSessionOpen())
            {
                throw new MyException("Session is not open.");
            }

            // get credentials of current session
            Credentials cred = this.session.GetCurrentCredentials();

            List<Item> lockedItems = new List<Item>();
            try
            {
                // lock and synchronize
                lockedItems = this.LockItems(cred, assembly);
                Response res = this.client.Synchronize(cred, assembly);

                // copy properties of the initial item      
                foreach (Item resItem in res.Items)
                {
                    resItem.ItemOperationState = this.GetItem(assembly, resItem.ItemNumber).ItemOperationState;
                    resItem.ItemServerState = this.GetItem(assembly, resItem.ItemNumber).ItemServerState;
                }

                List<Item> itemsToUpload = res.Items;

                // upload all the files
                this.client.UploadFiles(cred, itemsToUpload, dir);

                // fire the parent event (parent item is synchronized always)
                if (this.EventItemSynchronized != null)
                {
                    this.EventItemSynchronized(assembly);
                }

                // fire the events and set uploadedFiles
                foreach (Item itemToUpload in itemsToUpload)
                {
                    // fire the child events
                    if (this.EventItemSynchronized != null &&
                        itemToUpload.ItemNumber != assembly.ItemNumber &&
                        itemToUpload.ItemOperationState != Item.OperationState.Skip)
                    {
                        this.EventItemSynchronized(itemToUpload);
                    }

                    // Get the current modification time from file system 
                    string name = itemToUpload.GetFileName();
                    string time = MetaDataEntry.GetCurrentLocalModificationTime(dir, name);

                    // add the metadata
                    this.uploadedFilesXml.AddEntry(new MetaDataEntry()
                        {
                            Name = name,
                            LocalModificationTime = time,
                            ServerModificationTime = time
                        }

                    );
                }

                Response updateRes = this.client.UpdateItemsData(cred, itemsToUpload);

                // the item has been updated, so now it (and its file as well) exists on server.
                assembly.ItemServerState = Item.ServerState.Existing;
                assembly.NewVersionCreated = true;

                return updateRes;
            }
            finally
            {
                // unlock after all
                this.UnlockItems(cred, lockedItems);
            }
        }

        /// <summary>
        /// A helper: finds an item in a sub-assembly and return it
        /// </summary>
        /// <param name="assembly">the assembly</param>
        /// <param name="item_number">search criterion</param>
        /// <returns>Server State</returns>
        private Item GetItem(Item assembly, string item_number)
        {
            if (assembly.ItemNumber == item_number)
            {
                return assembly;
            }

            // find all children
            foreach (Item child in assembly.Children)
            {
                if (child.ItemNumber == item_number)
                {
                    return child;
                }
            }
                        
            return null;
        }

        /// <summary>
        /// Lock assembly and its children 
        /// </summary>
        /// <param name="cred">User credentials</param>
        /// <param name="assembly">the assembly (probably, with a hierarchical structure)</param>
        /// <returns>the list of locked items</returns>
        private List<Item> LockItems(Credentials cred, Item assembly)
        {
            List<Item> lockedItems = new List<Item>();

            if (assembly.ItemServerState == Item.ServerState.Existing &&
                assembly.PwbIsCheckedOutBy != cred.UserName)
            {
                client.LockUnlock(cred, assembly, true);
                lockedItems.Add(assembly);
            }

            foreach (Item child in assembly.Children)
            {
                if (child.ItemServerState == Item.ServerState.Existing &&
                    child.PwbIsCheckedOutBy != cred.UserName &&
                    client.NeedToSynchronize(child))
                {
                    client.LockUnlock(cred, child, true);
                    lockedItems.Add(child);
                }
            }

            return lockedItems;
        }

        /// <summary>
        /// Lock/unlock locked items
        /// </summary>
        /// <param name="cred">User credentials</param>
        /// <param name="lockedItems">the locked items</param>
        private void UnlockItems(Credentials cred, List<Item> lockedItems)
        {
            foreach (Item lockedItem in lockedItems)
            {
                client.LockUnlock(cred, lockedItem, false);
            }
        }
    }
}