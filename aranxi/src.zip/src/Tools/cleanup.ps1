 
 
$scriptpath = $MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath
cd $dir\..

 
Write-Host "======== cleanup sources ============"
  
# obj, bin, x64  
#$folders = (Get-Childitem . -Recurse  | where {($_.Attributes -eq "Directory")  -and ($_.fullname -notmatch "Cleanup") -and  ($_.Name -eq "obj"  -or $_.Name -eq "bin"  -or $_.Name -eq "x64")})       
#foreach ($folder in $folders) 
#{  
#  if($folder -ne $NULL)
#  {
#    Write-Host "delete: " $folder.fullname 
#    Remove-Item -Recurse -Force $folder.fullname 
#  }
#}  

# Debug, Release 
#$folders = (Get-Childitem . -Recurse  | where {$_.Attributes -eq "Directory" -and ($_.fullname -notmatch "Cleanup") -and ($_.Name -eq "Debug"   -or $_.Name -eq "Release")}) 
#foreach ($folder in $folders) 
#{  
#  if($folder -ne $NULL)
#  {
#    Write-Host "delete: "$folder.fullname 
#    Remove-Item -Recurse -Force $folder.fullname 
#  }
#}  


$startup = $(get-content env:UGII_USER_DIR) + "\startup"
Write-Host "======== cleanup" $startup "============"

cd $startup

$files = (Get-Childitem . -Recurse)       
foreach ($file in $files) 
{  
  if($file -ne $NULL)
  {
    Write-Host "delete: " $file.Name 
    Remove-Item -Force $file.fullname 
  }
}  


$app = $(get-content env:UGII_USER_DIR) + "\application"
Write-Host "======== cleanup" $app "============"
cd $app

$files = (Get-Childitem . -Recurse | where { ($_.Name -notmatch "NXOpen") -and ($_.Name -ne "Snap.dll")} )      
foreach ($file in $files) 
{  
  if($file -ne $NULL)
  {
    Write-Host "delete: "  $file.Name 
    Remove-Item -Force $file.fullname 
  }
}  
