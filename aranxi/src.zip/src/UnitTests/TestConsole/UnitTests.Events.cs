﻿// -----------------------------------------------------------------------
// <copyright file="UnitTests.Events.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using TSI.PDM.BL;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Event-catching methods
    /// </summary>
    public partial class UnitTests
    {
        /// <summary>
        /// Class for catching events
        /// </summary>
        public class SynchronizedEvents
        {
            /// <summary>
            /// List of synchronizedItems
            /// </summary>
            private List<Item> synchronizedItems = new List<Item>();

            /// <summary>
            /// Gets a list of synchronizedItems
            /// </summary>
            public List<Item> SynchronizedItems
            {
                get
                {
                    return this.synchronizedItems;
                }
            }

            /// <summary>
            /// Subscribe to event
            /// </summary>
            public void Subscribe()
            {
                Backend.Instance.EventItemSynchronized +=
                        new Backend.EventHandler(this.OnItemSynchronized);

                this.synchronizedItems.Clear();
            }

            /// <summary>
            /// unsubscribe from Event
            /// </summary>
            public void Unsubscribe()
            {
                Backend.Instance.EventItemSynchronized -=
                        new Backend.EventHandler(this.OnItemSynchronized);
            }

            /// <summary>
            /// a handler 
            /// </summary>
            /// <param name="item">the syncronized item</param>
            private void OnItemSynchronized(Item item)
            {
                Message.Log(
                    "EVENT: " + item.ItemOperationState + " item: " + item.ItemNumber + " ... OK!",
                    ConsoleColor.Blue);

                this.synchronizedItems.Add(item);
            }
        }
    }
}
