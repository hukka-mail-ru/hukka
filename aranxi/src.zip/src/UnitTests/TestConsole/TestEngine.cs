﻿// -----------------------------------------------------------------------
// <copyright file="TestEngine.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Text;
    using System.Threading;

    using TSI.PDM.BL;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Test of Engine
    /// </summary>
    public partial class UnitTests
    {
        /*
        public void TestCompareRoots()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item child1 = GetPart("child1");
            Item child2 = GetPart("child2");
            Item child3 = GetPart("child3");

            Item localRoot = GetAssembly("root");
            localRoot.Children.Add(child2);

            Item serverRoot = GetAssembly("root");
            serverRoot.Children.Add(child1);
            serverRoot.Children.Add(child2);
            serverRoot.Children.Add(child3);

            Engine.SetParents(localRoot);
            Engine.SetParents(serverRoot);
            Engine.CompareRoots(localRoot, serverRoot);

            this.Check(localRoot.Children.Count == 3);

            this.Check(localRoot.GetChild("child1").RelationServerState == Item.ServerState.ToDelete);
            this.Check(localRoot.GetChild("child2").RelationServerState != Item.ServerState.ToDelete);
            this.Check(localRoot.GetChild("child3").RelationServerState == Item.ServerState.ToDelete);

            this.Check(localRoot.GetChild("child2").ItemServerState == Item.ServerState.Existing);
        }

        public void TestCompareRoots2()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item localRoot = GetAssembly("root");
            Item child1 = GetPart("child1");
            Item child2 = GetPart("child2");
            Item child3 = GetPart("child3");

            // server is empty
            Item serverRoot = GetAssembly("no");
            serverRoot.ItemServerState = Item.ServerState.New;

            localRoot.Children.Add(child1);
            localRoot.Children.Add(child2);
            localRoot.Children.Add(child3);

            Engine.SetParents(localRoot);
            Engine.CompareRoots(localRoot, serverRoot);

            this.Check(localRoot.Children.Count == 3);

            this.Check(localRoot.GetChild("child1").RelationServerState != Item.ServerState.ToDelete);
            this.Check(localRoot.GetChild("child2").RelationServerState != Item.ServerState.ToDelete);
            this.Check(localRoot.GetChild("child3").RelationServerState != Item.ServerState.ToDelete);

            this.Check(localRoot.GetChild("child1").ItemServerState == Item.ServerState.New);
            this.Check(localRoot.GetChild("child2").ItemServerState == Item.ServerState.New);
            this.Check(localRoot.GetChild("child3").ItemServerState == Item.ServerState.New);
        }

        // delete all from server
        public void TestCompareRoots3()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item localRoot = GetAssembly("root");

            Item serverRoot = GetAssembly("root");
            Item child1 = GetPart("child1");
            Item child2 = GetPart("child2");
            Item child3 = GetAssembly("child3");
            Item subchild1 = GetPart("subchild1");
            Item subchild2 = GetPart("subchild2");

            serverRoot.Children.Add(child1);
            serverRoot.Children.Add(child2);
            serverRoot.Children.Add(child3);

            child3.Children.Add(subchild1);
            child3.Children.Add(subchild2);

            Engine.SetParents(localRoot);
            Engine.SetParents(serverRoot);
            Engine.CompareRoots(localRoot, serverRoot);

            this.Check(localRoot.Children.Count == 3);

            this.Check(localRoot.GetChild("child1").RelationServerState == Item.ServerState.ToDelete);
            this.Check(localRoot.GetChild("child2").RelationServerState == Item.ServerState.ToDelete);
            this.Check(localRoot.GetChild("child3").RelationServerState == Item.ServerState.ToDelete);
        }

        public void TestCompareRoots_Move()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item localRoot = GetAssembly("root");
            Item localChild = GetPart("child");
            localRoot.Children.Add(localChild);

            Item serverRoot = GetAssembly("root");
            Item serverB = GetAssembly("B");
            Item serverChild = GetPart("child");
            serverRoot.Children.Add(serverB);
            serverB.Children.Add(serverChild);

            Engine.SetParents(localRoot);
            Engine.SetParents(serverRoot);
            Engine.CompareRoots(localRoot, serverRoot);

            this.Check(localRoot.Children.Count == 2);

            this.Check(localRoot.GetChild("child").RelationServerState != Item.ServerState.ToDelete);
            this.Check(localRoot.GetChild("B").RelationServerState == Item.ServerState.ToDelete);

            this.Check(localRoot.GetChild("child").ItemServerState == Item.ServerState.New);
        }

        public void TestCompareRoots_Move2()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item localRoot = GetAssembly("root");
            Item localB = GetAssembly("B");
            Item localChild = GetPart("child");

            Item serverRoot = GetAssembly("root");
            Item serverChild = GetPart("child");

            localRoot.Children.Add(localB);
            localB.Children.Add(localChild);

            serverRoot.Children.Add(serverChild);

            Engine.SetParents(localRoot);
            Engine.SetParents(serverRoot);
            Engine.CompareRoots(localRoot, serverRoot);

            this.Check(localRoot.Children.Count == 2);

            this.Check(localRoot.GetChild("child").RelationServerState == Item.ServerState.ToDelete);
            this.Check(localRoot.GetChild("B").RelationServerState != Item.ServerState.ToDelete);

            this.Check(localRoot.GetChild("B").ItemServerState == Item.ServerState.New);
        }
        */
    }
}
