// -----------------------------------------------------------------------
// <copyright file="TestUpdate.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Text;

    using TSI.PDM.BL;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Test Update
    /// </summary>
    public partial class UnitTests
    {
/*
        /// <summary>
        /// 1. Select a file inside of a structure
        /// 2. Parent assembly must be selected
        /// </summary>
        public void TestUpdate_SelectParentAssembly()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            // items
            Item car = this.GetAssembly("Car");
            Item inside = this.GetAssembly("Inside");
            Item seats = this.GetPart("Seats");
            Item outside = this.GetPart("Outside");
            Item wheels = this.GetPart("Wheels");

            List<Item> items = new List<Item>();
            items.Add(car);
            items.Add(inside);
            items.Add(outside);
            items.Add(seats);
            items.Add(wheels);

            // relations
            car.Children.Add(inside);
            car.Children.Add(outside);
            inside.Children.Add(seats);
            outside.Children.Add(wheels);

            // select 
            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(seats);


            // cleanup and create files
            foreach (Item item in items)
            {
                this.DeleteItemOnServer(item);
                this.DeleteFileLocally(item);
                this.CreateFileLocally(item);
            }

            Message.Log("+++++++++++++++ create structure ++++++++++++++++");
            this.CreateOrUpdateStructureOnServer(car);

            this.Check(car.Selected == true);
            this.Check(inside.Selected == true);
            this.Check(seats.Selected == true);
            this.Check(outside.Selected == false);
            this.Check(wheels.Selected == false);
        }
        
        /// <summary>
        /// 1. Create structure
        /// 2. Modify some files locally
        /// 3. Update structure
        /// </summary>
        public void TestUpdate_ModifyFiles()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            // items
            Item car = this.GetAssembly("Car");
            Item inside = this.GetAssembly("Inside");
            Item outside = this.GetAssembly("Outside");
            Item wheels = this.GetAssembly("Wheels");

            Item engine = this.GetPart("Engine");
            Item seats = this.GetPart("Seats");
            Item corpus = this.GetPart("Corpus");

            Item one = this.GetPart("One");
            Item two = this.GetPart("Two");
            Item three = this.GetPart("Three");
            Item four = this.GetPart("Four");

            List<Item> items = new List<Item>();
            items.Add(car);
            items.Add(inside);
            items.Add(outside);
            items.Add(wheels);
            items.Add(engine);
            items.Add(seats);
            items.Add(corpus);
            items.Add(one);
            items.Add(two);
            items.Add(three);
            items.Add(four);

            // relations
            car.Children.Add(inside);
            car.Children.Add(outside);

            inside.Children.Add(engine);
            inside.Children.Add(seats);

            outside.Children.Add(corpus);
            outside.Children.Add(wheels);

            wheels.Children.Add(one);
            wheels.Children.Add(two);
            wheels.Children.Add(three);
            wheels.Children.Add(four);

            // select all
            List<Item> selectedItems = new List<Item>();
            foreach (Item item in items)
            {
                selectedItems.Add(item);
            }

            // cleanup and create files
            foreach (Item item in items)
            {
                this.DeleteItemOnServer(item);
                this.DeleteFileLocally(item);
                this.CreateFileLocally(item);
            }

            Message.Log("+++++++++++++++ create structure ++++++++++++++++");
            this.CreateOrUpdateStructureOnServer(car);

            Message.Log("+++++++++++++++ modify some files ++++++++++++++++");
            List<Item> modifiedItems = new List<Item>();
            modifiedItems.Add(car);
            modifiedItems.Add(inside);
            modifiedItems.Add(one);

            string modification = "Modified file contents";
            foreach (Item item in modifiedItems)
            {
                this.ModifyFileLocally(item, modification);
            }

            Message.Log("+++++++++++++++ Update Structure ++++++++++++++++");
            this.CreateOrUpdateStructureOnServer(car);


            Message.Log("+++++++++++++++ Reload Structure ++++++++++++++++");
            foreach (Item item in modifiedItems)
            {
                this.DeleteFileLocally(item);
            }
            this.LoadStructure(car, items);

            // modified files number?
            int counter = 0;
            foreach (Item item in items)
            {
                string content = this.ReadFileLocally(item);
                if (content == modification)
                {
                    counter++;
                }
            }
            Message.Log("Number of modified files is OK?");
            this.Check(counter == modifiedItems.Count);

            foreach (Item modifiedItem in modifiedItems)
            {
                Message.Log("Content of file is OK?");
                this.Check(this.ReadFileLocally(modifiedItem) ==modification);
            }
        }

        /// <summary>
        /// 1. Create structure
        /// 2. Add some parts to the structure
        /// 3. Update structure
        /// </summary>
        
        public void TestUpdate_AddParts()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            // items
            Item car = this.GetTestAssembly("Car");
            Item inside = this.GetTestAssembly("Inside");
            Item outside = this.GetTestAssembly("Outside");
            Item wheels = this.GetTestAssembly("Wheels");

            Item engine = this.GetTestItem("Engine");
            Item seats = this.GetTestItem("Seats");
            Item corpus = this.GetTestItem("Corpus");

            Item one = this.GetTestItem("One");
            Item two = this.GetTestItem("Two");
            Item three = this.GetTestItem("Three");
            Item four = this.GetTestItem("Four");

            List<Item> items = new List<Item>();
            items.Add(car);
            items.Add(inside);
            items.Add(outside);
            items.Add(wheels);
            items.Add(engine);
            items.Add(seats);
            items.Add(corpus);
            items.Add(one);
            items.Add(two);
            items.Add(three);
            items.Add(four);

            // relations
            car.Children.Add(inside);
            car.Children.Add(outside);

            inside.Children.Add(engine);
            inside.Children.Add(seats);

            outside.Children.Add(corpus);
            outside.Children.Add(wheels);

            wheels.Children.Add(one);
            wheels.Children.Add(two);
            wheels.Children.Add(three);
            wheels.Children.Add(four);



            Message.Log("\n\n+++++++++++++++ select all ++++++++++++++++\n");
            List<Item> selectedItems = new List<Item>();
            foreach (Item item in items)
            {
                selectedItems.Add(item);
            }

            Message.Log("\n\n+++++++++++++++ cleanup and create files ++++++++++++++++\n");
            foreach (Item item in items)
            {
                this.DeleteItemOnServer(item);
                this.DeleteFileLocally(item);
                this.CreateFileLocally(item);
            }

            Message.Log("\n\n+++++++++++++++ create structure ++++++++++++++++\n");
            this.CreateOrUpdateStructureOnServer(car);

            Message.Log("\n\n+++++++++++++++ add new parts ++++++++++++++++\n");
            Item blink = this.GetTestItem("Blink");
            items.Add(blink);
            car.Children.Add(blink);
            this.CreateFileLocally(blink);
            this.DeleteItemOnServer(blink);

            Item five = this.GetTestItem("Five");
            items.Add(five);
            wheels.Children.Add(five);
            this.CreateFileLocally(five);
            this.DeleteItemOnServer(five);

            Message.Log("\n\n+++++++++++++++ select all ++++++++++++++++\n");
            selectedItems = new List<Item>();
            foreach (Item item in items)
            {
                selectedItems.Add(item);
            }

            Message.Log("\n\n+++++++++++++++  update structure ++++++++++++++++\n");
            this.CreateOrUpdateStructureOnServer(car);

            Message.Log("\n\n+++++++++++++++  Reload Structure ++++++++++++++++\n");
            Item resItem = this.LoadStructure(car, items);

            this.CheckStructure(resItem, car);
        }
        
        public void TestUpdate_Generation()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("\n\n+++++++++++++++ create item ++++++++++++++++\n");
            Item item = this.GetPart("ItemA");
            this.DeleteItemOnServer(item);
            this.CreateItemOnServer(item);
            this.CreateFileLocally(item);

            // Item is on server?
            Backend.Instance.DoQueryItem(item);
            Message.Log("Item is on server?");
            this.Check(item.ItemServerState == Item.ServerState.Existing);

            Message.Log("\n\n+++++++++++++++ modify file 1 ++++++++++++++++\n");
            string modification = "Modified";
            this.ModifyFileLocally(item, modification);
            Message.Log("File modified?");
            this.Check(this.ReadFileLocally(item) == modification);

            Message.Log("\n\n+++++++++++++++ update ++++++++++++++++\n");
            Item updateResItem = this.UpdateItemOnServer(item);
            Message.Log("Item updated?");
            this.Check(updateResItem != null);



            Message.Log("\n\n+++++++++++++++ modify file  2 ++++++++++++++++\n");
            modification = "Modified file 222 ";
            this.ModifyFileLocally(item, modification);
            Message.Log("File modified?");
            this.Check(this.ReadFileLocally(item) == modification);

            Message.Log("\n\n+++++++++++++++ update ++++++++++++++++\n");
            updateResItem = this.UpdateItemOnServer(item);
            Message.Log("Item updated?");
            this.Check(updateResItem != null);



            Message.Log("\n\n+++++++++++++++ modify file 3 ++++++++++++++++\n");
            modification = "Modified file contents  3333";
            this.ModifyFileLocally(item, modification);
            Message.Log("File modified?");
            this.Check(this.ReadFileLocally(item) == modification);

            Message.Log("\n\n+++++++++++++++ update ++++++++++++++++\n");
            updateResItem = this.UpdateItemOnServer(item);
            Message.Log("Item updated?");
            this.Check(updateResItem != null);

            Backend.Instance.DoQueryItem(item);

            int correctGeneration = 4;
            Message.Log("Generation is " + item.Generation + ". Correct is " + correctGeneration);
            this.Check(item.Generation == correctGeneration.ToString());
        }

        public void TestUpdate_Events()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("\n\n+++++++++++++++ delete UpdateFiles.xml ++++++++++++++++\n");
            File.Delete(Settings.Instance.UploadedFilesXml);

            Message.Log("\n\n+++++++++++++++ create items ++++++++++++++++\n");
            Item assembly = this.GetAssembly("assembly");
            Item sub_assembly1 = this.GetAssembly("sub_assembly1");

            Item perch = this.GetPart("perch");
            Item front = this.GetPart("front");

            Item side = this.GetPart("side");
            Item leg = this.GetPart("leg");
            Item roof = this.GetPart("roof");
            Item bottom = this.GetPart("bottom");

            List<Item> items = new List<Item>();
            items.Add(assembly);
            items.Add(sub_assembly1);
            items.Add(front);
            items.Add(perch);
            items.Add(side);
            items.Add(leg);
            items.Add(roof);
            items.Add(bottom);

            // relations
            sub_assembly1.Children.Add(perch);
            sub_assembly1.Children.Add(front);

            assembly.Children.Add(sub_assembly1);
            assembly.Children.Add(side);
            assembly.Children.Add(leg);
            assembly.Children.Add(roof);
            assembly.Children.Add(bottom);

            // files
            Message.Log("\n\n+++++++++++++++ copy files from 'skvo' ++++++++++++++++\n");
            foreach (Item item in items)
            {
                this.DeleteItemOnServer(item);
                CopyFileLocally(item, "skvo");
            }

            Message.Log("\n\n+++++++++++++++ select LEG ++++++++++++++++\n");
            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(leg);

            // subscribe to events
            SynchronizedEvents synchronizedEvents = new SynchronizedEvents();
            synchronizedEvents.Subscribe();

            // must be updated:
            // leg, assembly
            Message.Log("\n\n+++++++++++++++ create structure on server ++++++++++++++++\n");
            this.CreateOrUpdateStructureOnServer(assembly);
       
            // select again
            Message.Log("\n\n+++++++++++++++ select PERCH ++++++++++++++++\n");
            List<Item> selectedItems2 = new List<Item>();
            selectedItems2.Add(perch);

            // must be updated:
            // perch, assembly, sub-assembly
            Message.Log("\n\n+++++++++++++++ create structure on server 2 ++++++++++++++++\n");
            this.CreateOrUpdateStructureOnServer(assembly);

            Message.Log("Check events are catched");
            this.Check(synchronizedEvents.SynchronizedItems.Count == 5);

            Item found = synchronizedEvents.SynchronizedItems.Find(i => i.ItemNumber == "assembly");
            this.Check(found.ItemNumber != null);
            found = synchronizedEvents.SynchronizedItems.Find(i => i.ItemNumber == "sub_assembly1");
            this.Check(found.ItemNumber != null);
            found = synchronizedEvents.SynchronizedItems.Find(i => i.ItemNumber == "perch");
            this.Check(found.ItemNumber != null);
            found = synchronizedEvents.SynchronizedItems.Find(i => i.ItemNumber == "leg");
            this.Check(found.ItemNumber != null);

            synchronizedEvents.Unsubscribe();
        }

        public void TestUpdate_ChangeClass()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item item = this.CreateItemAndFile("ItemC", Settings.Instance.CadPart);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(item);

            this.CreateOrUpdateStructureOnServer(item);


            Message.Log("---- Change Class ---- ", ConsoleColor.DarkCyan);
            item.Class = Settings.Instance.CadAssembly;

            this.CreateOrUpdateStructureOnServer(item);
        }
 */
    }
}
