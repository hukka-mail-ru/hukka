﻿// -----------------------------------------------------------------------
// <copyright file="TestAranxi33.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Text;
    using TSI.PDM.BL;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Unit Tests: Test JIRA Aranxi-33 
    /// </summary>
    public partial class UnitTests
    {
        /// <summary>
        /// Create File
        /// </summary>
        public void TestAranxi33_01_CreateFile()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item item = this.CreateItemAndFile("ItemA", Settings.Instance.CadPart);
            item.Description = "Description";
            
            // Transmit the file to server
            Backend.Instance.DoCreateSingleFile(
                item, "default", Settings.Instance.XmapDir, false);

            // Test
            Item res = new Item { ItemNumber = "ItemA", Class = Settings.Instance.CadPart };
            Backend.Instance.DoQueryItem(res);

            Message.Log("res.description '" + res.Description + "'");
      
            this.Check(res.Description == "Description");
            this.Check(res.NativeFile == item.GetFileName());

            Message.Log("Item is on server?");
            this.Check(res.ItemServerState == Item.ServerState.Existing);

            this.DeleteFileLocally(res);

            Backend.DownloadStatus st
                = Backend.Instance.DoLoadSingleFile(res, false, false);

            Message.Log("Item downloaded?");
            this.Check(st == Backend.DownloadStatus.Downloaded);

            Message.Log("File exists?");
            this.Check(this.IsFileExistsLocally(res) == true);
        }

        /// <summary>
        /// Change File
        /// </summary>
        public void TestAranxi33_02_ChangeFile()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            // items
            Item item = this.GetPart("ItemA");

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(item);

            // cleanup and create files
            this.CreateFileLocally(item);

            Message.Log("--- create structure", ConsoleColor.DarkCyan);
            this.CreateOrUpdateStructureOnServer(item);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.Generation);

            Message.Log("--- modify file", ConsoleColor.DarkCyan);
            string modification = "Modified file contents";
            this.ModifyFileLocally(item, modification);

            Message.Log("--- Update Structure", ConsoleColor.DarkCyan);
            this.CreateOrUpdateStructureOnServer(item);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.Generation);
            
            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            this.DeleteFileLocally(item);

            Backend.DownloadStatus st
                = Backend.Instance.DoLoadSingleFile(item, false, false);

            Message.Log("Item downloaded?");
            this.Check(st == Backend.DownloadStatus.Downloaded);

            Message.Log("modified?");
            string content = this.ReadFileLocally(item);
            this.Check(content == modification);
        }

        /// <summary>
        /// Change Unsaved File
        /// </summary>
        public void TestAranxi33_02a_ChangeFile_Unsaved()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            // items
            Item item = this.GetPart("ItemA");

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(item);

            // cleanup and create files
            this.CreateFileLocally(item);

            Message.Log("--- create structure", ConsoleColor.DarkCyan);
            this.CreateOrUpdateStructureOnServer(item);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.Generation);

            Message.Log("--- modify file", ConsoleColor.DarkCyan);

            List<Item> unsavedItems = new List<Item>();
            unsavedItems.Add(item);

            Message.Log("--- Update Structure", ConsoleColor.DarkCyan);
            this.CreateOrUpdateStructureOnServer(item, unsavedItems);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.Generation);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            this.DeleteFileLocally(item);

            Backend.DownloadStatus st
                = Backend.Instance.DoLoadSingleFile(item, false, false);

            Message.Log("Item downloaded?");
            this.Check(st == Backend.DownloadStatus.Downloaded);

            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.Generation);

          // this.Check(item.generation == "2");
        }
 
        /// <summary>
        /// Update Only Modified File
        /// </summary>
        public void TestAranxi33_03_UpdateOnlyModified()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            // let's user press SAVE
            Engine.SetSaved(true);

            Item item = this.GetPart("ItemA");

            // select it
            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(item);

            // cleanup and create files
            this.CreateFileLocally(item);

            Message.Log("\n\n+++++++++++++++ upload to server ++++++++++++++++\n");
            this.CreateOrUpdateStructureOnServer(item);

            Message.Log("\n\n+++++++++++++++ upload again ++++++++++++++++\n");
            Item resItem = this.CreateOrUpdateStructureOnServer(item);
            this.Check(resItem == null);

            // restore default contition
            Engine.SetSaved(false);
        }

        /// <summary>
        /// Add Existsing File To New Assembly
        /// </summary>
        public void TestAranxi33_04_AddExistsingFileToNewAssembly()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- file", ConsoleColor.DarkCyan);
            Item item = this.CreateItemAndFile("ItemA", Settings.Instance.CadPart);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(item);

            Message.Log("--- create structure", ConsoleColor.DarkCyan);
            this.CreateOrUpdateStructureOnServer(item);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.Generation);

            Message.Log("--- assembly", ConsoleColor.DarkCyan);
            Item assembly = this.CreateItemAndFile("AssemblyA", Settings.Instance.CadAssembly);

            assembly.Children.Add(item);

            selectedItems.Clear();
            selectedItems.Add(assembly);
            selectedItems.Add(item);

            Message.Log("--- update structure", ConsoleColor.DarkCyan);
            this.CreateOrUpdateStructureOnServer(assembly);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.Generation);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            foreach (Item i in selectedItems)
            {
                this.DeleteFileLocally(i);
            }

            Item res = this.LoadStructure(assembly, selectedItems);

            this.CheckStructure(res, assembly);
        }

        /// <summary>
        /// Add New File To New Assembly
        /// </summary>
        public void TestAranxi33_05_AddNewFileToNewAssembly()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- file", ConsoleColor.DarkCyan);
            Item item = this.CreateItemAndFile("ItemA", Settings.Instance.CadPart);

            Message.Log("--- assembly", ConsoleColor.DarkCyan);
            Item assembly = this.CreateItemAndFile("AssemblyA", Settings.Instance.CadAssembly);

            assembly.Children.Add(item);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(assembly);
            selectedItems.Add(item);

            Message.Log("--- update structure", ConsoleColor.DarkCyan);
            this.CreateOrUpdateStructureOnServer(assembly);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.Generation);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            foreach (Item i in selectedItems)
            {
                this.DeleteFileLocally(i);
            }

            Item res = this.LoadStructure(assembly, selectedItems);

            this.CheckStructure(res, assembly);
        }

        /// <summary>
        /// Add Existing File To Existing Assembly
        /// </summary>
        public void TestAranxi33_06_AddExistingFileToExistingAssembly()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- file", ConsoleColor.DarkCyan);
            Item item = this.CreateItemAndFile("ItemA", Settings.Instance.CadPart);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(item);

            Message.Log("--- create structure (file)", ConsoleColor.DarkCyan);
            this.CreateOrUpdateStructureOnServer(item);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.Generation);

            Message.Log("--- assembly", ConsoleColor.DarkCyan);
            Item assembly = this.CreateItemAndFile("AssemblyA", Settings.Instance.CadAssembly);

            selectedItems.Clear();
            selectedItems.Add(assembly);

            Message.Log("--- create structure (assembly)", ConsoleColor.DarkCyan);
            this.CreateOrUpdateStructureOnServer(assembly);
            Backend.Instance.DoQueryItem(assembly);
            Message.Log("item.generation " + assembly.Generation);

            Message.Log("--- add item as child", ConsoleColor.DarkCyan);
            assembly.Children.Add(item);
            this.ModifyFileLocally(assembly, "file modified because child is added");

            selectedItems.Clear();
            selectedItems.Add(assembly);
            selectedItems.Add(item);

            Message.Log("--- update structure", ConsoleColor.DarkCyan);
            this.CreateOrUpdateStructureOnServer(assembly);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.Generation);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            foreach (Item i in selectedItems)
            {
                this.DeleteFileLocally(i);
            }

            Item res = this.LoadStructure(assembly, selectedItems);

            this.CheckStructure(res, assembly);
        }

        /// <summary>
        /// Add Existing File To Existing Assembly embracing
        /// </summary>
        public void TestAranxi33_06a_AddExistingFileToExistingAssembly()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- item", ConsoleColor.DarkCyan);
            Item item = this.CreateItemAndFile("Item_06a", Settings.Instance.CadPart);
            this.CreateOrUpdateStructureOnServer(item);

            Message.Log("--- assembly", ConsoleColor.DarkCyan);
            Item root = this.CreateItemAndFile("Root_06a", Settings.Instance.CadAssembly);
            Item assembly = this.CreateItemAndFile("Assembly_06a", Settings.Instance.CadAssembly);

            root.Children.Add(assembly);
            this.CreateOrUpdateStructureOnServer(root);            

            Message.Log("--- add item as child", ConsoleColor.DarkCyan);
            assembly.Children.Add(item);
            this.ModifyFileLocally(assembly, "file modified because child is added");
            this.ModifyFileLocally(root, "file modified because child is added");

            this.CreateOrUpdateStructureOnServer(root);
            
            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);

            List<Item> items = new List<Item>();
            items.Add(root);
            items.Add(assembly);
            items.Add(item);

            this.DeleteFileLocally(root);
            this.DeleteFileLocally(assembly);
            this.DeleteFileLocally(item);

            Item res = this.LoadStructure(root, items);

            this.CheckStructure(res, root);
        }

        /// <summary>
        /// Add New File To Existing Assembly
        /// </summary>
        public void TestAranxi33_07_AddNewFileToExistingAssembly()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- assembly", ConsoleColor.DarkCyan);
            Item assembly = this.CreateItemAndFile("AssemblyA_07", Settings.Instance.CadAssembly);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Clear();
            selectedItems.Add(assembly);

            Message.Log("--- create structure (assembly)", ConsoleColor.DarkCyan);
            this.CreateOrUpdateStructureOnServer(assembly);
            Backend.Instance.DoQueryItem(assembly);
            Message.Log("item.generation " + assembly.Generation);

            Message.Log("--- file", ConsoleColor.DarkCyan);
            Item item = this.CreateItemAndFile("ItemA_07", Settings.Instance.CadPart);

            Message.Log("--- add item as child", ConsoleColor.DarkCyan);
            assembly.Children.Add(item);
            this.ModifyFileLocally(assembly, "file modified because child is added");

            selectedItems.Clear();
            selectedItems.Add(assembly);
            selectedItems.Add(item);

            Message.Log("--- update structure", ConsoleColor.DarkCyan);
            this.CreateOrUpdateStructureOnServer(assembly);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.Generation);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            foreach (Item i in selectedItems)
            {
                this.DeleteFileLocally(i);
            }

            Item res = this.LoadStructure(assembly, selectedItems);

            this.CheckStructure(res, assembly);
        }

        /// <summary>
        /// Add New File To Existing Assembly embracing
        /// </summary>
        public void TestAranxi33_07a_AddNewFileToExistingAssembly()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- create assembly", ConsoleColor.DarkCyan);
            Item root = this.CreateItemAndFile("Root_07a", Settings.Instance.CadAssembly);
            Item assembly = this.CreateItemAndFile("AssemblyA_07a", Settings.Instance.CadAssembly);

            root.Children.Add(assembly);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Clear();
            selectedItems.Add(root);
            selectedItems.Add(assembly);

            this.CreateOrUpdateStructureOnServer(assembly);
            Backend.Instance.DoQueryItem(assembly);
            Message.Log("item.generation " + assembly.Generation);

            Message.Log("--- file", ConsoleColor.DarkCyan);
            Item item = this.CreateItemAndFile("ItemA_07a", Settings.Instance.CadPart);

            Message.Log("--- add item as child", ConsoleColor.DarkCyan);
            assembly.Children.Add(item);
            this.ModifyFileLocally(assembly, "file modified because child is added");

            selectedItems.Clear();
            selectedItems.Add(root);
            selectedItems.Add(assembly);
            selectedItems.Add(item);

            Message.Log("--- update structure", ConsoleColor.DarkCyan);
            this.CreateOrUpdateStructureOnServer(root);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.Generation);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            foreach (Item i in selectedItems)
            {
                this.DeleteFileLocally(i);
            }

            Item res = this.LoadStructure(root, selectedItems);

            this.CheckStructure(res, root);
        }
         
        /// <summary>
        /// Delete File From Existing Assembly
        /// </summary>
        public void TestAranxi33_08_DeleteFileFromExistingAssembly()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- assembly", ConsoleColor.DarkCyan);
            Item assembly = this.CreateItemAndFile("AssemblyA", Settings.Instance.CadAssembly);

            Message.Log("--- file", ConsoleColor.DarkCyan);
            Item item = this.CreateItemAndFile("ItemA", Settings.Instance.CadPart);

            assembly.Children.Add(item);

            Message.Log("--- create structure", ConsoleColor.DarkCyan);
            this.CreateOrUpdateStructureOnServer(assembly);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.Generation);
            Backend.Instance.DoQueryItem(assembly);
            Message.Log("assembly.generation " + assembly.Generation);

            Message.Log("--- remove file", ConsoleColor.DarkCyan);
            assembly.Children.Remove(item);
            this.Check(assembly.Children.Count == 0);
            this.ModifyFileLocally(assembly, "modified contents");
            this.CreateOrUpdateStructureOnServer(assembly);

            List<Item> items = new List<Item>();
            items.Add(assembly);
            items.Add(item);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            Item res = this.LoadStructure(assembly, items);

            this.CheckStructure(res, assembly);
        }

        /// <summary>
        /// Delete File From Existing Assembly embracing
        /// </summary>
        public void TestAranxi33_08a_DeleteFileFromExistingAssembly()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- assembly", ConsoleColor.DarkCyan);
            Item root = this.CreateItemAndFile("Root_08a", Settings.Instance.CadAssembly);
            Item assembly = this.CreateItemAndFile("Assembly_08a", Settings.Instance.CadAssembly);
            Item item = this.CreateItemAndFile("Item_08a", Settings.Instance.CadPart);

            root.Children.Add(assembly);
            assembly.Children.Add(item);

            this.CreateOrUpdateStructureOnServer(root);

            Backend.Instance.DoExpand(assembly);
            
            Message.Log("--- remove file", ConsoleColor.DarkCyan);
            assembly.Children.Remove(item);
            this.Check(assembly.Children.Count == 0);
            this.ModifyFileLocally(assembly, "modified contents");

            this.CreateOrUpdateStructureOnServer(root);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);

            // recreate structure, i.e. Engine.SetProperties adds the deleted element to assembly.
            assembly.Children.Clear();

            List<Item> items = new List<Item>();
            items.Add(root);
            items.Add(assembly);

            Message.LogHi("assembly.Children " + assembly.Children.Count);

            Item res = this.LoadStructure(root, items);

            this.CheckStructure(res, root);
        }

        /// <summary>
        /// Add Existsing Assembly To Existing Assembly
        /// </summary>
        public void TestAranxi33_09_AddExistsingAssemblyToExistingAssembly()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- create structure A", ConsoleColor.DarkCyan);
            Item assemblyA = this.CreateItemAndFile("AssemblyA", Settings.Instance.CadAssembly);
            Item itemA = this.CreateItemAndFile("ItemA", Settings.Instance.CadPart);
            
            assemblyA.Children.Add(itemA);

            this.CreateOrUpdateStructureOnServer(assemblyA);

            Message.Log("--- create structure B", ConsoleColor.DarkCyan);
            Item assemblyB = this.CreateItemAndFile("AssemblyB", Settings.Instance.CadAssembly);
            Item itemB = this.CreateItemAndFile("ItemB", Settings.Instance.CadPart);

            assemblyB.Children.Add(itemB);

            this.CreateOrUpdateStructureOnServer(assemblyB);
           
            Message.Log("--- add B to A", ConsoleColor.DarkCyan);
            assemblyA.Children.Add(assemblyB);
            this.ModifyFileLocally(assemblyA, "modified file");
            this.ModifyFileLocally(assemblyB, "modified file");

            this.CreateOrUpdateStructureOnServer(assemblyA);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            List<Item> items = new List<Item>();
            items.Add(assemblyA);
            items.Add(assemblyB);
            items.Add(itemA);
            items.Add(itemB);

            Item res = this.LoadStructure(assemblyA, items);

            Message.Log("--- res", ConsoleColor.DarkCyan);
            this.CheckStructure(res, assemblyA);
        }

        /// <summary>
        /// Add Existsing Assembly To Existing Assembly embracing
        /// </summary>
        public void TestAranxi33_09a_AddExistsingAssemblyToExistingAssembly()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- create structure A", ConsoleColor.DarkCyan);
            Item root = this.CreateItemAndFile("Root_09a", Settings.Instance.CadAssembly);
            Item assemblyA = this.CreateItemAndFile("AssemblyA_09a", Settings.Instance.CadAssembly);
            Item itemA = this.CreateItemAndFile("ItemA_09a", Settings.Instance.CadPart);

            root.Children.Add(assemblyA);
            assemblyA.Children.Add(itemA);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(root);
            selectedItems.Add(assemblyA);
            selectedItems.Add(itemA);

            this.CreateOrUpdateStructureOnServer(root);

            Message.Log("--- create structure B", ConsoleColor.DarkCyan);
            Item assemblyB = this.CreateItemAndFile("AssemblyB_09a", Settings.Instance.CadAssembly);
            Item itemB = this.CreateItemAndFile("ItemB_09a", Settings.Instance.CadPart);

            assemblyB.Children.Add(itemB);

            selectedItems = new List<Item>();
            selectedItems.Add(assemblyB);
            selectedItems.Add(itemB);

            this.CreateOrUpdateStructureOnServer(assemblyB);

            Message.Log("--- add B to A", ConsoleColor.DarkCyan);
            assemblyA.Children.Add(assemblyB);
            this.ModifyFileLocally(assemblyA, "modified file");
            this.ModifyFileLocally(assemblyB, "modified file");

            selectedItems = new List<Item>();
            selectedItems.Add(root);
            selectedItems.Add(assemblyA);
            selectedItems.Add(assemblyB);
            selectedItems.Add(itemB);

            this.CreateOrUpdateStructureOnServer(root);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            Item res = this.LoadStructure(root, selectedItems);

            Message.Log("--- Check result", ConsoleColor.DarkCyan);
            this.CheckStructure(res, root);
        }

        /// <summary>
        /// Add New Assembly To Existing Assembly
        /// </summary>
        public void TestAranxi33_10_AddNewAssemblyToExistingAssembly()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- AssemblyB", ConsoleColor.DarkCyan);
            Item assemblyA = this.CreateItemAndFile("AssemblyA", Settings.Instance.CadAssembly);
            Item itemA = this.CreateItemAndFile("ItemA", Settings.Instance.CadPart);

            assemblyA.Children.Add(itemA);

            this.CreateOrUpdateStructureOnServer(assemblyA);

            Message.Log("--- AssemblyB", ConsoleColor.DarkCyan);
    
            Item assemblyB = this.CreateItemAndFile("AssemblyB", Settings.Instance.CadAssembly);
            Item itemB = this.CreateItemAndFile("ItemB", Settings.Instance.CadPart);

            assemblyB.Children.Add(itemB);
            assemblyA.Children.Add(assemblyB);
            this.ModifyFileLocally(assemblyA, "modified file");

            List<Item> items = new List<Item>();
            items.Add(assemblyA);
            items.Add(assemblyB);
            items.Add(itemB);
            items.Add(itemA);

            Message.Log("--- create structure", ConsoleColor.DarkCyan);
            this.CreateOrUpdateStructureOnServer(assemblyA);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            Item res = this.LoadStructure(assemblyA, items);

            Message.Log("--- res", ConsoleColor.DarkCyan);
            this.CheckStructure(res, assemblyA);
        }

        /// <summary>
        /// Add New Assembly To Existing Assembly embracing
        /// </summary>
        public void TestAranxi33_10a_AddNewAssemblyToExistingAssembly()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item root = this.CreateItemAndFile("Root_10a", Settings.Instance.CadAssembly);
            Item assemblyA = this.CreateItemAndFile("AssemblyA_10a", Settings.Instance.CadAssembly);
            Item itemA = this.CreateItemAndFile("ItemA_10a", Settings.Instance.CadPart);

            root.Children.Add(assemblyA);
            assemblyA.Children.Add(itemA);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(root);
            selectedItems.Add(assemblyA);
            selectedItems.Add(itemA);

            Message.Log("--- create structure", ConsoleColor.DarkCyan);
            this.CreateOrUpdateStructureOnServer(root);

            Message.Log("--- AssemblyB", ConsoleColor.DarkCyan);

            Item assemblyB = this.CreateItemAndFile("AssemblyB_10a", Settings.Instance.CadAssembly);
            Item itemB = this.CreateItemAndFile("ItemB_10a", Settings.Instance.CadPart);

            assemblyB.Children.Add(itemB);
            assemblyA.Children.Add(assemblyB);
            this.ModifyFileLocally(assemblyA, "modified file");

            selectedItems = new List<Item>();
            selectedItems.Add(root);
            selectedItems.Add(assemblyA);
            selectedItems.Add(assemblyB);
            selectedItems.Add(itemB);

            Message.Log("--- create structure", ConsoleColor.DarkCyan);
            this.CreateOrUpdateStructureOnServer(root);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            Item res = this.LoadStructure(root, selectedItems);

            Message.Log("--- res", ConsoleColor.DarkCyan);
            this.CheckStructure(res, root);
        }

        /// <summary>
        /// Delete Assembly From Existing Assembly 
        /// </summary>
        public void TestAranxi33_11_DeleteAssemblyFromExistingAssembly()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- create structure A", ConsoleColor.DarkCyan);
            Item assemblyA = this.CreateItemAndFile("AssemblyA", Settings.Instance.CadAssembly);
            Item itemA = this.CreateItemAndFile("ItemA", Settings.Instance.CadPart);            

            Message.Log("--- create structure B", ConsoleColor.DarkCyan);
            Item assemblyB = this.CreateItemAndFile("AssemblyB", Settings.Instance.CadAssembly);
            Item itemB = this.CreateItemAndFile("ItemB", Settings.Instance.CadPart);

            assemblyB.Children.Add(itemB);
            assemblyA.Children.Add(itemA);
            assemblyA.Children.Add(assemblyB);

            this.CreateOrUpdateStructureOnServer(assemblyA);

            Message.Log("--- delete structure B", ConsoleColor.DarkCyan);
            this.ModifyFileLocally(assemblyA, "del");
            assemblyA.Children.Remove(assemblyB);
            this.Check(assemblyA.Children.Count == 1);

            this.CreateOrUpdateStructureOnServer(assemblyA);
            
            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);

            List<Item> items = new List<Item>();
            items.Add(assemblyA);
            items.Add(itemA);

            Item loadRes = this.LoadStructure(assemblyA, items);

            // recreate assemblyA, because it was deformed by Engine.SetProperties
            assemblyA.Children.Clear();
            assemblyA.Children.Add(itemA);

            this.CheckStructure(loadRes, assemblyA);             
        }

        /// <summary>
        /// Delete Assembly From Existing Assembly embracing
        /// </summary>
        public void TestAranxi33_11a_DeleteAssemblyFromExistingAssembly()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- create structure A", ConsoleColor.DarkCyan);
            Item root = this.CreateItemAndFile("Root_11a", Settings.Instance.CadAssembly);
            Item assemblyA = this.CreateItemAndFile("AssemblyA_11a", Settings.Instance.CadAssembly);
            Item itemA = this.CreateItemAndFile("ItemA_11a", Settings.Instance.CadPart);

            Message.Log("--- create structure B", ConsoleColor.DarkCyan);
            Item assemblyB = this.CreateItemAndFile("AssemblyB_11a", Settings.Instance.CadAssembly);
            Item itemB = this.CreateItemAndFile("ItemB_11a", Settings.Instance.CadPart);

            assemblyB.Children.Add(itemB);

            assemblyA.Children.Add(itemA);
            assemblyA.Children.Add(assemblyB);
            root.Children.Add(assemblyA);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(root);
            selectedItems.Add(assemblyA);
            selectedItems.Add(itemA);
            selectedItems.Add(assemblyB);
            selectedItems.Add(itemB);

            this.CreateOrUpdateStructureOnServer(root);

            Message.Log("--- delete structure B", ConsoleColor.DarkCyan);
            assemblyA.Children.Remove(assemblyB);
            this.ModifyFileLocally(assemblyA, "del");
            selectedItems.Clear();
            selectedItems.Add(root);
            selectedItems.Add(assemblyA);
            selectedItems.Add(itemA);

            this.CreateOrUpdateStructureOnServer(root);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            foreach (Item i in selectedItems)
            {
                this.DeleteFileLocally(i);
            }

            Item loadRes = this.LoadStructure(root, selectedItems);

            // recreate assemblyA, because it was deformed by Engine.SetProperties
            assemblyA.Children.Clear();
            assemblyA.Children.Add(itemA);

            this.CheckStructure(loadRes, root);
        }

        /*
        public void TestAranxi33_13_ChangeItemWhichIsUsedTwice()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);


            Item assembly = this.CreateItemAndFile("AssemblyA", Settings.Instance.CadAssembly);
            Item itemA = this.CreateItemAndFile("ItemA", Settings.Instance.CadPart);
            Item itemB = this.CreateItemAndFile("ItemA", Settings.Instance.CadPart);
            Item itemC = this.CreateItemAndFile("ItemA", Settings.Instance.CadPart);

            assembly.Children.Add(itemA);
            assembly.Children.Add(itemB);
            assembly.Children.Add(itemC);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(assembly);
            selectedItems.Add(itemA);
            selectedItems.Add(itemB);
            selectedItems.Add(itemC);

            Message.Log("--- create structure", ConsoleColor.DarkCyan);
            this.CreateOrUpdateStructureOnServer(assembly);
            Backend.Instance.DoQueryItem(itemA);
            Message.Log("item.generation " + itemA.generation);
            Backend.Instance.DoQueryItem(itemB);
            Message.Log("item.generation " + itemA.generation);
            Backend.Instance.DoQueryItem(itemC);
            Message.Log("item.generation " + itemA.generation);
            Backend.Instance.DoQueryItem(assembly);
            Message.Log("assembly.generation " + assembly.generation);


            this.ModifyFileLocally(assembly, "modified file");
            this.ModifyFileLocally(itemB, "modified file");

           // assembly.NeedToUploadFile = true; - we need to add it in Engine.SelectAllParents
            selectedItems.Clear();
            selectedItems.Add(itemB);

            Message.Log("--- create structure", ConsoleColor.DarkCyan);
            this.CreateOrUpdateStructureOnServer(assembly);


            this.DeleteFileLocally(itemB);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            Item res = this.LoadStructure(assembly, selectedItems);

            Message.Log("--- res", ConsoleColor.DarkCyan);

            Message.Log("modified?");
            string content = this.ReadFileLocally(itemB);
            this.Check(content == "modified file");
        }*/

        /// <summary>
        /// Delete Then Restore
        /// </summary>
        public void TestAranxi33_14_DeleteThenRestore()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- create ", ConsoleColor.DarkCyan);
            Item assembly = this.CreateItemAndFile("AssemblyA", Settings.Instance.CadAssembly);
            Item item = this.CreateItemAndFile("ItemA", Settings.Instance.CadPart);

            assembly.Children.Add(item);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(assembly);
            selectedItems.Add(item);

            this.CreateOrUpdateStructureOnServer(assembly);

            Message.Log("--- delete", ConsoleColor.DarkCyan);
            assembly.Children.Remove(item);
            this.ModifyFileLocally(assembly, "del");
            this.Check(assembly.Children.Count == 0);
            selectedItems.Clear();
            selectedItems.Add(assembly);
            this.CreateOrUpdateStructureOnServer(assembly);

            Message.Log("--- restore", ConsoleColor.DarkCyan);
            assembly.Children.Clear();
            assembly.Children.Add(item);
            this.ModifyFileLocally(assembly, "add");
            selectedItems.Clear();
            selectedItems.Add(assembly);
            this.CreateOrUpdateStructureOnServer(assembly);
            
            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            foreach (Item i in selectedItems)
            {
                this.DeleteFileLocally(i);
            }

            Item res = this.LoadStructure(assembly, selectedItems);

            this.CheckStructure(res, assembly);
        }

        /// <summary>
        /// Increase Generation
        /// </summary>
        public void TestAranxi33_15_IncreaseGeneration()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- create structure", ConsoleColor.DarkCyan);
            Item assembly = this.CreateItemAndFile("Assembly", Settings.Instance.CadAssembly);
            Item itemA = this.CreateItemAndFile("ItemA", Settings.Instance.CadPart);
            Item itemB = this.CreateItemAndFile("ItemB", Settings.Instance.CadPart);

            assembly.Children.Add(itemA);
            assembly.Children.Add(itemB);

            this.CreateOrUpdateStructureOnServer(assembly);

            Message.Log("--- update file", ConsoleColor.DarkCyan);
            this.ModifyFileLocally(assembly, "mod");
            this.ModifyFileLocally(itemA, "mod");

            this.CreateOrUpdateStructureOnServer(assembly);

            Backend.Instance.DoQueryItem(assembly);
            Backend.Instance.DoQueryItem(itemA);
            Backend.Instance.DoQueryItem(itemB);

            Message.Log("--- Test Generation", ConsoleColor.DarkCyan);

            Message.Log("assembly.generation " + assembly.Generation);
            Message.Log("itemA.generation " + itemA.Generation);
            Message.Log("itemB.generation " + itemB.Generation);

            if (Settings.Instance.Versioning == true)
            {
                this.Check(assembly.Generation == "2");
                this.Check(itemA.Generation == "2");
                this.Check(itemB.Generation == "1");
            }
            else
            {
                this.Check(assembly.Generation == "1");
                this.Check(itemA.Generation == "1");
                this.Check(itemB.Generation == "1");
            }

            List<Item> items = new List<Item>();
            items.Add(assembly);
            items.Add(itemA);
            items.Add(itemB);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            Item res = this.LoadStructure(assembly, items);

            this.CheckStructure(res, assembly);

            Message.Log("modified?");
            string content = this.ReadFileLocally(assembly);
            this.Check(content == "mod");

            content = this.ReadFileLocally(itemA);
            this.Check(content == "mod");

            content = this.ReadFileLocally(itemB);
            this.Check(content == "Initial");
        }
        
        /// <summary>
        /// Change Class Part->Assembly
        /// </summary>
        public void TestAranxi33_16_ChangeClass()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- create", ConsoleColor.DarkCyan);
            Item item = this.GetPart("ItemA");

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(item);

            // cleanup and create files
            this.CreateFileLocally(item);

            this.CreateOrUpdateStructureOnServer(item);

            Message.Log("--- change class to CadAssembly", ConsoleColor.DarkCyan);

            item.Class = Settings.Instance.CadAssembly;
            this.ModifyFileLocally(item, "Modified file contents");
            bool exceptionCatched = false;
            try
            {
                this.CreateOrUpdateStructureOnServer(item);
            }
            catch (ExceptionItemNameNotUnique)
            {
                exceptionCatched = true;
            }

            this.Check(exceptionCatched == true);
        }

        /// <summary>
        /// Change Class Assembly->Part
        /// </summary>
        public void TestAranxi33_16a_ChangeClass()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- create", ConsoleColor.DarkCyan);
            Item item = this.GetAssembly("AssemblyA");

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(item);

            // cleanup and create files
            this.CreateFileLocally(item);

            this.CreateOrUpdateStructureOnServer(item);

            Message.Log("--- change class to CadPart", ConsoleColor.DarkCyan);

            item.Class = Settings.Instance.CadPart;
            this.ModifyFileLocally(item, "Modified file contents");

            this.CreateOrUpdateStructureOnServer(item);

            this.Check(item.Class == Settings.Instance.CadAssembly);
        }

        /// <summary>
        /// Change Class Drawing->Part
        /// </summary>
        public void TestAranxi33_16b_ChangeClass()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- create", ConsoleColor.DarkCyan);
            Item item = this.GetDrawing("DrawingA");

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(item);

            // cleanup and create files
            this.CreateFileLocally(item);

            this.CreateOrUpdateStructureOnServer(item);

            Message.Log("--- change class to CadPart", ConsoleColor.DarkCyan);

            item.Class = Settings.Instance.CadPart;
            this.ModifyFileLocally(item, "Modified file contents");

            this.CreateOrUpdateStructureOnServer(item);

            this.Check(item.Class == Settings.Instance.CadDrawing);
        }

        /// <summary>
        /// Change Class Drawing->Assembly
        /// </summary>
        public void TestAranxi33_16c_ChangeClass()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- create", ConsoleColor.DarkCyan);
            Item item = this.GetDrawing("DrawingA");

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(item);

            // cleanup and create files
            this.CreateFileLocally(item);

            this.CreateOrUpdateStructureOnServer(item);

            Message.Log("--- change class to CadAssembly", ConsoleColor.DarkCyan);

            item.Class = Settings.Instance.CadAssembly;
            this.ModifyFileLocally(item, "Modified file contents");

            bool exceptionCatched = false;
            try
            {
                this.CreateOrUpdateStructureOnServer(item);
            }
            catch (ExceptionItemNameNotUnique)
            {
                exceptionCatched = true;
            }

            this.Check(exceptionCatched == true);
        }

        /// <summary>
        /// Lock Before Update (a locked item must remain locked)
        /// </summary>
        public void TestAranxi33_17_LockBeforeUpdate()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            // items
            Item item = this.GetPart("ItemA");

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(item);

            // cleanup and create files
            this.CreateFileLocally(item);

            Message.Log("--- create structure", ConsoleColor.DarkCyan);
            this.CreateOrUpdateStructureOnServer(item);

            Backend.Instance.DoLockUnlock(item, true);

            Message.Log("--- modify file", ConsoleColor.DarkCyan);
            string modification = "Modified file contents";
            this.ModifyFileLocally(item, modification);

            Message.Log("--- Update Structure", ConsoleColor.DarkCyan);
            this.CreateOrUpdateStructureOnServer(item);

            Backend.Instance.DoQueryItem(item);
            this.Check(item.PwbIsCheckedOutBy != null);
        }

        /// <summary>
        /// Lock Before Update (an unlocked item must remain unlocked)
        /// </summary>
        public void TestAranxi33_17a_LockBeforeUpdate()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            // items
            Item item = this.GetPart("ItemA");

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(item);

            // cleanup and create files
            this.CreateFileLocally(item);

            Message.Log("--- create structure", ConsoleColor.DarkCyan);
            this.CreateOrUpdateStructureOnServer(item);

            Backend.Instance.DoLockUnlock(item, false);

            Message.Log("--- modify file", ConsoleColor.DarkCyan);
            string modification = "Modified file contents";
            this.ModifyFileLocally(item, modification);

            Message.Log("--- Update Structure", ConsoleColor.DarkCyan);
            this.CreateOrUpdateStructureOnServer(item);

            Backend.Instance.DoQueryItem(item);
            this.Check(item.PwbIsCheckedOutBy == null);
        }
    }
}
