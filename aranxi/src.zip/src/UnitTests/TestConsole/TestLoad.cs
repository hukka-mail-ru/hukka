// -----------------------------------------------------------------------
// <copyright file="TestLoad.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Text;
    using System.Threading;

    using TSI.PDM.BL;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Test Load     
    /// </summary>
    public partial class UnitTests
    {
        /// <summary>
        /// Query "DocumentNumber1" and then try load it        
        /// </summary>
        public void TestLoad_SingleFile()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item item = this.GetPart("ItemA");
            this.DeleteItemOnServer(item);
            this.CreateFileLocally(item);
            this.CreateItemOnServer(item);

            Backend.Instance.DoQueryItem(item);

            Message.Log("Item found?");
            this.Check(item.ItemServerState == Item.ServerState.Existing);

            Message.Log("\n\n------------> File must be downloaded if DownloadedFiles.Xml not exist");
            File.Delete(Settings.Instance.DownloadedFilesXml);
            Backend.DownloadStatus st = Backend.Instance.DoLoadSingleFile(item, false, false);
            Message.Log("File downloaded?");
            this.Check(st == Backend.DownloadStatus.Downloaded);

            Message.Log("\n\n------------> File must be downloaded if it doesn't exist ");
            this.DeleteFileLocally(item);
            st = Backend.Instance.DoLoadSingleFile(item, false, false);
            Message.Log("File downloaded?");
            this.Check(st == Backend.DownloadStatus.Downloaded);

            Message.Log("\n\n------------> File must NOT be downloaded if it's up to date ");
            st = Backend.Instance.DoLoadSingleFile(item, false, false);
            Message.Log("File not downloaded?");
            this.Check(st != Backend.DownloadStatus.Downloaded);

            Message.Log("\n\n------------> File must be downloaded if is modified locally ");
     
            Thread.Sleep(2000);
            this.ModifyFileLocally(item, "modifications");
            st = Backend.Instance.DoLoadSingleFile(item, false, false);
            Message.Log("File downloaded?");
            this.Check(st == Backend.DownloadStatus.Downloaded);
        }

        /// <summary>
        /// Load Deleted Single File
        /// </summary>
        public void TestLoad_DeletedSingleFile()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item item = this.GetPart("ItemA");
            this.DeleteItemOnServer(item);
            this.DeleteFileLocally(item);

            try
            {
                Backend.DownloadStatus st = Backend.Instance.DoLoadSingleFile(item, false, false);
            }
            catch (Exception e)
            {
                Message.Log("TEST OK: EXCEPTION CATCHED: ");
                Message.Log(e);
                return;
            }

            this.Check(false);
        }
    }
}
