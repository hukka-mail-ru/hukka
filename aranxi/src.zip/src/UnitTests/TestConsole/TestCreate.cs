// -----------------------------------------------------------------------
// <copyright file="TestCreate.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Text;

    using TSI.PDM.BL;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Test Create
    /// </summary>
    public partial class UnitTests
    {
        /*
        public void TestCreate_ParentAndChild()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("\n\n+++++++++++++++ delete UpdateFiles.xml ++++++++++++++++\n");
            File.Delete(Settings.Instance.UploadedFilesXml);

            Message.Log("\n\n+++++++++++++++ create items ++++++++++++++++\n");
            Item parent = this.GetAssembly("parent");
            Item child = this.GetPart("child");

            List<Item> items = new List<Item>();
            items.Add(parent);
            items.Add(child);

            // relations
            parent.Children.Add(child);

            // files
            Message.Log("\n\n+++++++++++++++ create files ++++++++++++++++\n");
            foreach (Item item in items)
            {
                this.DeleteItemOnServer(item);
                this.DeleteFileLocally(item);
                this.CreateFileLocally(item);
            }

            // create structure
            Message.Log("\n\n+++++++++++++++ create structure on server ++++++++++++++++\n");
            this.CreateOrUpdateStructureOnServer(parent);

            ShowStructure(parent);

            // cleanup
            Message.Log("\n\n+++++++++++++++ cleanup ++++++++++++++++\n");
            foreach (Item item in items)
            {
                this.DeleteFileLocally(item);
            }

            // check the structure
            Message.Log("\n\n+++++++++++++++ expand and check the structure ++++++++++++++++\n");
            Item resItem = Backend.Instance.DoExpand(parent);

            Message.Log("The root item OK?");
            this.Check(resItem.ItemNumber == parent.ItemNumber);

            this.CheckStructure(resItem, parent);
        }


        public void TestCreate_Subassembly()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("\n\n+++++++++++++++ delete UpdateFiles.xml ++++++++++++++++\n");
            File.Delete(Settings.Instance.UploadedFilesXml);

            Message.Log("\n\n+++++++++++++++ create items ++++++++++++++++\n");
            Item parent = this.GetAssembly("parent");
            Item sub_parent = this.GetAssembly("sub-parent");
            Item child = this.GetPart("child");

            List<Item> items = new List<Item>();
            items.Add(parent);
            items.Add(sub_parent);
            items.Add(child);

            // relations
            parent.Children.Add(sub_parent);
            sub_parent.Children.Add(child);

            // files
            Message.Log("\n\n+++++++++++++++ create files ++++++++++++++++\n");
            foreach (Item item in items)
            {
                this.DeleteItemOnServer(item);
                this.DeleteFileLocally(item);
                this.CreateFileLocally(item);
            }

            // create structure
            Message.Log("\n\n+++++++++++++++ create structure on server ++++++++++++++++\n");
            this.CreateOrUpdateStructureOnServer(parent);

            ShowStructure(parent);

            // cleanup
            Message.Log("\n\n+++++++++++++++ cleanup ++++++++++++++++\n");
            foreach (Item item in items)
            {
                this.DeleteFileLocally(item);
            }

            // check the structure
            Message.Log("\n\n+++++++++++++++ expand and check the structure ++++++++++++++++\n");
            Item resItem = Backend.Instance.DoExpand(parent);

            Message.Log("The root item OK?");
            this.Check(resItem.ItemNumber == parent.ItemNumber);

            this.CheckStructure(resItem, parent);
        }


        public void TestCreate_Birdhouse()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("\n\n+++++++++++++++ delete UpdateFiles.xml ++++++++++++++++\n");
            File.Delete(Settings.Instance.UploadedFilesXml);

            Message.Log("\n\n+++++++++++++++ create items ++++++++++++++++\n");
            Item assembly = this.GetAssembly("assembly");
            Item sub_assembly1 = this.GetAssembly("sub_assembly1");

            Item perch = this.GetPart("perch");
            Item front = this.GetPart("front");

            Item side = this.GetPart("side");
            Item leg = this.GetPart("leg");
            Item roof = this.GetPart("roof");
            Item bottom = this.GetPart("bottom");

            List<Item> items = new List<Item>();
            items.Add(assembly);
            items.Add(sub_assembly1);
            items.Add(front);
            items.Add(perch);
            items.Add(side);
            items.Add(leg);
            items.Add(roof);
            items.Add(bottom);

            // relations
            sub_assembly1.Children.Add(perch);
            sub_assembly1.Children.Add(front);

            assembly.Children.Add(sub_assembly1);
            assembly.Children.Add(side);
            assembly.Children.Add(leg);
            assembly.Children.Add(roof);
            assembly.Children.Add(bottom);

            // files
            Message.Log("\n\n+++++++++++++++ copy files from 'skvo' ++++++++++++++++\n");
            foreach (Item item in items)
            {
                this.DeleteItemOnServer(item);
                CopyFileLocally(item, "../skvo");
            }

            // create structure
            Message.Log("\n\n+++++++++++++++ create structure on server ++++++++++++++++\n");
            this.CreateOrUpdateStructureOnServer(assembly);

            ShowStructure(assembly);

            // cleanup
            Message.Log("\n\n+++++++++++++++ cleanup ++++++++++++++++\n");
            foreach (Item item in items)
            {
                this.DeleteFileLocally(item);
            }

            // check the structure
            Message.Log("\n\n+++++++++++++++ expand and check the structure ++++++++++++++++\n");
            Item resItem = Backend.Instance.DoExpand(assembly);

            Message.Log("The root item OK?");
            this.Check(resItem.ItemNumber == assembly.ItemNumber);

            this.CheckStructure(resItem, assembly);

            // update structure
            Message.Log("\n\n+++++++++++++++ update structure on server ++++++++++++++++\n");
            this.CreateOrUpdateStructureOnServer(assembly);
        }



        public void TestCreate_Car()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("\n\n+++++++++++++++ delete UpdateFiles.xml ++++++++++++++++\n");
            File.Delete(Settings.Instance.UploadedFilesXml);

            // items
            Message.Log("\n\n+++++++++++++++ create items ++++++++++++++++\n");
            Item car = this.GetAssembly("Car");
            Item inside = this.GetAssembly("Inside");
            Item outside = this.GetAssembly("Outside");
            Item wheels = this.GetAssembly("Wheels");

            Item engine = this.GetPart("Engine");
            Item seats = this.GetPart("Seats");
            Item corpus = this.GetPart("Corpus");

            Item one = this.GetPart("One");
            Item two = this.GetPart("Two");
            Item three = this.GetPart("Three");
            Item four = this.GetPart("Four");

            List<Item> items = new List<Item>();
            items.Add(car);
            items.Add(inside);
            items.Add(outside);
            items.Add(wheels);
            items.Add(engine);
            items.Add(seats);
            items.Add(corpus);
            items.Add(one);
            items.Add(two);
            items.Add(three);
            items.Add(four);

            // relations
            car.Children.Add(inside);
            car.Children.Add(outside);

            inside.Children.Add(engine);
            inside.Children.Add(seats);

            outside.Children.Add(corpus);
            outside.Children.Add(wheels);

            wheels.Children.Add(one);
            wheels.Children.Add(two);
            wheels.Children.Add(three);
            wheels.Children.Add(four);

            // files
            Message.Log("\n\n+++++++++++++++ create files ++++++++++++++++\n");
            foreach(Item item in items)
            {
                this.DeleteItemOnServer(item);
                this.DeleteFileLocally(item);
                this.CreateFileLocally(item);
            }

            // create structure
            Message.Log("\n\n+++++++++++++++ create structure on server ++++++++++++++++\n");
            this.CreateOrUpdateStructureOnServer(car);

            ShowStructure(car);

            // cleanup
            Message.Log("\n\n+++++++++++++++ cleanup ++++++++++++++++\n");
            foreach (Item item in items)
            {
                this.DeleteFileLocally(item);
            }

            // check the structure
            Message.Log("\n\n+++++++++++++++ expand and test ++++++++++++++++\n");
            Item resItem = Backend.Instance.DoExpand(car);
            
            Message.Log("The root item is Car?");
            this.Check(resItem.ItemNumber == "Car");

            this.CheckStructure(resItem, car);
        }

        public void TestCreate_SelectedItems()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("\n\n+++++++++++++++ delete UpdateFiles.xml ++++++++++++++++\n");
            File.Delete(Settings.Instance.UploadedFilesXml);

            Item car     = this.GetAssembly("Car");
            Item inside  = this.GetAssembly("Inside");
            Item outside = this.GetAssembly("Outside");
            Item addon = this.GetAssembly("Addon");
            Item wheels = this.GetAssembly("Wheels");

            Item engine = this.GetPart("Engine");
            Item seats = this.GetPart("Seats");
            Item corpus = this.GetPart("Corpus");

            Item one = this.GetPart("One");
            Item two = this.GetPart("Two");
            Item three = this.GetPart("Three");
            Item four = this.GetPart("Four");

            
            // relations
            car.Children.Add(inside);
            car.Children.Add(outside);
            car.Children.Add(addon);

            inside.Children.Add(engine);
            inside.Children.Add(seats);

            outside.Children.Add(corpus);
            outside.Children.Add(wheels);

            wheels.Children.Add(one);
            wheels.Children.Add(two);
            wheels.Children.Add(three);
            wheels.Children.Add(four);

            // select not all
            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(inside);
            selectedItems.Add(engine);
            selectedItems.Add(wheels);
            selectedItems.Add(one);
            selectedItems.Add(two);

            List<Item> unsavedItems = new List<Item>();

            Engine.SetProperties(car, unsavedItems);
        
            Message.Log("Selection is OK?");
            this.Check(car.Selected == true);

            this.Check(inside.Selected == true);
            this.Check(outside.Selected == true);
            this.Check(addon.Selected == false);

            this.Check(engine.Selected == true);
            this.Check(seats.Selected == false);
            this.Check(wheels.Selected == true);

            this.Check(one.Selected == true);
            this.Check(two.Selected == true);
            this.Check(three.Selected == false);
            this.Check(four.Selected == false);

            List<Item> allItems = new List<Item>();
            Item.GetAllItems(car, allItems);
            foreach(Item item in allItems)
            {
                Message.Log("item: " + item.ItemNumber + "\t " + 
                    item.ItemOperationState + "\t " + item.ItemModifyState);
            }
        }

        public void TestCreate_FileWithTemplate()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("\n\n+++++++++++++++ delete UpdateFiles.xml ++++++++++++++++\n");
            File.Delete(Settings.Instance.UploadedFilesXml);

            string templateName = "model-plain-1-mm-template";
            Item template = this.GetPart(templateName);
            this.DeleteFileLocally(template);

            Item item = this.GetPart("ItemA");
            this.DeleteItemOnServer(item);
            this.DeleteFileLocally(item);
            this.CreateFileLocally(item);

            // Transmit templated file to server
            Backend.Instance.DoCreateSingleFile(
                item, templateName, Settings.Instance.XmapDir, false);

            // Test
            Backend.Instance.DoQueryItem(item);
            Message.Log("Item is on server?");
            this.Check(item.ItemServerState == Item.ServerState.Existing);

            Message.Log("Template downloaded?");
            this.Check(this.IsFileExistsLocally(template) == true);

        }

        public void TestCreate_SingleFileTwice()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("\n\n+++++++++++++++ delete UpdateFiles.xml ++++++++++++++++\n");
            File.Delete(Settings.Instance.UploadedFilesXml);

            Item item = this.GetPart("ItemA");
            this.DeleteItemOnServer(item);
            this.DeleteFileLocally(item);
            this.CreateFileLocally(item);


            // Transmit the file to server
            Backend.Instance.DoCreateSingleFile(
                item, "default", Settings.Instance.XmapDir, false);

            try
            {
                Backend.Instance.DoCreateSingleFile(
                   item, "default", Settings.Instance.XmapDir, false);
            }
            catch (Exception)
            {
                Message.Log("EXCEPTION CATCHED: TEST OK");
                return;
            }

            this.Check(false);
        }
         */
    }
}