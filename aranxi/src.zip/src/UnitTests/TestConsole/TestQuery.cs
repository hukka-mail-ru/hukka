// -----------------------------------------------------------------------
// <copyright file="TestQuery.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using System.Text;
    using System.Xml.Linq;

    using TSI.PDM.BL;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Test Query
    /// </summary>
    public partial class UnitTests
    {
        /// <summary>
        /// Query PDMAttributes
        /// </summary>
        public void TestQuery_PDMAttributes()
        {
            Item item = new Item();

            item.PDMAttributes.Add(new PDMAttribute { Name = "item_number", Value = "33" });
            item.PDMAttributes.Add(new PDMAttribute { Name = "Class", Value = Settings.Instance.CadPart });
            item.PDMAttributes.Add(new PDMAttribute { Name = "modified_on", Value = "01.01.2011" });
            item.PDMAttributes.Add(new PDMAttribute { Name = "is_template", Value = "1" });
            item.PDMAttributes.Add(new PDMAttribute { Name = "native_file", Value = "item1" });
            item.PDMAttributes.Add(new PDMAttribute { Name = "OBID", Value = "23532523" });
            item.PDMAttributes.Add(new PDMAttribute { Name = "generation", Value = "44" });
            item.PDMAttributes.Add(new PDMAttribute { Name = "description", Value = "55" });

            this.Check(item.ItemNumber == "33");
            this.Check(item.Class == Settings.Instance.CadPart);
            this.Check(item.ModifiedOn == "01.01.2011");
            this.Check(item.IsTemplate == "1");
            this.Check(item.NativeFile == "item1");
            this.Check(item.OBID == "23532523");
            this.Check(item.Generation == "44");
            this.Check(item.Description == "55");

            XElement example = item.ToXML("example");
            Message.Log(example.ToString());

            Item item2 = new Item();
            item2.FromXML(example);

            this.Check(item2.ItemNumber == "33");
            this.Check(item2.Class == Settings.Instance.CadPart);
            this.Check(item2.ModifiedOn == "01.01.2011");
            this.Check(item2.IsTemplate == "1");
            this.Check(item2.NativeFile == "item1");
            this.Check(item2.OBID == "23532523");
            this.Check(item2.Generation == "44");
            this.Check(item2.Description == "55");

            Item item3 = new Item();
            item3.ItemNumber = "33";
            item3.Class = Settings.Instance.CadPart;
            item3.ModifiedOn = "01.01.2011";
            item3.IsTemplate = "1";
            item3.NativeFile = "item1";
            item3.OBID = "23532523";
            item3.Generation = "44";
            item3.Description = "55";

            Message.Log(item3.ItemNumber);
            this.Check(item3.ItemNumber == "33");
            this.Check(item3.Class == Settings.Instance.CadPart);
            this.Check(item3.ModifiedOn == "01.01.2011");
            this.Check(item3.IsTemplate == "1");
            this.Check(item3.NativeFile == "item1");
            this.Check(item3.OBID == "23532523");
            this.Check(item3.Generation == "44");
            this.Check(item3.Description == "55");

            Item item4 = new Item();
            item4.Copy(item3);

            this.Check(item4.ItemNumber == "33");
            this.Check(item4.Class == Settings.Instance.CadPart);
            this.Check(item4.ModifiedOn == "01.01.2011");
            this.Check(item4.IsTemplate == "1");
            this.Check(item4.NativeFile == "item1");
            this.Check(item4.OBID == "23532523");
            this.Check(item4.Generation == "44");
            this.Check(item4.Description == "55");
        }

        /// <summary>
        /// Find Items
        /// </summary>
        public void TestQuery_FindItems()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item itemA = this.GetPart("ItemA");
            this.DeleteItemOnServer(itemA);
            this.CreateItemOnServer(itemA);

            Item itemB = this.GetPart("ItemB");
            this.DeleteItemOnServer(itemB);
            this.CreateItemOnServer(itemB);

            Item match = new Item
            {
                ItemNumber = "*",
                Class = Settings.Instance.CadPart
            };

            List<Item> items = Backend.Instance.DoFindItems(match);
            
            bool foundA = false;
            bool foundB = false;
            foreach (Item item in items)
            {
                if (item.ItemNumber == itemA.ItemNumber)
                {
                    foundA = true;
                }

                if (item.ItemNumber == itemB.ItemNumber)
                {
                    foundB = true;
                }
            }

            this.Check(foundA == true);
            this.Check(foundB == true);
        }

        /// <summary>
        /// Query Structure
        /// </summary>
        public void TestQuery_Structure()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item item = this.GetPart("ItemA");

            Message.Log("Item number: " + item.ItemNumber);

            this.DeleteItemOnServer(item);

            Message.Log("Item number: " + item.ItemNumber);

            Backend.Instance.DoQueryItem(item);

            Message.Log("Item number: " + item.ItemNumber);
            Message.Log("Item new?");
            this.Check(item.ItemServerState == Item.ServerState.New);

            this.CreateItemOnServer(item);

            Backend.Instance.DoQueryItem(item);
            Message.Log("Item exists?");
            this.Check(item.ItemServerState == Item.ServerState.Existing);
        }

        /// <summary>
        /// Query Item
        /// </summary>
        public void TestQuery_Item()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item item = this.GetPart("ItemA");
            this.DeleteItemOnServer(item);
            this.CreateItemOnServer(item);

            Backend.Instance.DoQueryItem(item);

            Message.Log("Item found?");
            this.Check(item.ItemServerState == Item.ServerState.Existing);
        }

        /// <summary>
        /// Query Deleted Item
        /// </summary>
        public void TestQuery_DeletedItem()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item item = this.GetPart("ItemA");
            this.DeleteItemOnServer(item);
            Backend.Instance.DoQueryItem(item);

            Message.Log("Item not found?");
            this.Check(item.ItemServerState != Item.ServerState.Existing);
        }    
    }
}
