// -----------------------------------------------------------------------
// <copyright file="TestLock.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using System.Text;

    using TSI.PDM.BL;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Test Lock
    /// </summary>
    public partial class UnitTests
    {
        /// <summary>
        /// Lock Item
        /// </summary>
        public void TestLock_LockItem()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item item = this.GetPart("ItemA");
            this.CreateItemOnServer(item);

            Backend.Instance.DoLockUnlock(item, true);            
            Backend.Instance.DoQueryItem(item);

            Message.Log("Item locked?");
            this.Check(item.PwbIsCheckedOutBy == "admin");
        }

        /// <summary>
        /// Lock Assembly
        /// </summary>
        public void TestLock_LockAssembly()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item item = this.GetAssembly("AssemblyA");
            this.CreateItemOnServer(item);

            Backend.Instance.DoLockUnlock(item, true);
            Backend.Instance.DoQueryItem(item);

            Message.Log("Item locked?");
            this.Check(item.PwbIsCheckedOutBy == "admin");
        }

        /// <summary>
        /// Unlock Item
        /// </summary>
        public void TestLock_UnlockItem()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item item = this.GetPart("ItemA");
            this.CreateItemOnServer(item);

            Backend.Instance.DoLockUnlock(item, false);
            Backend.Instance.DoQueryItem(item);

            Message.Log("Item unlocked?");
            this.Check(item.PwbIsCheckedOutBy == null);
        }

        /// <summary>
        /// Lock Deleted Item
        /// </summary>
        public void TestLock_DeletedItem()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item item = this.GetPart("ItemA");

            try
            {
                Backend.Instance.DoLockUnlock(item, true);
            }
            catch (Exception)
            {
                Message.Log("EXCEPTION CATCHED: TEST OK");
                return;
            }

            this.Check(false);
        }
    }
}
