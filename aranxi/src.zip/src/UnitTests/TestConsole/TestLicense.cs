﻿// -----------------------------------------------------------------------
// <copyright file="TestLicense.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using System.Text;
    using TSI.PDM.BL;

    /// <summary>
    /// Test License
    /// </summary>
    public partial class UnitTests
    {
        /// <summary>
        /// Test of allocation of License
        /// </summary>
        public void TestLicense()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Engine.CheckLicense();
        }
    }
}
