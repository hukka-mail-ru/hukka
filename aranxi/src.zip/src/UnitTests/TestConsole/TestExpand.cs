﻿// -----------------------------------------------------------------------
// <copyright file="TestExpand.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Text;
    using System.Threading;

    using TSI.PDM.BL;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Test Expand
    /// </summary>
    public partial class UnitTests
    {
        /// <summary>
        /// Expand Part
        /// </summary>
        public void TestExpandPart()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item itemA = this.CreateItemAndFile("ItemA", Settings.Instance.CadPart);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(itemA);
            
            Message.Log("+++++++++++++++ create structure ++++++++++++++++");
            this.CreateOrUpdateStructureOnServer(itemA);

            Backend.Instance.DoQueryItem(itemA);

            try
            {
                Item res = Backend.Instance.DoExpand(itemA);
                this.Check(false);
            }
            catch (ExceptionItemNotExpandable)
            {
                this.Check(true);
            }
        }

        /// <summary>
        /// Expand Empty Assembly
        /// </summary>
        public void TestExpandEmptyAssembly()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item assemblyA = this.CreateItemAndFile("ItemA", Settings.Instance.CadAssembly);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(assemblyA);

            Message.Log("+++++++++++++++ create structure ++++++++++++++++");
            this.CreateOrUpdateStructureOnServer(assemblyA);

            Backend.Instance.DoQueryItem(assemblyA);

            try
            {
                Item res = Backend.Instance.DoExpand(assemblyA);
                this.Check(false);
            }
            catch (ExceptionItemNotExpandable)
            {
                this.Check(true);
            }
        }

        /// <summary>
        /// Expand Assembly
        /// </summary>
        public void TestExpandAssembly()
        {
            this.ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item assemblyA = this.CreateItemAndFile("AssemblyA", Settings.Instance.CadAssembly);
            Item itemA = this.CreateItemAndFile("ItemA", Settings.Instance.CadPart);

            assemblyA.Children.Add(itemA);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(itemA);
            selectedItems.Add(assemblyA);

            Message.Log("+++++++++++++++ create structure ++++++++++++++++");
            this.CreateOrUpdateStructureOnServer(assemblyA);

            Backend.Instance.DoQueryItem(itemA);

            Item res = Backend.Instance.DoExpand(itemA);

            Message.LogHi(res.Parent.ItemNumber);
        }
    }
}
