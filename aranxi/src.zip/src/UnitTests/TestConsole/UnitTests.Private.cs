﻿// -----------------------------------------------------------------------
// <copyright file="UnitTests.Private.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;

    using TSI.PDM.BL;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Private methods
    /// </summary>
    public partial class UnitTests
    {
        /// <summary>
        /// A debug method: show all the structure
        /// </summary>
        /// <param name="item">the root item</param>
        private void ShowStructure(Item item)
        {
            Message.Log("item: " + item.ItemNumber +
                        "; server state: " + item.ItemServerState.ToString() +
                        "; local state: " + item.RelationServerState.ToString() +
                        "; parent: " + (item.HasParent ? item.Parent.ItemNumber : "NULL"));

            // find each child recursively
            foreach (Item child in item.Children)
            {
                this.ShowStructure(child);
            }
        }

        /// <summary>
        /// Create a new item on server
        /// </summary>
        /// <param name="item">the item</param>
        private void CreateItemOnServer(Item item)
        {
            // select it
            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(item);

            // cleanup and create files
            this.CreateFileLocally(item);
            
            this.CreateOrUpdateStructureOnServer(item);
        }

        /// <summary>
        /// Update an existing item on server
        /// TODO! make it like CreateItemOnServer
        /// </summary>
        /// <param name="item">the item</param>
        /// <returns>the server result</returns>
        private Item UpdateItemOnServer(Item item)
        {
          // item.NeedToUploadFile = true;
          // item.ItemModifyState = Item.ModifyState.ChangedLocally;
          // Item resItem = Backend.Instance.DoUpdateItem(item);

          // Message.Log("Is item updated?");
          // this.Check(resItem.item_number == item.item_number);
            return new Item();
        }

        /// <summary>
        /// Deletes an item on ARAS server if the item exists
        /// </summary>
        /// <param name="item">the item</param>
        private void DeleteItemOnServer(Item item)
        {
            Backend.Instance.DoQueryItem(item);
            if (item.ItemServerState == Item.ServerState.Existing)
            {
                Backend.Instance.DoDeleteItem(item);
            }
        }

        /// <summary>
        /// Deletes an file (corresponding to an item) locally
        /// </summary>
        /// <param name="item">the item</param>
        private void DeleteFileLocally(Item item)
        {
            string filename = item.GetFullLocalFileName(Settings.Instance.XmapDir);

            File.Delete(filename);

            Message.Log("Local file deleted: " + filename);
        }

        /// <summary>
        /// Create a file (corresponding to an item) locally
        /// </summary>
        /// <param name="item">the item</param>
        private void CreateFileLocally(Item item)
        {
            string filename = item.GetFullLocalFileName(Settings.Instance.XmapDir);

            System.IO.StreamWriter file = new System.IO.StreamWriter(filename);
            file.WriteLine("Initial");
            file.Close();

            Message.Log("Local file created: " + filename);
        }

        /// <summary>
        /// Copy a file (corresponding to an item) locally
        /// </summary>
        /// <param name="item">the item</param>
        /// <param name="srcDir">source dir</param>
        private void CopyFileLocally(Item item, string srcDir)
        {
            string sourceFileName = item.GetFullLocalFileName(Path.Combine(Settings.Instance.XmapDir, srcDir));
            string destFileName = item.GetFullLocalFileName(Settings.Instance.XmapDir);

            Message.Log("Copy file: " + sourceFileName + " -> " + destFileName);

            File.Copy(sourceFileName, destFileName, true);
        }

        /// <summary>
        ///  Modify a file (corresponding to an item) locally
        /// </summary>
        /// <param name="item">the item</param>
        /// <param name="modification">the modification</param>
        private void ModifyFileLocally(Item item, string modification)
        {
            string filename = item.GetFullLocalFileName(Settings.Instance.XmapDir);

            System.IO.StreamWriter file = new System.IO.StreamWriter(filename);
            file.WriteLine(modification);
            file.Close();

            Message.Log("Local file modified: " + filename);
        }

        /// <summary>
        ///  Read a file (corresponding to an item) locally
        /// </summary>
        /// <param name="item">the item</param>
        /// <returns>the file content</returns>
        private string ReadFileLocally(Item item)
        {
            string filename = item.GetFullLocalFileName(Settings.Instance.XmapDir);

            System.IO.StreamReader file = new System.IO.StreamReader(filename);
            string res = file.ReadLine();
            file.Close();

            Message.Log("Local file read: " + filename);
            Message.Log("Local file contents: " + res);

            return res;
        }

        /// <summary>
        /// Checks if a file (corresponding to an item) exists locally
        /// </summary>
        /// <param name="item">the item</param>
        /// <returns>true is the file exists</returns>
        private bool IsFileExistsLocally(Item item)
        {
            string filename = item.GetFullLocalFileName(Settings.Instance.XmapDir);

            Message.Log("Checking if file exists: " + filename);

            return File.Exists(filename);
        }

        /// <summary>
        /// Creates a simple item
        /// </summary>
        /// <param name="name">the item name</param>
        /// <returns>the resulting item</returns>
        private Item GetPart(string name)
        {
            Item item = new Item()
            {
                ItemNumber = name,
                Class = Settings.Instance.CadPart
            };

            return item;
        }

        /// <summary>
        /// Cleanup and create item and its file
        /// </summary>
        /// <param name="name">item name</param>
        /// <param name="className">item class</param>
        /// <returns>the item</returns>
        private Item CreateItemAndFile(string name, string className)
        {
            Item item = new Item()
            {
                ItemNumber = name,
                Class = className
            };

            // cleanup and create files
            // this.DeleteItemOnServer(item);
            // this.DeleteFileLocally(item);
            this.CreateFileLocally(item);

            return item;
        }

        /// <summary>
        /// Creates a simple Assembly
        /// </summary>
        /// <param name="name">assembly name</param>
        /// <returns>the assembly</returns>
        private Item GetAssembly(string name)
        {
            Item item = new Item()
            {
                ItemNumber = name,
                Class = Settings.Instance.CadAssembly,
            };

            return item;
        }

        /// <summary>
        /// Creates a simple Drawing
        /// </summary>
        /// <param name="name">Drawing name</param>
        /// <returns>the Drawing</returns>
        private Item GetDrawing(string name)
        {
            Item item = new Item()
            {
                ItemNumber = name,
                Class = Settings.Instance.CadDrawing,
            };

            return item;
        }
       
        /// <summary>
        /// Upload structure to server
        /// </summary>
        /// <param name="root">the root item</param>
        /// <param name="unsavedItems">unsaved Items</param>
        /// <returns>server result</returns>
        private Item CreateOrUpdateStructureOnServer(Item root, List<Item> unsavedItems = null)
        {
            if (unsavedItems == null)
            {
                unsavedItems = new List<Item>();
            }

            // get independentItems and forgottenItems
            Engine.SetProperties(root, unsavedItems);

            /*
            List<Item> allItems = new List<Item>();
            Item.GetAllItems(root, allItems);
            foreach (Item item in allItems)
            {
                Message.Log("item: " + item.item_number + "\t " +
                    item.Operation + "\t " + item.ItemModifyState);
            }*/

            // create or update items 
            return Backend.Instance.DoUpdateItem(root);
        }

        /// <summary>
        /// Log the test result 
        /// </summary>
        /// <param name="state">true if the test is OK</param>
        private void Check(bool state)
        {
            if (!state)
            {
                throw new MyException("TEST FAILED!");
            }
            else
            {
                Message.Log("TEST OK", ConsoleColor.DarkMagenta);
            }
        }

        /// <summary>
        /// Checks if two hierarchical structures are identical
        /// </summary>
        /// <param name="item">root of the first structure</param>
        /// <param name="correctItem">root of the second structure</param>
        private void CheckStructure(Item item, Item correctItem)
        {
            Message.Log(correctItem.ItemNumber + " item_number OK?");
            this.Check(item.ItemNumber == correctItem.ItemNumber);

            Message.Log(correctItem.ItemNumber + ": Children? " + item.Children.Count + ", must be " + correctItem.Children.Count);
            this.Check(item.Children.Count == correctItem.Children.Count);
            
            if (item.Children.Count > 0)
            {
                this.CheckArray(item.Children.ToList(), correctItem.Children.ToList(), "found");
            }

            // find all children recursively
            foreach (Item child in item.Children)
            {
                foreach (Item correctChild in correctItem.Children)
                {
                    if (correctChild.ItemNumber == child.ItemNumber)
                    {
                        this.CheckStructure(child, correctChild);
                    }
                }
            }             
        }

        /// <summary>
        /// Checks if two arrays are identical
        /// </summary>
        /// <param name="items">the first array</param>
        /// <param name="correctItems">the second array</param>
        /// <param name="itemType">a text to display</param>
        private void CheckArray(List<Item> items, List<Item> correctItems, string itemType)
        {
            foreach (Item correctItem in correctItems)
            {
                foreach (Item item in items)
                {
                    if (correctItem.ItemNumber == item.ItemNumber)
                    {
                        correctItem.Description = "FOUND";
                        break;
                    }
                }
            }

            foreach (Item correctItem in correctItems)
            {
                Message.Log("correct item " + correctItem.ItemNumber);
            }

            Message.Log("items ");
            foreach (Item item in items)
            {
                Message.Log("item " + item.ItemNumber);
            }

            Message.Log("items number is ok?");
            this.Check(items.Count == correctItems.Count);

            foreach (Item correctItem in correctItems)
            {
                Message.Log("item " + correctItem.ItemNumber + " is " + itemType + "?");
                this.Check(correctItem.Description == "FOUND");
            }
        }

        /// <summary>
        /// Show TestHeader And Cleanup
        /// </summary>
        /// <param name="name">test name</param>
        private void ShowTestHeaderAndCleanup(string name)
        {
            Message.Log("\n\n\n===  cleanup  " + name + " =====\n");

            for (int i = 0; i < 2; i++)
            {
                // delete assemblies
                List<Item> assemblies = Backend.Instance.DoFindItems(new Item
                {
                    ItemNumber = "*",
                    Class = Settings.Instance.CadAssembly,
                    IsTemplate = "0"
                });

                foreach (Item assembly in assemblies)
                {
                    Backend.Instance.DoDeleteItem(assembly);
                }

                // delete parts
                List<Item> parts = Backend.Instance.DoFindItems(new Item
                {
                    ItemNumber = "*",
                    Class = Settings.Instance.CadPart,
                    IsTemplate = "0"
                });

                foreach (Item part in parts)
                {
                    Backend.Instance.DoDeleteItem(part);
                }

                // delete local prt files
                string[] files = Directory.GetFiles(Settings.Instance.XmapDir, "*.prt");
                foreach (string file in files)
                {
                    File.Delete(file);
                }

                // delete local xml files
                files = Directory.GetFiles(Settings.Instance.XmapDir, "*.xml");
                foreach (string file in files)
                {
                    File.Delete(file);
                }
            }

            Message.Log("\n\n\n===== "  + name + " ==============\n");
            Message.Log("VERSIONING = " + Settings.Instance.Versioning, ConsoleColor.DarkYellow);
        }

        /// <summary>
        /// Cleaunup and load structure
        /// </summary>
        /// <param name="root">the root item</param>
        /// <param name="items">items to check</param>
        /// <returns>the server response</returns>
        private Item LoadStructure(Item root, List<Item> items)
        {
            foreach (Item item in items)
            {
                this.DeleteFileLocally(item);
            }

            // Load all
            Item responseItem = new Item();
            try
            {
                responseItem = Backend.Instance.DoExpand(root);
            }
            catch (ExceptionItemNotExpandable)
            {
                responseItem = root;
            }

            this.ShowStructure(responseItem);

            Backend.Instance.DoLoadStructure(responseItem, false);

            // all exist?
            foreach (Item item in items)
            {
                this.Check(this.IsFileExistsLocally(item));
            }

            return responseItem;
        }

        /// <summary>
        /// Create Assembly With Child
        /// </summary>
        /// <param name="assemblyName">assembly Name</param>
        /// <param name="childName">child Name</param>
        /// <returns>the assembly</returns>
        private Item CreateAssemblyWithChild(string assemblyName, string childName)
        {
            Message.Log("+++++++++++++++ " + assemblyName + " ++++++++++++++++");
            Item assembly = this.CreateItemAndFile(assemblyName, Settings.Instance.CadAssembly);
            Item item = this.CreateItemAndFile(childName, Settings.Instance.CadPart);

            assembly.Children.Add(item);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(assembly);
            selectedItems.Add(item);

            Message.Log("+++++++++++++++ create structure ++++++++++++++++");
            this.CreateOrUpdateStructureOnServer(assembly);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.Generation);
            Backend.Instance.DoQueryItem(assembly);
            Message.Log("assembly.generation " + assembly.Generation);

            return assembly;
        }
    }
}
