﻿// -----------------------------------------------------------------------
// <copyright file="ArasCli.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace ArasCli
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Linq;
    using System.Text;

    using TSI.PDM.BL;
    using TSI.PDM.DataStore;

    /// <summary>
    /// A command-line tool for operating the Aras server
    /// </summary>
    internal class ArasCli
    {
        /// <summary>
        /// display level
        /// </summary>
        private enum DisplayLevel
        {
            /// <summary>
            /// no log messages
            /// </summary>
            Short,

            /// <summary>
            /// display log messages
            /// </summary>
            Verbose
        }

        /// <summary>
        /// The main function
        /// </summary>
        /// <param name="args">the args</param>
        public static void Main(string[] args)
        {
            try
            {
                ArasCli cli = new ArasCli();

                if (args.Length == 0)
                {
                    Console.WriteLine("no arguments.");
                    return;
                }

                string command = args[0];
                if (args.Length == 1)
                {
                    switch (command)
                    {
                        case "other":
                            cli.Other();
                            return;
                        default:
                            Console.WriteLine("no arguments of command " + command);
                            return;
                    }
                }

                // initialize
                Settings.Instance.UnitTest = true;
                Settings.Instance.EnableLogging = false;

                // Settings must be initialized very first, because all parts of the application use it!
                Settings.Instance.Initialize();

                Backend.Instance.Startup();

                Credentials cred =
                    new Credentials("admin", "innovator", Settings.Instance.Databases.Entries[0].Name);

                Backend.Instance.DoLogin(cred);

                // perform a command
                switch (command)
                {
                    case "find":
                        cli.FindAndDisplay(args[1], DisplayLevel.Short);
                        break;

                    case "stat":
                        cli.FindAndDisplay(args[1], DisplayLevel.Verbose);                      
                        break;

                    case "rm":
                        cli.FindAndDelete(args[1]);                        
                        break;

                    default:
                        Console.WriteLine("Unknown command.");
                        break;
                }

                // logout
                Backend.Instance.DoLogout();
            }
            catch (Exception e)
            {
                Message.Log(e);
            }            
        }

        /// <summary>
        /// Find And Display
        /// </summary>
        /// <param name="itemNumber">the item id</param>
        /// <param name="level">Display Level</param>
        private void FindAndDisplay(string itemNumber, DisplayLevel level)
        {
            List<Item> resItems = this.Find(itemNumber);

            Console.WriteLine("found: " + resItems.Count);
            foreach (Item resItem in resItems)
            {
                string className = "part ";

                if (resItem.Class == Settings.Instance.CadPart &&
                    resItem.IsTemplate == "0")
                {
                    Console.ForegroundColor = ConsoleColor.DarkBlue;
                }
                else if (resItem.Class == Settings.Instance.CadAssembly &&
                    resItem.IsTemplate == "0")
                {
                    className = "assem";
                    Console.ForegroundColor = ConsoleColor.DarkMagenta;
                }

                Console.WriteLine(className + ":  " + resItem.ItemNumber +
                                  "\t generation: " + resItem.Generation +
                                  "\t native_file: " + resItem.NativeFile +
                                   "\t lock: " + resItem.PwbIsCheckedOutBy +
                                   "\t desc: " + resItem.Description);

                if (resItem.Class == Settings.Instance.CadAssembly)
                {
                    foreach (Item child in resItem.Children)
                    {
                        string symbol = child.Class == Settings.Instance.CadAssembly ? "+" : "-";
                        Console.WriteLine("        " + symbol + " " + child.ItemNumber);
                    }
                }

                Console.ResetColor();

                if (level == DisplayLevel.Verbose)
                {
                    Console.WriteLine("OBID: " + resItem.OBID);

                    Console.WriteLine(resItem.ToXML("item").ToString());
                }
            }                        
        }

        /// <summary>
        /// Find And Delete
        /// </summary>
        /// <param name="itemNumber">the item id</param>
        private void FindAndDelete(string itemNumber)
        {
            List<Item> resItems = this.Find(itemNumber);

            if (itemNumber == "*")
            {
                Console.WriteLine("to remove: " + resItems.Count);
                foreach (Item resItem in resItems)
                {
                    Console.WriteLine("item: " + resItem.ItemNumber);
                }

                Console.WriteLine("press a key to remove, or Control+C to cancel");
                Console.Read();
            }

            Console.WriteLine("removing...");
            foreach (Item resItem in resItems)
            {
                Backend.Instance.DoDeleteItem(resItem);
            }

            resItems = this.Find(itemNumber);
            Console.WriteLine("remain: " + resItems.Count);
        }

        /// <summary>
        /// Just find
        /// </summary>
        /// <param name="itemNumber">the item id</param>
        /// <returns>the found items</returns>
        private List<Item> Find(string itemNumber)
        {
            List<Item> res = new List<Item>();

            // find assemblies
            Item assembly = new Item
            {
                ItemNumber = itemNumber,
                Class = Settings.Instance.CadAssembly,
                IsTemplate = "0"
            };

            List<Item> assemblies = Backend.Instance.DoFindItems(assembly);
            foreach (Item item in assemblies.ToList())
            {
                Item exp = this.Expand(item);

                assemblies.Remove(item);
                assemblies.Add(exp);
            }

            res.AddRange(assemblies);

            // other
            res.AddRange(this.FindItems(itemNumber, Settings.Instance.CadPart, "0"));
            res.AddRange(this.FindItems(itemNumber, Settings.Instance.CadDrawing, "0"));

            // templates
            // res.AddRange(this.FindItems(itemNumber, Settings.Instance.CadAssembly, "1"));
            // res.AddRange(this.FindItems(itemNumber, Settings.Instance.CadPart, "1"));
            // res.AddRange(this.FindItems(itemNumber, Settings.Instance.CadDrawing, "1"));
            return res;
        }

        /// <summary>
        /// Find certain items
        /// </summary>
        /// <param name="itemNumber">item number</param>
        /// <param name="className">item class</param>
        /// <param name="isTemplate">a flag</param>
        /// <returns>the found items</returns>
        private List<Item> FindItems(string itemNumber, string className, string isTemplate)
        {
            Item item = new Item
            {
                ItemNumber = itemNumber,
                Class = className,
                IsTemplate = isTemplate
            };

            return Backend.Instance.DoFindItems(item);
        }

        /// <summary>
        /// Expands an assembly
        /// </summary>
        /// <param name="assembly">an assembly root item</param>
        /// <returns>the expanded assembly</returns>
        private Item Expand(Item assembly)
        {
            try
            {
                assembly = Backend.Instance.DoExpand(assembly);
            }
            catch (ExceptionItemNotExpandable)
            {
            }

            return assembly;
        }

        /// <summary>
        /// A voluntary method
        /// </summary>
        private void Other()
        {
            Process[] processlist = Process.GetProcesses();

            foreach (Process theprocess in processlist)
            {
                Message.Log(theprocess.ProcessName + " " + theprocess);
            }
        }        
    }
}
