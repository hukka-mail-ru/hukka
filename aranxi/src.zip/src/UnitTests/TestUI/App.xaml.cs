// -----------------------------------------------------------------------
// <copyright file="App.xaml.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------
﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;

using TSI.PDM.BL;

namespace TestGUI
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
       //  BusinessLogic.Instance.Initialize();

       // Create 
    }
}
