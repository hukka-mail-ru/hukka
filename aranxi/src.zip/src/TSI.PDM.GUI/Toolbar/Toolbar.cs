// -----------------------------------------------------------------------
// <copyright file="Toolbar.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------
﻿namespace TSI.PDM.GUI
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using TSI.PDM.DataStore;
    using TSI.PDM.BL;

    public class Toolbar
    {

        #region singleton methods

        static readonly Toolbar instance = new Toolbar();
        
        /// <summary>
        /// Explicit static constructor to tell C# compiler not to mark type as beforefieldinit
        /// </summary>
        static Toolbar()
        {
            // Settings must be initialized very first, because all parts of the application use it!
            Settings.Instance.Initialize();

            Backend.Instance.Startup();
        }

        /// <summary>
        /// Sigleton instance getter
        /// </summary>
        public static Toolbar Instance
        {
            get
            {
                return instance;
            }
        }

        #endregion



        /// <summary>
        /// 
        /// </summary>
        public void ShowLoginWindow()
        {
            LoginWindow loginWindow = new LoginWindow();
            loginWindow.ShowInTaskbar = true;
            loginWindow.ShowDialog();
            loginWindow.Activate();
        }

        /// <summary>
        /// 
        /// </summary>
        public void ShowQueryWindow()
        {
            // create the window only if the first one is closed
            if (queryWindow == null || queryWindow.Opened == false)
            {
                queryWindow = new QueryWindow();
            }

            queryWindow.Show();
            queryWindow.Activate(); // set focus

            // test
     /*
            List<Item> responseItems = new List<Item>();
            Item item1  = new Item();// { item_number = "Item1", generation = "1", description = "desc1" };
            Item item2 = new Item();//{ item_number = "Item2", generation = "2", description = "desc2" };
            Item child = new Item();// { item_number = "Item3", generation = "3", description = "desc3" };
            item2.Children.Add(child);

            responseItems.Add(item1);
            responseItems.Add(item2);

            foreach (Item responseItem in responseItems)
            {
                responseItem.PDMAttributes.Add(new PDMAttribute { Name = "item_number", Value = "num" });
                responseItem.PDMAttributes.Add(new PDMAttribute { Name = "generation", Value = "gen" });
                responseItem.PDMAttributes.Add(new PDMAttribute { Name = "description", Value = "desc" });
            }

            child.PDMAttributes.Add(new PDMAttribute { Name = "item_number", Value = "num 2" });
            child.PDMAttributes.Add(new PDMAttribute { Name = "generation", Value = "gen 2" });
            child.PDMAttributes.Add(new PDMAttribute { Name = "description", Value = "desc 2" });

            queryWindow.OnSuccess(responseItems);
            */ 
        }

        /// <summary>
        /// 
        /// </summary>
        public void ShowCreateWindow()
        {
            CreateWindow createWindow = new CreateWindow();
            createWindow.ShowInTaskbar = true;
            createWindow.ShowDialog();
            createWindow.Activate();
        }

        /// <summary>
        /// Handle Update button
        /// </summary>
        public void ShowUpdateWindow(Item root, bool saved)
        {
            UpdateWindow window = new UpdateWindow(root, saved);
            window.ShowInTaskbar = true;
            window.ShowDialog();
            window.Activate();
        }

        /// <summary>
        /// Handle Lock or Unlock button
        /// </summary>
        /// <param name="itemName">name of item to lock</param>
        /// <param name="itemClass">class of item to lock</param>
        /// <param name="dolock">True if the lock is needed, false if unlock</param>
        public void OnLockUnlockButton(Item item, bool dolock)
        {
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor;

            Message.Log(item.ItemNumber + " " + item.Class);

            Backend.Instance.DoLockUnlock(item, dolock);

            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default;
        }

        /// <summary>
        /// 
        /// </summary>
        public void ShowAboutWindow()
        {
            AboutWindow aboutWindow = new AboutWindow();
            aboutWindow.ShowInTaskbar = true;
            aboutWindow.ShowDialog();
            aboutWindow.Activate();
        }

        /// <summary>
        /// 
        /// </summary>
        public void ShowResultWindow(List<Result> results)
        {
            ResultWindow window = new ResultWindow(results);
            window.ShowInTaskbar = true;
            window.ShowDialog();
            window.Activate();
        }

        
        // there should be only one instance of the window
        private QueryWindow queryWindow = null;
    }
}