// -----------------------------------------------------------------------
// <copyright file="RetrieveAssemblyInfo.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.GUI
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Linq;
    using System.Reflection;
    using System.Text;

    /// <summary>
    /// Class that represents AssemblyInfo
    /// </summary>
    public class RetrieveAssemblyInfo
    {
        /// <summary>
        /// Assembly of given type
        /// </summary>
        private static Assembly assembly;
        
        /// <summary>
        /// Initializes a new instance of the <see cref="RetrieveAssemblyInfo" /> class
        /// </summary>
        /// <param name="type">given type</param>
        public RetrieveAssemblyInfo(Type type)
        {
            assembly = Assembly.GetAssembly(type);
        }

        /// <summary>
        /// Gets title property
        /// </summary>
        public string Title
        {
            get
            {
                return this.CustomAttributes<AssemblyTitleAttribute>().Title;
            }
        }

        /// <summary>
        /// Gets description property
        /// </summary>
        public string Description
        {
            get
            {
                return this.CustomAttributes<AssemblyDescriptionAttribute>().Description;
            }
        }

        /// <summary>
        /// Gets company property
        /// </summary>
        public string Company
        {
            get
            {
                return this.CustomAttributes<AssemblyCompanyAttribute>().Company;
            }
        }

        /// <summary>
        /// Gets product property
        /// </summary>
        public string Product
        {
            get
            {
                return this.CustomAttributes<AssemblyProductAttribute>().Product;
            }
        }

        /// <summary>
        /// Gets copyright property
        /// </summary>
        public string Copyright
        {
            get
            {
                return this.CustomAttributes<AssemblyCopyrightAttribute>().Copyright;
            }
        }

        /// <summary>
        /// Gets trademark property
        /// </summary>
        public string Trademark
        {
            get
            {
                return this.CustomAttributes<AssemblyTrademarkAttribute>().Trademark;
            }
        }

        /// <summary>
        /// Gets AssemblyVersion property
        /// </summary>
        public string AssemblyVersion
        {
            get
            {
                return assembly.GetName().Version.ToString();
            }
        }

        /// <summary>
        /// Gets FileVersion property
        /// </summary>
        public string FileVersion
        {
            get
            {
                FileVersionInfo fileInfo = FileVersionInfo.GetVersionInfo(assembly.Location);
                return fileInfo.FileVersion;
            }
        }

        /// <summary>
        /// Returns custom attributes from AssemblyInfo.
        /// </summary>
        /// <typeparam name="T">given type</typeparam>
        /// <returns>custom attributes</returns>
        private T CustomAttributes<T>() where T : Attribute
        {
            object[] customAttributes = assembly.GetCustomAttributes(typeof(T), false);

            if ((customAttributes != null) && (customAttributes.Length > 0))
            {
                return (T)customAttributes[0];
            }

            throw new InvalidOperationException();
        }
    }
}
