// -----------------------------------------------------------------------
// <copyright file="UpdateWindow.xaml.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.GUI
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Data;
    using System.Windows.Documents;
    using System.Windows.Input;
    using System.Windows.Markup;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using System.Windows.Navigation;
    using System.Windows.Shapes;
    using System.Xml;

    using TSI.PDM.BL;
    using TSI.PDM.DataStore;

    /// <summary>
    /// UpdateWindow UI thread
    /// </summary>
    public partial class UpdateWindow : Window 
    {
        /// <summary>
        /// A collection which populates grid in the window
        /// </summary>
        private ObservableCollection<Item> itemsToShow =
               new ObservableCollection<Item>();

        /// <summary>
        /// A collection which populates grid in the window
        /// </summary>
        private ObservableCollection<Item> logsToShow =
               new ObservableCollection<Item>();

        /// <summary>
        /// A collection of structures to update on OK button
        /// </summary>
        private Item stuctureToUpdate;

        /// <summary>
        /// TODO:deprecated. to be deleted
        /// </summary>
        private bool saved;

        /// <summary>
        /// A number of operations to perform
        /// </summary>
        private int operationsToDo = 0;

        /// <summary>
        /// A number of operations to perform
        /// </summary>
        private int operationsDone = 0;

        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateWindow" /> class.
        /// </summary>
        /// <param name="root">structure to update</param>
        /// <param name="saved">was all the items saved or not</param>
        public UpdateWindow(Item root, bool saved)
        {
            Message.Log("UpdateWindow constructor");

            // Get an array of independent items
            List<Item> itemsInRoot = new List<Item>();
            Item.GetAllItems(root, itemsInRoot);

            foreach (Item item in itemsInRoot)
            {
                Message.Log(item.ItemNumber + " " + item.ItemModifyState + " " + item.ItemOperationState);

                if (item.ItemModifyState != Item.ModifyState.UpToDate)
                {
                    this.itemsToShow.Add(item);

                    if (item.ItemOperationState == Item.OperationState.Create ||
                        item.ItemOperationState == Item.OperationState.Update)
                    {
                        this.operationsToDo++;
                    }
                }
            }

            this.stuctureToUpdate = root;

            // ARANXI-92
            this.saved = saved;

            this.InitializeComponent();

            // if nothing to create/update
            if (this.operationsToDo == 0)
            {
                this.okButton.IsEnabled = false;
            }

            // Versioning is false by default
            Settings.Instance.Versioning = false;

            this.backgroundWorker = (BackgroundWorker)this.FindResource("backgroundWoker");
        }

        /// <summary>
        /// An event of INotifyPropertyChanged. Here it is fired, when the ItemCollection is changed,
        /// to notify the window and update its contents.
        /// </summary>        
        //// public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Gets a collection which populates grid in the window
        /// </summary>
        public ObservableCollection<Item> ItemCollection
        {
            get
            {
                return this.itemsToShow;
            }
        }

        /// <summary>
        /// Gets a collection which populates grid in the window
        /// </summary>
        public ObservableCollection<Item> LogsCollection
        {
            get
            {
                return this.logsToShow;
            }
        }

        /// <summary>
        /// A handler OnItemUpdate
        /// Must perform no operation with the UI!        
        /// </summary>
        /// <param name="item">the item</param>
        private void OnItemSynchronized(Item item)
        {
            // Just pass the result to the backgroundWorker
            this.backgroundWorker.ReportProgress(0, item);
        }

        /// <summary>
        ///  OK Click
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">Event Args</param>
        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            // Save before the update
            // ARANXI-92
            if (this.saved == false) 
            { 
                Backend.Instance.SaveBeforeUpdate(Settings.Instance.XmapDir); 
            }

            Message.Log("cleanup");

            this.MyProgressBar.Value = 0;
            this.MyProgressBar.Visibility = Visibility.Visible;

            // subscribe to Update Event of DoUpdate
            Backend.Instance.EventItemSynchronized +=
                new Backend.EventHandler(this.OnItemSynchronized);

            Message.Log("backgroundWorker.RunWorkerAsync");
            this.backgroundWorker.RunWorkerAsync();

            this.okButton.IsEnabled = false;
            this.cancelButton.IsEnabled = true;
        }

        /// <summary>
        ///  All operations completed      
        /// </summary>
        private void UpdateCompleted()
        {
            this.MyProgressBar.Visibility = Visibility.Hidden;

            this.okButton.IsEnabled = false;
            this.cancelButton.IsEnabled = false;

            // unsubscribe from  Update Event of DoUpdate
            Backend.Instance.EventItemSynchronized -=
                new Backend.EventHandler(this.OnItemSynchronized);
        }

        /// <summary>
        /// Cancel button event handler.
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">Routed Event Args</param>
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.backgroundWorker.CancelAsync();

            this.okButton.IsEnabled = false;
            this.cancelButton.IsEnabled = false;
        }

        /// <summary>
        /// Exit button event handler.
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">Routed Event Args</param>
        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            this.backgroundWorker.Dispose();
        }

        /// <summary>
        /// "Key pressed" event 
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">Routed Event Args</param>
        private void OnKeyDownHandler(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                this.OKButton_Click(sender, e);
            }
        }

        /// <summary>
        /// CheckBox Versioning changed
        /// </summary>
        /// <param name="sender">the sender</param>
        /// <param name="e">the args</param>
        private void OnCheckBoxVersioningChanged(object sender, RoutedEventArgs e)
        {
            Settings.Instance.Versioning = (bool)this.checkBoxVersioning.IsChecked;
        }
    }
}