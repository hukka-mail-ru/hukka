// -----------------------------------------------------------------------
// <copyright file="CreateWindow.xaml.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.GUI
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Data;
    using System.Windows.Documents;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using System.Windows.Navigation;
    using System.Windows.Shapes;
    using TSI.PDM.BL;
    using TSI.PDM.DataStore;

    /// <summary>
    /// Interaction logic for CreateWindow.xaml
    /// </summary>
    public partial class CreateWindow : Window
    {
        /// <summary>
        /// An array of form controls and their values
        /// </summary>
        private List<FormAttribute> formAttributes;

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateWindow" /> class.
        /// </summary>
        public CreateWindow()
        {
            this.InitializeComponent();

            ///////////////////////////////////////////////////
            // ItemTypeBox
            ///////////////////////////////////////////////////
            Common.LoadDataSourceToComboBox(Settings.Instance.ItemTypes, this.ItemTypeBox);
        }
     
        /// <summary>
        /// Cancel button event handler.
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">Event Args</param>
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// An event handler.
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">Event Args</param>
        private void ItemTypeBox_SelectionChanged(object sender, RoutedEventArgs e)
        {
            try
            {
                ///////////////////////////////////////////////////
                // TemplatesListBox:
                //
                // The list of templates is shown, 
                // when the create-form of the selected object-type contains 
                // a formattribute with the name-attribute “*Template” (‘*’ is meant as a wild-card) 
                // in the “Create”-form. 
                ///////////////////////////////////////////////////

                // show default item first, and select it
                this.TemplatesListBox.Items.Clear();
                int defaultItem = this.TemplatesListBox.Items.Add("default");
                this.TemplatesListBox.SelectedItem = this.TemplatesListBox.Items.GetItemAt(defaultItem);

                List<string> templateNames = Request.GetTemplateNames(
                                      this.ItemTypeBox.SelectedItem.ToString());
                if (templateNames.Count > 0)
                {
                    // get other templates from server:
                    Item item = new Item()
                    {
                        ItemNumber = "*",
                        Class = Request.GetNameByDisplayName(Settings.Instance.ItemTypes, this.ItemTypeBox.SelectedItem.ToString()),
                        IsTemplate = "1"
                    };

                    List<Item> responseItems = Backend.Instance.DoFindItems(item);

                    // add found items to TemplatesListBox
                    foreach (Item responseItem in responseItems)
                    {
                        this.TemplatesListBox.Items.Add(responseItem.ItemNumber);
                    }

                    this.TemplatesListBox.IsEnabled = true;
                }
                else
                {
                    this.TemplatesListBox.IsEnabled = false;
                }
 
                ///////////////////////////////////////////////////
                // Input fields
                ///////////////////////////////////////////////////

                // create a new grid
                Grid grid = new Grid();
                grid.Width = this.MainGrid.Width;
                grid.HorizontalAlignment = HorizontalAlignment.Left;
                grid.VerticalAlignment = VerticalAlignment.Top;

                grid.ColumnDefinitions.Add(new ColumnDefinition());
                
                // load a Labels and ComboBoxes from Settings
                this.formAttributes =
                    Request.GetFormAttributes("Register", this.ItemTypeBox.SelectedItem.ToString());
                int i = 0;
                foreach (var formAttribute in this.formAttributes)
                {
                    // a new row
                    grid.RowDefinitions.Add(new RowDefinition());

                    TextBlock txt = Common.CreateLabel(formAttribute, i, 0);                    
                    grid.Children.Add(txt);

                    i++;

                    // a new row
                    grid.RowDefinitions.Add(new RowDefinition());
                    Control control = Common.CreateControl(formAttribute, i, 0);
                    if (control != null)
                    {
                        control.Width = this.MainGrid.Width;
                        grid.Children.Add(control);
                        grid.Height += control.Height;                        
                    }

                    i++;
                }

                // add the created grid to form
                this.InputFieldsCell.Children.Clear();
                this.InputFieldsCell.Children.Add(grid);
            }
            catch (Exception ex)
            {
                Message.Show(ex);
            }
        }

        /// <summary>
        /// OK button event handler.
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">Event Args</param>
        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // retrieve values from controls
                Common.GetValuesOfControls(this.formAttributes);          
                
                // log
                /*
                foreach (FormAttribute a in formAttributes)
                {
                    Message.Log("FormAttribute: " + a.Name + " :  " + a.Value);
                }

                Message.Log("itemNumber " + itemNumber);
                */

                Request request = new Request();
                request.Attributes = this.formAttributes;

                // perform BL request
                string templateName = this.TemplatesListBox.SelectedItem.ToString();

                Item item = request.ToItem();
                item.Class = Request.GetNameByDisplayName(Settings.Instance.ItemTypes, this.ItemTypeBox.Text);

                Backend.Instance.DoCreateSingleFile(item, templateName, Settings.Instance.XmapDir, true);

                this.Close();
            }
            catch (Exception ex)
            {
                Message.Show(ex);
            }
        }

        /// <summary>
        /// "Key pressed" event 
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">Event Args</param>
        private void OnKeyDownHandler(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                this.OKButton_Click(sender, e);
            }
            else if (e.Key == Key.Escape)
            {
                // The other columns contain only textCancelButton_Click(sender, e);
            }
        }

        /// <summary>
        /// Enable OK button if all the required fields are filled
        /// </summary>
        /// 
        /*
        private void OnTextChanged(object sender, TextChangedEventArgs e)
        {
            bool buttonEnabled = true;

            foreach (FormAttribute a in formAttributes)
            {
                if (a.Value.Length == 0)
                {
                    buttonEnabled = false;
                }
            }

            okButton.IsEnabled = buttonEnabled;


        }
    */
    }
}
