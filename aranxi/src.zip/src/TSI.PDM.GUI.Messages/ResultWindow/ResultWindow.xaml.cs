﻿// -----------------------------------------------------------------------
// <copyright file="ResultWindow.xaml.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.GUI
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Linq;
    using System.Text;
    using System.Windows;
    using System.Windows.Input;

    /// <summary>
    /// Interaction logic for ResultWindow.xaml
    /// </summary>
    public partial class ResultWindow : Window
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ResultWindow" /> class.
        /// </summary>
        /// <param name="results">the list of results</param>
        public ResultWindow(List<Result> results)
        {
            this.Results = results;

            this.InitializeComponent();
        }

        /// <summary>
        /// Gets or sets a collection which populates grid in the window
        /// </summary>
        public List<Result> Results { get; set; }

        /// <summary>
        /// "Key pressed" event 
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">Event Args</param>
        private void OnKeyDownHandler(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return || e.Key == Key.Escape)
            {
                this.Close();
            }
        } 
        
        /// <summary> 
        ///  OK Click
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">Event Args</param>
        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
