﻿// -----------------------------------------------------------------------
// <copyright file="Result.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.GUI
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// Reparesents a result of an operation with an item (a model for ResultWindow)
    /// </summary>
    public class Result
    {
        /// <summary>
        /// Value of the result
        /// </summary>
        public enum ResultValue
        {
            /// <summary>
            /// OK value
            /// </summary>
            OK,

            /// <summary>
            /// Error value
            /// </summary>
            Error
        }

        /// <summary>
        /// Gets or sets ID of an item
        /// </summary>
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets Value of the result
        /// </summary>
        public ResultValue ResValue { get; set; }

        /// <summary>
        /// Gets or sets Description of the result
        /// </summary>
        public string Description { get; set; }
    }
}
