// -----------------------------------------------------------------------
// <copyright file="Relation.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.DataStore
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// A relation between two Items
    /// </summary>
    public class Relation
    {
        /// <summary>
        /// Gets or sets parent item name
        /// </summary>
        public string SourceId { get; set; } 

        /// <summary>
        /// Gets or sets child item name
        /// </summary>
        public string RelatedId { get; set; }

        /// <summary>
        /// Gets or sets class of left-related item (e.g. Part or Assembly)
        /// </summary>
        public string Class1 { get; set; }

        /// <summary>
        /// Gets or sets class of right-related item (e.g. Part or Assembly)
        /// </summary>
        public string Class2 { get; set; }

        /// <summary>
        /// Gets or sets class of the relation (e.g. /CAD Structure/Structure
        /// </summary>
        public string Class { get; set; }

        /// <summary>
        /// Gets or sets OBID of left-related file
        /// </summary>
        public string Left { get; set; }

        /// <summary>
        /// Gets or sets OBID of right-related file
        /// </summary>
        public string Right { get; set; }

        /// <summary>
        /// Gets or sets OBID of the Relation
        /// </summary>
        public string OBID { get; set; } 
    }
}
