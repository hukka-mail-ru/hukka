// -----------------------------------------------------------------------
// <copyright file="Item.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.DataStore
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.IO;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// Represents a CAD item as it it in PWBSchemaAras.xml
    /// It has properties with the same names as in PWBSchemaAras.xml
    /// </summary>
    public partial class Item
    {
        /// <summary>
        /// Children of assembly (An Item can have children if it is an Assembly)
        /// </summary>
        private readonly List<Item> children = new List<Item>();

        /// <summary>
        /// A flag indicating if the Item has a parent Item
        /// </summary>
        private bool hasParent = false;

        /// <summary>
        /// A field indicating the state of the item
        /// </summary>
        private ServerState itemServerState = ServerState.Unknown;

        /// <summary>
        /// A field indicatingthe state of the relation between this item and the parent item
        /// </summary>
        private ServerState relationServerState = ServerState.Unknown;

        /// <summary>
        /// State of the item on ARAS server
        /// </summary>
        public enum ServerState
        {
            /// <summary>
            /// State is unknown. Need to Query the item to define its state
            /// </summary>
            Unknown,

            /// <summary>
            /// Server has not such item
            /// </summary>
            New,

            /// <summary>
            /// Item exists on server
            /// </summary>
            Existing,

            /// <summary>
            /// Item exists on server and must be deleted
            /// </summary>
            ToDelete
        }

        /// <summary>
        /// Operation on ARAS server
        /// </summary>
        public enum OperationState
        {
            /// <summary>
            /// skip the item 
            /// </summary>
            Skip,

            /// <summary>
            /// Create the item 
            /// </summary>
            Create,

            /// <summary>
            /// Update the item 
            /// </summary>
            Update,

            /// <summary>
            /// Operation is completed
            /// </summary>
            Completed,

            /// <summary>
            /// An Error while performing the operation
            /// </summary>
            Error,

            /// <summary>
            /// Cancelled by user
            /// </summary>
            Cancelled
        }

        /// <summary>
        /// A status of a file: changed or up-to-date
        /// </summary> 
        public enum ModifyState
        {
            /// <summary>
            /// File is up-to-date (syncronized with server version)
            /// </summary> 
            UpToDate,

            /// <summary>
            /// File is changed locally
            /// </summary> 
            ChangedLocally,

            /// <summary>
            /// File is changed on server
            /// </summary> 
            ChangedOnServer
        }

         /// <summary>
         /// Gets or sets OBID of the file related to the Item (server File proprety)
         /// </summary>
         public string PwbFileObjectId { get; set; }

         /// <summary>
         /// Gets or sets ID of the user who locked the item (server File proprety)
         /// </summary>
         public string PwbIsCheckedOutBy { get; set; }

         /// <summary>
         /// Gets or sets a local dir with the NativeFile (server File proprety
         /// </summary>
         public string FolderName { get; set; }

         /// <summary>
         /// Gets or sets NodeType (server File proprety)
         /// </summary>
         public string NodeType { get; set; }

         /// <summary>
         /// Gets or sets PwbLinkTargetKeys (server File proprety)
         /// </summary>
         public string PwbLinkTargetKeys { get; set; }
                
         /// <summary>
         /// Gets or sets WorkspaceName (server File proprety)
         /// </summary>
         public string WorkspaceName { get; set; }

         /// <summary>
         /// Gets or sets parents of the item (UpdateWindow property)
         /// </summary>
         public string Structure { get; set; }

         /// <summary>
         /// Gets or sets a Operation (UpdateWindow property)
         /// </summary>
         public OperationState ItemOperationState { get; set; }

         /// <summary>
         /// Gets or sets a ModifyStatus 
         /// </summary>
         public ModifyState ItemModifyState { get; set; }
        
         /// <summary>
         /// Gets or sets a Result (UpdateWindow property)
         /// </summary>
         public string Result { get; set; }

         /// <summary>
         /// Gets or sets a value indicating whether the item selected in NX
         /// </summary>
         public bool Selected { get; set; }

         /// <summary>
         /// Gets or sets a value indicating whether the new version of item 
         /// is already created in the current sequence of Syncronize requests
         /// </summary>
         public bool NewVersionCreated { get; set; }

         /// <summary>
         /// Gets or sets a value indicating whether the item exists on ARAS server
         /// </summary>
         public ServerState ItemServerState 
         {
             get { return this.itemServerState; }
             set { this.itemServerState = value; }
         }

         /// <summary>
         /// Gets or sets a value indicating the server state of relation between this item and the parent item
         /// </summary>
         public ServerState RelationServerState
         {
             get { return this.relationServerState; }
             set { this.relationServerState = value; }
         }

         /// <summary>
         /// Gets or sets the relation between this item and the parent item
         /// </summary>
         public Relation RelationToParent { get; set; }

         /// <summary>
         /// Gets or sets the parent Item
         /// </summary>
         public Item Parent { get; set; }

         /// <summary>
         /// Gets children of assembly (An Item can have children if it is an Assembly)
         /// </summary>
         public List<Item> Children
         {
             get { return this.children; }
         }

         /// <summary>
         /// Gets or sets a value indicating whether the Item has a parent Item
         /// </summary>
         public bool HasParent
         {
             get { return this.hasParent; }
             set { this.hasParent = value; }
         }

         /// <summary>
         /// Get all  the items in the structure
         /// </summary>
         /// <param name="item">the root item</param>
         /// <param name="allItems">the result</param>
         public static void GetAllItems(Item item, List<Item> allItems)
         {
             bool found = false;
             foreach (Item i in allItems)
             {
                 if (i.ItemNumber == item.ItemNumber)
                 {
                     found = true;
                     break;
                 }
             }

             if (!found)
             {
                 allItems.Add(item);
             }

             // find each child recursively
             foreach (Item child in item.Children)
             {
                 GetAllItems(child, allItems);
             }
         }

         /// <summary>
         /// Gets a full name of a file, corresponding to an item
         /// </summary>
         /// <param name="dir">directory with the file</param>
         /// <returns>the full path</returns>
         public string GetFullLocalFileName(string dir)
         {
             return Path.Combine(dir, this.GetFileName());
         }

         /// <summary>
         /// Gets a full name of a file, corresponding to an item
         /// </summary>
         /// <returns>the full path</returns>
         public string GetFileName()
         {
             return this.ItemNumber + ".prt";
         }

        /// <summary>
        /// Gets a child of this item (if it exists)
        /// </summary>
         /// <param name="childName">child Name</param>
        /// <returns> the child</returns>
         public Item GetChild(string childName)
         {
             foreach (Item item in this.Children)
             {
                 if (item.ItemNumber == childName)
                 {
                     return item;
                 }
             }

             throw new MyException("Child '" + childName +
                 "' not found in assembly '" + this.ItemNumber + "'");
         }
    }
}
