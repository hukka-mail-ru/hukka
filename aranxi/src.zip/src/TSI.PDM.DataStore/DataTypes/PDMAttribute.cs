﻿// -----------------------------------------------------------------------
// <copyright file="PDMAttribute.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.DataStore
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// The PDM Attribute (A property of CAD Document in terms of Aras server)
    /// </summary>
    public class PDMAttribute
    {
        /// <summary>
        /// Gets or sets the name of attribute
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the value of attribute
        /// </summary>
        public string Value { get; set; }
    }
}
