﻿// -----------------------------------------------------------------------
// <copyright file="MetaDataXmlFile.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.DataStore
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Xml.Linq;

    using MetaDataKey = System.String;

    /// <summary>
    /// Represents DownloadedFiles.xml and UploadedFiles.xml
    /// </summary>
    public class MetaDataXmlFile
    {
        /// <summary>
        /// A map with the contents of DownloadedFiles.xml or UploadedFiles.xml
        /// </summary>
        private Dictionary<MetaDataKey, MetaDataEntry> dictionary = new Dictionary<MetaDataKey, MetaDataEntry>();

        /// <summary>
        /// The current file name (DownloadedFiles.xml or UploadedFiles.xml)
        /// </summary>
        private string metaDataXmlFileName;

        /// <summary>
        /// Initializes a new instance of the <see cref="MetaDataXmlFile" /> class
        /// </summary>
        /// <param name="metaFileName">the XML file name</param>
        public MetaDataXmlFile(string metaFileName)
        {
            Message.Log("MetaDataXmlFile " + metaFileName);

            this.metaDataXmlFileName = metaFileName;
        }

        /// <summary>
        /// Loads contents of the XML file
        /// </summary>
        public void Load()
        {
            try
            {
                Message.Log("Loading " + this.metaDataXmlFileName);
                this.dictionary.Clear();

                XDocument doc = XDocument.Load(this.metaDataXmlFileName);

                IEnumerable<XElement> elements = doc.Root.Descendants("file");

                foreach (XElement el in elements)
                {
                    MetaDataEntry metaData = new MetaDataEntry()
                    {
                        Name = el.Attribute("Name").Value,
                        LocalModificationTime = el.Attribute("LocalModificationTime").Value,
                        ServerModificationTime = el.Attribute("ServerModificationTime").Value
                    };

                    this.dictionary[metaData.Name] = metaData;
                }
            }
            catch (FileNotFoundException)
            {
            }
        }

        /// <summary>
        /// Saves contents of the XML file
        /// </summary>
        public void Save()
        {
            XDocument doc = new XDocument();
            XElement root = new XElement("files");
            doc.Add(root);

            foreach (KeyValuePair<MetaDataKey, MetaDataEntry> md in this.dictionary)
            {
                XElement el = new XElement("file",
                    new XAttribute("Name", md.Value.Name),
                    new XAttribute("LocalModificationTime", md.Value.LocalModificationTime),
                    new XAttribute("ServerModificationTime", md.Value.ServerModificationTime)
                );

                doc.Root.Add(el);
            }

            Message.Log("Saving " + this.metaDataXmlFileName);

            doc.Save(this.metaDataXmlFileName);
        }

        /// <summary>
        /// Get an entry of the XML file
        /// </summary>
        /// <param name="name">name of the entry</param>
        /// <returns>the entry</returns>
        public MetaDataEntry GetEntry(string name)
        {
            if (this.dictionary.ContainsKey(name))
            {
                return this.dictionary[name];
            }
            else
            {
                return new MetaDataEntry
                {
                    Name = name,
                    LocalModificationTime = "N/A",
                    ServerModificationTime = "N/A"
                };
            }
        }

        /// <summary>
        /// Adds or replaces an entry of the XML file
        /// </summary>
        /// <param name="metaDataEntry">the entry</param>
        public void AddEntry(MetaDataEntry metaDataEntry)
        {
            this.dictionary[metaDataEntry.Name] = metaDataEntry;
        }

        /// <summary>
        /// Check if a file modified locally
        /// </summary>  
        /// <param name="item">a file to check</param>
        /// <returns>
        /// A status of the file - was the file modified or not
        /// </returns>
        public bool IsModifiedLocally(Item item)
        {
            string name = item.GetFileName();
            string dir = Settings.Instance.XmapDir;

            MetaDataEntry metaDataEntry = this.GetEntry(name);

            // compare with file system timestamp
            return MetaDataEntry.GetCurrentLocalModificationTime(dir, name) != metaDataEntry.LocalModificationTime;
        }

        /// <summary>
        /// Check if a file modified on server
        /// </summary>  
        /// <param name="item">a file to check</param>
        /// <returns>
        /// A status of the file - was the file modified or not
        /// </returns>
        public bool IsModifiedOnServer(Item item)
        {
            string name = item.GetFileName();
            string dir = Settings.Instance.XmapDir;

            MetaDataEntry metaDataEntry = this.GetEntry(name);

            Message.Log("item.ModifiedOn != downloadedFile.ServerModificationTime: UpdateStatus.ChangedOnServer");

            return item.ModifiedOn != metaDataEntry.ServerModificationTime;
        }
    }
}
