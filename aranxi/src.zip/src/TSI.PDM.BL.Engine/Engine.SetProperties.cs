﻿// -----------------------------------------------------------------------
// <copyright file="Engine.SetProperties.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.BL
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Linq;
    using System.Text;

    using TSI.PDM.DataStore;

    /// <summary>
    /// Engine part - prepares the hierarchical structure
    /// for dispaying in UpdateWindow and uploading to the ARAS server
    /// </summary>
    public partial class Engine
    {
#if DEBUG_WITH_CHEAT
        /// <summary>
        /// Only for UnitTests: Sets private "saved" flag
        /// </summary>
        /// <param name="value">flag value</param>
        public static void SetSaved(bool value)
        {
            saved = value;
        }
#endif

        /// <summary>
        /// set properties to the Items in the hierarchical structure (root)
        /// </summary>
        /// <param name="localRoot">the root of the NX hierarchical structure</param>
        /// <param name="unsavedItems">unsaved Items</param>
        public static void SetProperties(
            Item localRoot,
            List<Item> unsavedItems)
        {
            // get all items
            List<Item> localItems = new List<Item>();
            Item.GetAllItems(localRoot, localItems);

            Message.Log("localItems ... " + localItems.Count);
            foreach (Item localItem in localItems)
            {
                Message.Log("localItem: " + localItem.ItemNumber);
            }

            Message.Log("unsavedItems ... " + unsavedItems.Count);
            foreach (Item unsavedItem in unsavedItems)
            {
                Message.Log("unsavedItem: " + unsavedItem.ItemNumber);
            }

            //////////////////////////////////////////
            // Set properties, coming from NX 
            //////////////////////////////////////////
            // set parent references and "selected" and "upload" flags
            SetParents(localRoot);
            SetStructureDescriptions(localRoot);

            // Set Selections And NeedToUpload (localItems);
            foreach (Item item in localItems)
            {
                item.Selected = true;
                item.NewVersionCreated = false; 
            }

            //////////////////////////////////////////
            // Check saved/unsaved
            //////////////////////////////////////////
            // get modification state for all the items            
            MetaDataXmlFile uploadedFilesXml = new MetaDataXmlFile(Settings.Instance.UploadedFilesXml);
            uploadedFilesXml.Load();
            foreach (Item item in localItems)
            {
                item.ItemModifyState = uploadedFilesXml.IsModifiedLocally(item) ?
                    Item.ModifyState.ChangedLocally :
                    Item.ModifyState.UpToDate;

                Message.Log("check timestamp: " + item.ItemNumber + " is " + item.ItemModifyState);
            }

            // mark all unsavedItems (in the Root) as ChangedLocally 
            foreach (Item unsavedItem in unsavedItems)
            {
                Item found = localItems.Find(i => i.ItemNumber == unsavedItem.ItemNumber);
                found.ItemModifyState = Item.ModifyState.ChangedLocally;

                Message.Log("check unsavedItems: " + found.ItemNumber + " is " + found.ItemModifyState);
            }

            // Select also parents of the selected Items. 
            foreach (Item item in localItems)
            {
                if (item.Selected && item.ItemModifyState != Item.ModifyState.UpToDate)
                {
                    SelectAllParents(item);
                }
            }

            //////////////////////////////////////////
            // Query server to define existsing, new and deleted items
            //////////////////////////////////////////
            Message.Log("Query server to define existsing, new and deleted items");
            QueryAssembly(localRoot);

            // set Skipped items
            foreach (Item item in localItems)
            {
                if (!item.Selected ||
                    item.ItemModifyState == Item.ModifyState.UpToDate ||
                    IsLockedByAnotherUser(item))
                {
                    item.ItemOperationState = Item.OperationState.Skip;
                }
            }

            // log
            foreach (Item item in localItems)
            {
                Message.LogHi("item " + item.ItemNumber +
                            ": " + item.ItemServerState +
                            "; rel=" + item.RelationServerState +
                            "; oper=" + item.ItemOperationState +
                            "; modif=" + item.ItemModifyState);
            }
        }

        /// <summary>
        /// Recursively query all subassemblies to define existsing, new and deleted items
        /// </summary>
        /// <param name="localAssembly">the root assembly</param>
        public static void QueryAssembly(Item localAssembly)
        {
            // repeat for each child recursively
            foreach (Item child in localAssembly.Children)
            {
                QueryAssembly(child);
            }

            Message.LogHi("QueryAssembly " + localAssembly.ItemNumber);

            // query the top item: does it exist or no?
            Backend.Instance.DoQueryItem(localAssembly);

            if (localAssembly.ItemServerState == Item.ServerState.Existing)
            {
                // the assembly exists - try expand it and check:
                // if any items was deleted locally by user 
                // (in this case we need to delete them on server also)
                try
                {
                    Item serverAssembly = Backend.Instance.DoExpand(localAssembly);

                    CompareLists(localAssembly.Children, serverAssembly.Children);
                }
                catch (ExceptionItemNotExpandable)
                {
                    // the assembly doesn't linked to any items on server - 
                    // but they may exist on server (test 07)
                    foreach (Item item in localAssembly.Children)
                    {
                        QueryItemAndSetNewRelation(item);
                    }
                }
            }
            else
            {
                // the assembly doesn't exist on server - 
                // but may be its children exist (test 09)
                foreach (Item item in localAssembly.Children)
                {
                    QueryItemAndSetNewRelation(item);
                }
            }

            Message.LogHi("QueryAssembly " + localAssembly.ItemNumber + " res .. Children: ");
            foreach (Item item in localAssembly.Children)
            {
                Message.Log(item.ItemNumber + " rel=" + item.RelationServerState);
            }
        }

        /// <summary>
        /// Query children one-by-one and mark their relation as new
        /// </summary>
        /// <param name="item">the item</param>
        private static void QueryItemAndSetNewRelation(Item item)
        {
            Backend.Instance.DoQueryItem(item);
            item.RelationServerState = Item.ServerState.New;
        }

        /// <summary>
        /// Compares two lists, finding new, existing and deleted items
        /// </summary>
        /// <param name="localItems">the local items list</param>
        /// <param name="serverItems">the server items list</param>
        private static void CompareLists(List<Item> localItems, List<Item> serverItems)
        {
            // item is Existing if exists in the same assembly
            foreach (Item localItem in localItems)
            {
                Item serverItem = serverItems.Find(i => i.ItemNumber == localItem.ItemNumber);

                if (serverItem != null)
                {
                    // item exists in this assembly on server
                    localItem.Copy(serverItem);

                    localItem.PwbIsCheckedOutBy = serverItem.PwbIsCheckedOutBy;
                    localItem.PwbFileObjectId = serverItem.PwbFileObjectId;

                    localItem.ItemServerState = Item.ServerState.Existing;
                    localItem.RelationServerState = Item.ServerState.Existing;
                    localItem.ItemOperationState = Item.OperationState.Update;
                }
                else
                {
                    // item doesn't exist in this assembly on server
                    QueryItemAndSetNewRelation(localItem);
                }
            }

            // mark deleted
            foreach (Item serverItem in serverItems)
            {
                Item localItem = localItems.Find(i => i.ItemNumber == serverItem.ItemNumber);

                if (localItem == null)
                {
                    Message.LogHi("Mark deleted: " + serverItem.ItemNumber);
                    serverItem.ItemServerState = Item.ServerState.Existing;
                    serverItem.RelationServerState = Item.ServerState.ToDelete;
                    localItems.Add(serverItem);
                }
            }

            /*
            foreach (Item localItem in localItems)
            {
                Message.LogHi(localItem.item_number + " Item: "
                    + localItem.ItemServerState + " Relation: " + localItem.RelationServerState);
            }*/
        }

        /// <summary>
        /// Define parents of items
        /// </summary>
        /// <param name="item">an item</param>
        private static void SetParents(Item item)
        {
            // find each child recursively
            foreach (Item child in item.Children)
            {
                SetParents(child);
            }

            // initially item has no parent
            item.Parent = null;
            item.HasParent = false;

            foreach (Item child in item.Children)
            {
                child.Parent = item;
                child.HasParent = true;
            }
        }

        /// <summary>
        /// recursively find and select all parents of an item
        /// </summary>
        /// <param name="item">the item</param>
        private static void SelectAllParents(Item item)
        {
            if (item.Parent != null)
            {
                item.Parent.Selected = true;
                item.Parent.ItemModifyState = Item.ModifyState.ChangedLocally;
                SelectAllParents(item.Parent);
            }
        }

        /// <summary>
        /// Checks if an item is locked by somebody, except the current user
        /// </summary>
        /// <param name="item">an item</param>
        /// <returns>true if locked</returns>
        private static bool IsLockedByAnotherUser(Item item)
        {
            return item.PwbIsCheckedOutBy != null &&
                   item.PwbIsCheckedOutBy.Length > 0 &&
                   item.PwbIsCheckedOutBy != Backend.Instance.GetUserName();
        }

        /// <summary>
        /// Define PDM structure of items
        /// </summary>
        /// <param name="item">an item</param>
        private static void SetStructureDescriptions(Item item)
        {
            if (item.Parent == null)
            {
                item.Structure = "/";
            }

            // find each child recursively
            foreach (Item child in item.Children)
            {
                if (item.Parent == null)
                {
                    child.Structure += "/" + item.ItemNumber;
                }
                else
                {
                    child.Structure += item.Structure + "/" + item.ItemNumber;
                }

                SetStructureDescriptions(child);
            }
        }
    }
}
