// -----------------------------------------------------------------------
// <copyright file="DataSource.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.DataStore
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Xml.Linq;
    
    /// <summary>
    /// Represents a DataSource as it is in PWBSchema_Aras.xml
    /// e.g.
    /// <dataSource name="LoginDatabases" type="ValueList">
    ///        <value name="InnovatorSolutions" displayName="" />
    ///        <value name="InnovatorSolutions930" displayName="" />
    ///    </dataSource>
    /// </summary>
    public class DataSource
    {
        /// <summary>
        /// The content of the data source
        /// </summary>
        private List<DataSourceEntry> entries = new List<DataSourceEntry>();

        /// <summary>
        /// Gets or sets the list contained in the data source
        /// </summary>
        public List<DataSourceEntry> Entries
        {
            get
            {
                return this.entries;
            }

            set
            {
                this.entries = value;
            }
        }
    }
}
