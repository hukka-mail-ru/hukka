﻿// -----------------------------------------------------------------------
// <copyright file="MetaDataEntry.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.DataStore
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// Represents an entry in DownloadedFiles.xml
    /// </summary> 
    public class MetaDataEntry
    {
        /// <summary>
        /// Gets or sets the entry name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets local modification timestamp
        /// </summary> 
        public string LocalModificationTime { get; set; }

        /// <summary>
        /// Gets or sets server modification timestamp
        /// </summary> 
        public string ServerModificationTime { get; set; }

        /// <summary>
        /// Get modification time of a file in the local file system
        /// </summary> 
        /// <param name="dir">location of the file</param>
        /// <param name="fileName">name of the file</param>
        /// <returns>
        /// A string containing the time
        /// </returns>
        public static string GetCurrentLocalModificationTime(string dir, string fileName)
        {
            // Message.Log("dir: " + dir);
            // Message.Log("fileName: " + fileName);
            FileInfo fi = new FileInfo(Path.Combine(dir, fileName));

            // Message.Log(string.Format("GetCurrentLocalModificationTime: {0:yyyy-MM-ddTHH-mm-ss}", fi.LastWriteTime));
            return string.Format("{0:yyyy-MM-ddTHH-mm-ss}", fi.LastWriteTime);
        }
    }
}
