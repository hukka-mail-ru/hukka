// -----------------------------------------------------------------------
// <copyright file="DataSourceEntry.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.DataStore
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// Represents an attribute as it it in PWBSchemaAras.xml (settings.xml)
    /// </summary>
    public class DataSourceEntry
    {
        /// <summary>
        /// Gets or sets name of the attribute
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets name of the attribute as it is displayed in UI
        /// </summary>
        public string DisplayName { get; set; }

        /// <summary>
        /// Gets or sets value of the attribute 
        /// </summary>
        public string BooleanValue { get; set; }
    }
}
