﻿// -----------------------------------------------------------------------
// <copyright file="MyException.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.DataStore
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// The base class for all the exceptions of our application
    /// </summary>
    public class MyException : System.Exception
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MyException" /> class.
        /// </summary>
        /// <param name="message">error message</param>
        public MyException(string message) :
            base(message) 
        { 
        }
    }

    /// <summary>
    /// Item Not Expandable
    /// </summary>
    public class ExceptionItemNotExpandable : MyException
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ExceptionItemNotExpandable" /> class.
        /// </summary>
        /// <param name="item">the item</param>
        public ExceptionItemNotExpandable(Item item) :
            base("Item '" + item.item_number + "' is not expandable") 
        { 
        }
    }

    /// <summary>
    /// ItemLockedBySomeoneElse
    /// </summary>
    public class ExceptionItemLockedBySomeoneElse : MyException
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ExceptionItemLockedBySomeoneElse" /> class.
        /// </summary>
        /// <param name="item">the item</param>
        public ExceptionItemLockedBySomeoneElse() :
            base( "Item is locked by someone else") 
        { 
        }
    }
    
    /// <summary>
    /// Server Error
    /// </summary>
    public class ExceptionServerError : MyException
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ExceptionServerError" /> class.
        /// </summary>
        /// <param name="message">the error message</param>
        public ExceptionServerError(string message) :
            base("Server response: " + message) 
        { 
        }
    }

    /// <summary>
    /// Client Error
    /// </summary>
    public class ExceptionClientError : MyException
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ExceptionClientError" /> class.
        /// </summary>
        /// <param name="message">the error message</param>
        public ExceptionClientError(string message) :
            base("Client response: " + message) 
        { 
        }
    }

    /// <summary>
    /// File Not Found
    /// </summary>
    public class ExceptionFileNotFound : MyException
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ExceptionFileNotFound" /> class.
        /// </summary>
        /// <param name="item">the file</param>
        /// <param name="dir">dir to search in</param>
        public ExceptionFileNotFound(Item item, string dir) :
            base("File " + item.GetFileName() + " not found in " + dir) 
        { 
        }
    }

    /// <summary>
    /// File already exists
    /// </summary>
    public class ExceptionFileAlreadyExists : MyException
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ExceptionFileAlreadyExists" /> class.
        /// </summary>
        public ExceptionFileAlreadyExists() : base("File already exists") { }
    }
}
