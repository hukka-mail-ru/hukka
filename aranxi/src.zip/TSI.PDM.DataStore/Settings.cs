// -----------------------------------------------------------------------
// <copyright file="Settings.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.DataStore
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Xml.Linq;

    /// <summary>
    /// Settings gives a access to the XML-file containing the settings of the Aras-NX-Integration 
    /// of the computer. The xml-file is placed in the same directory as the dll.
    /// </summary>
    /// <remarks>Implements a singleton-pattern as only one settings-file should by used.</remarks>
    public class Settings
    {
        /// <summary>
        /// Gets singleton instance
        /// </summary>
        private static Settings instance = new Settings();

        /// <summary>
        /// The main config. file
        /// </summary>
        private string settingsXml = "PWBSchema_Aras_NX.xml";

        /// <summary>
        /// DownloadedFiles.xml: a file which contais a list of downloaded files and their metadata
        /// </summary>
        private string downloadedFilesXml = "DownloadedFiles.xml";

        /// <summary>
        /// UploadedFiles.xml: a file which contais a list of uploaded files and their metadata
        /// </summary>
        private string uploadedFilesXml = "UploadedFiles.xml";

        /// <summary>
        /// Server path to Part
        /// </summary>
        private string cadPart = "/CAD/Mechanical/Part";

        /// <summary>
        /// Server path to Assembly
        /// </summary>
        private string cadAssembly = "/CAD/Mechanical/Assembly";

        /// <summary>
        /// Server path to Drawing
        /// </summary>
        private string cadDrawing = "/CAD/Mechanical/Drawing";

        /// <summary>
        /// Address of ARAS server
        /// </summary>
        private string server;

        /// <summary>
        /// USER_DIR/Startup directory
        /// </summary>
        private string startupDir;

        /// <summary>
        /// USER_DIR/Application directory
        /// </summary>
        private string applicationDir;

        /// <summary>
        /// USER_DIR/Config directory
        /// </summary>
        private string configDir;

        /// <summary>
        /// USER_DIR/Log directory
        /// </summary>
        private string logDir;

        /// <summary>
        /// USER_DIR/xmap directory
        /// </summary>
        private string xmapDir;

        /// <summary>
        /// USER_DIR/xmap/Debug directory
        /// </summary>
        private string debugDir;

        /// <summary>
        /// Databases existing on ARAS server
        /// </summary>
        private DataSource databases = new DataSource();

        /// <summary>
        /// E.g. CAD/Mecanical/Part, CAD/Mecanical/Assembly, CAD/Mecanical/Drawing
        /// </summary>
        private DataSource itemTypes = new DataSource();

        /// <summary>
        /// if true, Message.Show creates an NX window
        /// if false, Message.Show outputs to console
        /// </summary>
        private bool isConsoleOutput = false;

        /// <summary>
        /// enables/disables log mesages
        /// </summary>
        private bool enableLogging = true;

        /// <summary>
        /// Prevents a default instance of the <see cref="Settings" /> class from being created.
        /// </summary>
        private Settings()
        {
        }

        /// <summary>
        /// Gets sigleton instance 
        /// </summary>
        public static Settings Instance
        {
            get
            {
                return instance;
            }
        }

        /// <summary>
        /// Gets or sets the name of the main config. file
        /// </summary>
        public string SettingsXml
        {
            get
            {
                return this.settingsXml;
            }

            set
            {
                this.settingsXml = value;
            }
        }

        /// <summary>
        /// Gets or sets the name of a file which contais a list of downloaded files and their metadata
        /// </summary>
        public string DownloadedFilesXml
        {
            get
            {
                return this.downloadedFilesXml;
            }

            set
            {
                this.downloadedFilesXml = value;
            }
        }

        /// <summary>
        /// Gets or sets the name of a file which contais a list of uploaded files and their metadata
        /// </summary>
        public string UploadedFilesXml
        {
            get
            {
                return this.uploadedFilesXml;
            }

            set
            {
                this.uploadedFilesXml = value;
            }
        }

        /// <summary>
        /// Gets the server path to Cad Part
        /// </summary>
        public string CadPart
        {
            get
            {
                return this.cadPart;
            }
        }

        /// <summary>
        /// Gets the server path to Cad Assembly
        /// </summary>
        public string CadAssembly
        {
            get
            {
                return this.cadAssembly;
            }
        }

        /// <summary>
        /// Gets the server path to Cad Assembly
        /// </summary>
        public string CadDrawing
        {
            get
            {
                return this.cadDrawing;
            }
        }
       
        /// <summary>
        /// Gets the Aras Innovator Server defined in the settings-file.
        /// </summary>
        public string Server
        {
            get
            {
                return this.server;
            }
        }

        /// <summary>
        /// Gets USER_DIR/Application directory
        /// </summary>
        public string ApplicationDir
        {
            get
            {
                return this.applicationDir;
            }
        }

        /// <summary>
        /// Gets USER_DIR/Log directory
        /// </summary>
        public string LogDir
        {
            get
            {
                return this.logDir;
            }
        }

        /// <summary>
        /// Gets e.g. CAD/Mecanical/Part, CAD/Mecanical/Assembly, CAD/Mecanical/Drawing
        /// </summary>
        public DataSource ItemTypes
        {
            get
            {
                return this.itemTypes;
            }
        }

        /// <summary>
        /// Gets databases existing on ARAS server
        /// </summary>
        public DataSource Databases
        {
            get
            {
                return this.databases;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether UnitTest is being executed
        /// </summary>
        public bool UnitTest
        {
            get
            {
                return this.isConsoleOutput;
            }

            set
            {
                this.isConsoleOutput = value;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether log messages are enabled
        /// </summary>
        public bool EnableLogging
        {
            get
            {
                return this.enableLogging;
            }

            set
            {
                this.enableLogging = value;
            }
        }

        /// <summary>
        /// Gets the path of the XMAP to use. If the end of the path doesn´t contain the string "XMAP" a exception is thrown (that´Server important for the CleanStart of a session to avoid deletion of C:\...).
        /// </summary>
        public string XmapDir
        {
            get
            {
                return this.xmapDir;
            }
        }

        /// <summary>
        /// Gets the path of the XMAP to use. If the end of the path doesn´t contain the string "XMAP" a exception is thrown (that´Server important for the CleanStart of a session to avoid deletion of C:\...).
        /// </summary>
        public string DebugDir
        {
            get
            {
                return this.debugDir;
            }
        }
       
        /// <summary>
        /// Read all the settings from XML file
        /// </summary>
        public void Initialize()
        {
            string userDir = Environment.GetEnvironmentVariable("UGII_USER_DIR");

            this.startupDir = Path.Combine(userDir, "startup");
            this.applicationDir = Path.Combine(userDir, "application");
            this.configDir = Path.Combine(userDir, "config");
            this.logDir = Path.Combine(userDir, "log");
            this.xmapDir = Path.Combine(userDir, "xmap");
            this.debugDir = Path.Combine(userDir, "debug");

            this.SettingsXml = Path.Combine(this.configDir, this.SettingsXml);

            Message.Log("UGII_USER_DIR: " + userDir);
            Message.Log("Settings: " + this.SettingsXml);
            Message.Log("StartupDir: " + this.startupDir);
            Message.Log("ConfigDir: " + this.configDir);
            Message.Log("LogDir: " + this.logDir);
            Message.Log("DebugDir: " + this.debugDir);

            this.server = XML.GetAttribute(this.SettingsXml, "soapTargetUrl", "value");

            // Load all DataSources
            this.LoadDataSource(this.databases, "LoginDatabases");
            this.LoadDataSource(this.itemTypes, "ItemTypes");

            this.DownloadedFilesXml = Path.Combine(this.XmapDir, this.DownloadedFilesXml);
            this.UploadedFilesXml = Path.Combine(this.XmapDir, this.UploadedFilesXml);

            // Debug
            Message.Log("Server: " + this.Server);
            Message.Log("XmapDir: " + this.XmapDir);

            if (this.databases.Entries.Count == 0)
            {
                throw new MyException("No database defined in settings.xml");
            }

            if (this.Server == string.Empty)
            {
                throw new MyException("No server name defined in settings.xml");
            }
        }

        /// <summary>
        /// Loads the data source from file
        /// </summary>
        /// <param name="dataSource">DataSource object to fill</param>
        /// <param name="dataSourceName">DataSource name</param>
        private void LoadDataSource(DataSource dataSource, string dataSourceName)
        {
            dataSource.Entries.Clear();

            XElement root = XElement.Load(this.SettingsXml);

            // get the <dataSource name="dataSourceName">
            XElement ds = (from el in root.Descendants("dataSource")
                                    where (string)el.Attribute("name") == dataSourceName
                                    select el).First();

            // get all dataSourceEntries
            IEnumerable<XElement> entList =
                from el in ds.Descendants("value")
                select el;

            foreach (XElement el in entList)
            {
                DataSourceEntry entry = new DataSourceEntry();
                entry.Name = (string)el.Attribute("name");
                entry.DisplayName = (string)el.Attribute("displayName");
                entry.BooleanValue = (string)el.Attribute("booleanValue");

                dataSource.Entries.Add(entry);
            }
        }
    }
}
