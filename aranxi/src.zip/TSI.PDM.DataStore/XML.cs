// -----------------------------------------------------------------------
// <copyright file="XML.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace TSI.PDM.DataStore
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Xml;
    using System.Xml.Linq;

    /// <summary>
    /// This class contains common (context-independent) methods of read/write of XML files
    /// </summary>
    public class XML
    {
        /// <summary>
        /// Check if an element exist
        /// </summary>
        /// <param name="fileName">name of XML file, which contains the element</param>
        /// <returns>a name of the element</returns>
        public static string GetRootName(string fileName)
        {
            XElement root = XElement.Load(fileName);
            return root.Name.ToString();
        }

        /// <summary>
        /// Get the first element with the given name and return its value
        /// In the following example it return  "Logout from Aras Innovator successful."
        /// <message>Logout from Aras Innovator successful.</message>
        /// </summary>
        /// <param name="fileName">name of XML file, which contains the element</param>
        /// <param name="elementName">name the element</param>
        /// <returns>
        /// a value of the attribute
        /// </returns>
        public static string GetValue(string fileName, string elementName)
        {
            XElement root = XElement.Load(fileName);

            // get the first element. If it doesn't exist, throw an exception.
            XElement first = (from el in root.Descendants(elementName)
                                select el).First();

            return (string)first.Value;
        }

        /// <summary>
        /// Get the first element with the given name and return its attribute
        /// In the following example it return  "PwbArasSoapClient.exe"
        /// <soapClient value="PwbArasSoapClient.exe"/>
        /// </summary>
        /// <param name="fileName">name of XML file, which contains the element</param>
        /// <param name="elementName">name the element</param>
        /// <param name="attributeName">name the attribute</param>
        /// <returns>
        /// a name of the attribute
        /// </returns>
        public static string GetAttribute(string fileName, string elementName, string attributeName)
        {
            XElement root = XElement.Load(fileName);
 
            // get the first element. If it doesn't exist, throw an exception.
            XElement first = (from el in root.Descendants(elementName)
                                select el).First();

            return (string)first.Attribute(attributeName);           
        }
    }
}
