﻿// -----------------------------------------------------------------------
// <copyright file="UnitTests.Private.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;

    using TSI.PDM.DataStore;
    using TSI.PDM.BL;

    /// <summary>
    /// Private methods
    /// </summary>
    public partial class UnitTests
    {

        /// <summary>
        /// Create a new item on server
        /// </summary>
        /// <param name="item"></param>
        private void CreateItemOnServer(Item item)
        {
            // select it
            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(item);

            // cleanup and create files
            CreateFileLocally(item);
            
            CreateOrUpdateStructureOnServer(item, selectedItems);
        }

        /// <summary>
        /// Update an existing item on server
        /// TODO! make it like CreateItemOnServer
        /// </summary>
        /// <param name="item"></param>
        private Item UpdateItemOnServer(Item item)
        {
         //   item.NeedToUploadFile = true;
        //    item.ItemModifyState = Item.ModifyState.ChangedLocally;
         //   Item resItem = Backend.Instance.DoUpdateItem(item);

          //  Message.Log("Is item updated?");
         //   Check(resItem.item_number == item.item_number);

            return new Item();
        }


        /// <summary>
        /// Deletes an item on ARAS server if the item exists
        /// </summary>
        /// <param name="item">the item</param>
        private void DeleteItemOnServer(Item item)
        {
            Backend.Instance.DoQueryItem(item);
            if (item.ItemServerState == Item.ServerState.Existing)
            {
                Backend.Instance.DoDeleteItem(item);
            }
        }

        /// <summary>
        /// Deletes an file (corresponding to an item) locally
        /// </summary>
        /// <param name="item">the item</param>
        private void DeleteFileLocally(Item item)
        {
            string filename = item.GetFullLocalFileName(Settings.Instance.XmapDir);

            File.Delete(filename);

            Message.Log("Local file deleted: " + filename);
        }

        /// <summary>
        /// Create a file (corresponding to an item) locally
        /// </summary>
        /// <param name="item">the item</param>
        private void CreateFileLocally(Item item)
        {
            string filename = item.GetFullLocalFileName(Settings.Instance.XmapDir);

            System.IO.StreamWriter file = new System.IO.StreamWriter(filename);
            file.WriteLine("Initial");
            file.Close();

            Message.Log("Local file created: " + filename);
        }

        /// <summary>
        /// Copy a file (corresponding to an item) locally
        /// </summary>
        /// <param name="item">the item</param>
        private void CopyFileLocally(Item item, string srcDir)
        {
            string sourceFileName = item.GetFullLocalFileName(Path.Combine(Settings.Instance.XmapDir, srcDir));
            string destFileName = item.GetFullLocalFileName(Settings.Instance.XmapDir);

            Message.Log("Copy file: " + sourceFileName + " -> " + destFileName);

            File.Copy(sourceFileName, destFileName, true);
        }

        /// <summary>
        ///  Modify a file (corresponding to an item) locally
        /// </summary>
        /// <param name="item">the item</param>
        /// <param name="modification">the modification</param>
        private void ModifyFileLocally(Item item, string modification)
        {
            string filename = item.GetFullLocalFileName(Settings.Instance.XmapDir);

            System.IO.StreamWriter file = new System.IO.StreamWriter(filename);
            file.WriteLine(modification);
            file.Close();

            Message.Log("Local file modified: " + filename);
        }

        /// <summary>
        ///  Read a file (corresponding to an item) locally
        /// </summary>
        /// <param name="item">the item</param>
        private string ReadFileLocally(Item item)
        {
            string filename = item.GetFullLocalFileName(Settings.Instance.XmapDir);

            System.IO.StreamReader file = new System.IO.StreamReader(filename);
            string res = file.ReadLine();
            file.Close();

            Message.Log("Local file read: " + filename);
            Message.Log("Local file contents: " + res);

            return res;
        }

        /// <summary>
        /// Checks if a file (corresponding to an item) exists locally
        /// </summary>
        /// <param name="item">the item</param>
        private bool IsFileExistsLocally(Item item)
        {
            string filename = item.GetFullLocalFileName(Settings.Instance.XmapDir);

            Message.Log("Checking if file exists: " + filename);

            return File.Exists(filename);
        }

        /// <summary>
        /// Creates a simple item
        /// </summary>
        /// <returns></returns>
        private Item GetPart(string name)
        {
            Item item = new Item()
            {
                item_number = name,
                Class = Settings.Instance.CadPart
            };

            return item;
        }

        /// <summary>
        /// Cleanup and create item and its file
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private Item CreateItemAndFile(string name, string className)
        {
            Item item = new Item()
            {
                item_number = name,
                Class = className
            };

            // cleanup and create files
//            DeleteItemOnServer(item);
            //DeleteFileLocally(item);
            CreateFileLocally(item);

            return item;
        }

        /// <summary>
        /// Creates a simple Assembly
        /// </summary>
        /// <returns></returns>
        private Item GetAssembly(string name)
        {
            Item item = new Item()
            {
                item_number = name,
                Class = Settings.Instance.CadAssembly,
            };

            return item;
        }

        /// <summary>
        /// A debug method: show all the structure
        /// </summary>
        /// <param name="item">the root item</param>
        private static void ShowStructure(Item item)
        {
            Message.Log("item: " + item.item_number +
                        "; server state: " + item.ItemServerState.ToString() +
                        "; local state: " + item.RelationServerState.ToString() +
                        "; parent: " + (item.HasParent ? item.Parent.item_number : "NULL"));


            // find each child recursively
            foreach (Item child in item.Children)
            {
                ShowStructure(child);
            }
        }

        /// <summary>
        /// Upload structure to server
        /// </summary>
        /// <param name="root"></param>
        /// <param name="selectedItems"></param>
        private Item CreateOrUpdateStructureOnServer(Item root, List<Item> selectedItems)
        {
            // get independentItems and forgottenItems
            Engine.SetProperties(root, selectedItems);

            /*
            List<Item> allItems = new List<Item>();
            Item.GetAllItems(root, allItems);
            foreach (Item item in allItems)
            {
                Message.Log("item: " + item.item_number + "\t " +
                    item.Operation + "\t " + item.ItemModifyState);
            }*/

            // create or update items 
            return Backend.Instance.DoUpdateItem(root);
        }

        /// <summary>
        /// Log the test result 
        /// </summary>
        /// <param name="state">true if the test is OK</param>
        private void Check(bool state)
        {
            if (!state)
            {
                throw new MyException("TEST FAILED!");
            }
            else
            {
                Message.Log("TEST OK", ConsoleColor.DarkMagenta);
            }
        }

        /// <summary>
        /// Checks if two hierarchical structures are identical
        /// </summary>
        /// <param name="item">root of the first structure</param>
        /// <param name="correctItem">root of the second structure</param>
        private void CheckStructure(Item item, Item correctItem)
        {
            Message.Log(correctItem.item_number + " OK?");
            Check(item.item_number == correctItem.item_number);

            Message.Log(correctItem.item_number + ": Children number OK? " + item.Children.Count + " : " + correctItem.Children.Count);
            Check(item.Children.Count == correctItem.Children.Count);
            
            if (item.Children.Count > 0)
            {
                CheckArray(item.Children.ToList(), correctItem.Children.ToList(), "found");
            }

            // find all children recursively
            foreach (Item child in item.Children)
            {
                foreach (Item correctChild in correctItem.Children)
                {
                    if (correctChild.item_number == child.item_number)
                    {
                        CheckStructure(child, correctChild);
                    }
                }
            }
             
        }

        /// <summary>
        /// Checks if two arrays are identical
        /// </summary>
        /// <param name="items">the first array</param>
        /// <param name="correctItems">the second array</param>
        /// <param name="itemType">a text to display</param>
        private void CheckArray(List<Item> items, List<Item> correctItems, string itemType)
        {
            foreach (Item correctItem in correctItems)
            {
                foreach (Item item in items)
                {
                    if (correctItem.item_number == item.item_number)
                    {
                        correctItem.description = "FOUND";
                        break;
                    }
                }
            }

            foreach (Item correctItem in correctItems)
            {
                Message.Log("correct item " + correctItem.item_number);
            }

            Message.Log("items ");
            foreach (Item item in items)
            {
                Message.Log("item " + item.item_number);
            }


            Message.Log("items number is ok?");
            Check(items.Count == correctItems.Count);

            foreach (Item correctItem in correctItems)
            {
                Message.Log("item " + correctItem.item_number + " is " + itemType + "?");
                Check(correctItem.description == "FOUND");
            }
        }

        private void ShowTestHeaderAndCleanup(string name)
        {
            Message.Log("\n\n\n===  cleanup  " + name + " =====\n");

            // delete assemblies
            List<Item> assemblies = Backend.Instance.DoFindItems(new Item
            {
                item_number = "*",
                Class = Settings.Instance.CadAssembly,
                is_template = "0"
            });

            foreach (Item assembly in assemblies)
            {
                Backend.Instance.DoDeleteItem(assembly);
            }

            // delete parts
            List<Item> parts = Backend.Instance.DoFindItems(new Item
            {
                item_number = "*",
                Class = Settings.Instance.CadPart,
                is_template = "0"
            });

            foreach (Item part in parts)
            {
                Backend.Instance.DoDeleteItem(part);
            }

            // delete local prt files
            string[] files = Directory.GetFiles(Settings.Instance.XmapDir, "*.prt");
            foreach (string file in files)
            {
                File.Delete(file);
            }

            // delete local xml files
            files = Directory.GetFiles(Settings.Instance.XmapDir, "*.xml");
            foreach (string file in files)
            {
                File.Delete(file);
            }


            Message.Log("\n\n\n===== "  + name + " ==============\n");
        }

        /// <summary>
        /// Cleaunup and load structure
        /// </summary>
        /// <param name="root"></param>
        /// <param name="items"></param>
        private Item LoadStructure(Item root, List<Item> items)
        {

            // Load all
            Item responseItem = new Item();
            try
            {
                responseItem = Backend.Instance.DoExpand(root);
            }
            catch (ExceptionItemNotExpandable)
            {
                responseItem = root;
            }

            ShowStructure(responseItem);

            Backend.Instance.DoLoadStructure(responseItem, false);

            // all exist?
            foreach (Item item in items)
            {
                this.Check(this.IsFileExistsLocally(item));
            }

            return responseItem;
        }


        private Item CreateAssemblyWithChild(string assemblyName, string childName)
        {
            Message.Log("+++++++++++++++ " + assemblyName + " ++++++++++++++++");
            Item assembly = CreateItemAndFile(assemblyName, Settings.Instance.CadAssembly);
            Item item = CreateItemAndFile(childName, Settings.Instance.CadPart);

            assembly.Children.Add(item);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(assembly);
            selectedItems.Add(item);

            Message.Log("+++++++++++++++ create structure ++++++++++++++++");
            CreateOrUpdateStructureOnServer(assembly, selectedItems);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.generation);
            Backend.Instance.DoQueryItem(assembly);
            Message.Log("assembly.generation " + assembly.generation);

            return assembly;
        }
    }
}
