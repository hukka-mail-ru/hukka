// -----------------------------------------------------------------------
// <copyright file="TestQuery.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Reflection;

    using TSI.PDM.DataStore;
    using TSI.PDM.BL;


    partial class UnitTests
    {
        public void TestQuery_FindItems()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item itemA = this.GetPart("ItemA");
            DeleteItemOnServer(itemA);
            CreateItemOnServer(itemA);

            Item itemB = this.GetPart("ItemB");
            DeleteItemOnServer(itemB);
            CreateItemOnServer(itemB);

            Item match = new Item
            {
                item_number = "*",
                Class = Settings.Instance.CadPart
            };

            List<Item> items = Backend.Instance.DoFindItems(match);
            
            bool foundA = false;
            bool foundB = false;
            foreach(Item item in items)
            {
                if (item.item_number == itemA.item_number)
                {
                    foundA = true;
                }

                if (item.item_number == itemB.item_number)
                {
                    foundB = true;
                }
            }

            Check(foundA == true);
            Check(foundB == true);
        }


        public void TestQuery_Structure()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item item = this.GetPart("ItemA");

            Message.Log("Item number: " + item.item_number);
            Message.Log("Item id: " + item.id);

            DeleteItemOnServer(item);

            Message.Log("Item number: " + item.item_number);
            Message.Log("Item id: " + item.id);

            Backend.Instance.DoQueryItem(item);

            Message.Log("Item number: " + item.item_number);
            Message.Log("Item id: " + item.id);

            Message.Log("Item new?");
            Check(item.ItemServerState == Item.ServerState.New);

            CreateItemOnServer(item);

            Backend.Instance.DoQueryItem(item);
            Message.Log("Item exists?");
            Check(item.ItemServerState == Item.ServerState.Existing);

        }


        public void TestQuery_Item()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item item = this.GetPart("ItemA");
            DeleteItemOnServer(item);
            CreateItemOnServer(item);

            Backend.Instance.DoQueryItem(item);

            Message.Log("Item found?");
            Check(item.ItemServerState == Item.ServerState.Existing);
        }


        public void TestQuery_DeletedItem()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item item = this.GetPart("ItemA");
            DeleteItemOnServer(item);
            Backend.Instance.DoQueryItem(item);

            Message.Log("Item not found?");
            Check(item.ItemServerState != Item.ServerState.Existing);
        }    
    }
}
