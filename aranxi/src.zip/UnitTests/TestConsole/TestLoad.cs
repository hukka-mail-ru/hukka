// -----------------------------------------------------------------------
// <copyright file="TestLoadSingleFile.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Reflection;
    using System.Threading;

    using TSI.PDM.DataStore;
    using TSI.PDM.BL;


    partial class UnitTests
    {

        /// <summary>
        /// Query "DocumentNumber1" and then try load it        
        /// </summary>
        public void TestLoad_SingleFile()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item item = this.GetPart("ItemA");
            DeleteItemOnServer(item);
            this.CreateFileLocally(item);
            this.CreateItemOnServer(item);

            Backend.Instance.DoQueryItem(item);

            Message.Log("Item found?");
            Check(item.ItemServerState == Item.ServerState.Existing);

            Message.Log("\n\n------------> File must be downloaded if DownloadedFiles.Xml not exist");
            File.Delete(Settings.Instance.DownloadedFilesXml);
            Backend.DownloadStatus st = Backend.Instance.DoLoadSingleFile(item, false, false);
            Message.Log("File downloaded?");
            Check(st == Backend.DownloadStatus.Downloaded);

            Message.Log("\n\n------------> File must be downloaded if it doesn't exist ");
            DeleteFileLocally(item);
            st = Backend.Instance.DoLoadSingleFile(item, false, false);
            Message.Log("File downloaded?");
            Check(st == Backend.DownloadStatus.Downloaded);

            Message.Log("\n\n------------> File must NOT be downloaded if it's up to date ");
            st = Backend.Instance.DoLoadSingleFile(item, false, false);
            Message.Log("File not downloaded?");
            Check(st != Backend.DownloadStatus.Downloaded);

            Message.Log("\n\n------------> File must be downloaded if is modified locally ");
     
            Thread.Sleep(2000);
            ModifyFileLocally(item, "modifications");
            st = Backend.Instance.DoLoadSingleFile(item, false, false);
            Message.Log("File downloaded?");
            Check(st == Backend.DownloadStatus.Downloaded);

        }

        public void TestLoad_DeletedSingleFile()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item item = this.GetPart("ItemA");
            this.DeleteItemOnServer(item);
            this.DeleteFileLocally(item);

            try
            {
                Backend.DownloadStatus st = Backend.Instance.DoLoadSingleFile(item, false, false);
            }
            catch (Exception e)
            {
                Message.Log("TEST OK: EXCEPTION CATCHED: ");
                Message.Log(e);
                return;
            }

            Check(false);
        }
    }
}
