﻿// -----------------------------------------------------------------------
// <copyright file="TestExpand.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Reflection;
    using System.Threading;

    using TSI.PDM.DataStore;
    using TSI.PDM.BL;


    partial class UnitTests
    {
        public void TestExpandPart()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item itemA = CreateItemAndFile("ItemA", Settings.Instance.CadPart);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(itemA);
            
            Message.Log("+++++++++++++++ create structure ++++++++++++++++");
            CreateOrUpdateStructureOnServer(itemA, selectedItems);

            Backend.Instance.DoQueryItem(itemA);

            try
            {
                Item res = Backend.Instance.DoExpand(itemA);
                Check(false);
            }
            catch (ExceptionItemNotExpandable)
            {
                Check(true);
            }

        }

        public void TestExpandEmptyAssembly()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item assemblyA = CreateItemAndFile("ItemA", Settings.Instance.CadAssembly);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(assemblyA);

            Message.Log("+++++++++++++++ create structure ++++++++++++++++");
            CreateOrUpdateStructureOnServer(assemblyA, selectedItems);

            Backend.Instance.DoQueryItem(assemblyA);

            try
            {
                Item res = Backend.Instance.DoExpand(assemblyA);
                Check(false);
            }
            catch (ExceptionItemNotExpandable)
            {
                Check(true);
            }
        }

        public void TestExpandAssembly()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item assemblyA = CreateItemAndFile("AssemblyA", Settings.Instance.CadAssembly);
            Item itemA = CreateItemAndFile("ItemA", Settings.Instance.CadPart);

            assemblyA.Children.Add(itemA);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(itemA);
            selectedItems.Add(assemblyA);

            Message.Log("+++++++++++++++ create structure ++++++++++++++++");
            CreateOrUpdateStructureOnServer(assemblyA, selectedItems);

            Backend.Instance.DoQueryItem(assemblyA);

            Item res = Backend.Instance.DoExpand(assemblyA);

            Check(res != null);
        }

    }
}
