﻿// -----------------------------------------------------------------------
// <copyright file="TestAranxi33.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Reflection;

    using TSI.PDM.DataStore;
    using TSI.PDM.BL;


    partial class UnitTests
    {
        public void TestAranxi33_01_CreateFile()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);


            Item item = CreateItemAndFile("ItemA", Settings.Instance.CadPart);
            item.description = "Description";
            item.name = "ItemName";

            // Transmit the file to server
            Backend.Instance.DoCreateSingleFile(
                item, "default", Settings.Instance.XmapDir, false);

            // Test
            Item res = new Item { item_number = "ItemA", Class = Settings.Instance.CadPart };
            Backend.Instance.DoQueryItem(res);


            Check(res.name == "ItemName");
            Check(res.description == "Description");
            Check(res.native_file == item.GetFileName());

            Message.Log("Item is on server?");
            Check(res.ItemServerState == Item.ServerState.Existing);

            this.DeleteFileLocally(res);

            Backend.DownloadStatus st
                = Backend.Instance.DoLoadSingleFile(res, false, false);

            Message.Log("Item downloaded?");
            Check(st == Backend.DownloadStatus.Downloaded);

            Message.Log("File exists?");
            Check(this.IsFileExistsLocally(res) == true);
        }

        public void TestAranxi33_02_ChangeFile()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            // items
            Item item = this.GetPart("ItemA");
            Message.Log(item.generation);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(item);

            // cleanup and create files
            CreateFileLocally(item);

            Message.Log("--- create structure", ConsoleColor.DarkCyan);
            CreateOrUpdateStructureOnServer(item, selectedItems);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.generation);

            Message.Log("--- modify file", ConsoleColor.DarkCyan);
            string modification = "Modified file contents";
            ModifyFileLocally(item, modification);

            Message.Log("--- Update Structure", ConsoleColor.DarkCyan);
            CreateOrUpdateStructureOnServer(item, selectedItems);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.generation);

            
            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            DeleteFileLocally(item);

            Backend.DownloadStatus st
                = Backend.Instance.DoLoadSingleFile(item, false, false);

            Message.Log("Item downloaded?");
            Check(st == Backend.DownloadStatus.Downloaded);

            Message.Log("modified?");
            string content = this.ReadFileLocally(item);
            Check(content == modification);
  
        }
 
        public void TestAranxi33_03_UpdateOnlyModified()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            // let's user press SAVE
            Engine.SetSaved(true);

            Item item = this.GetPart("ItemA");

            // select it
            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(item);

            // cleanup and create files
            CreateFileLocally(item);


            Message.Log("\n\n+++++++++++++++ upload to server ++++++++++++++++\n");
            CreateOrUpdateStructureOnServer(item, selectedItems);

            Message.Log("\n\n+++++++++++++++ upload again ++++++++++++++++\n");
            Item resItem = CreateOrUpdateStructureOnServer(item, selectedItems);
            Check(resItem == null);

            // restore default contition
            Engine.SetSaved(false);
        }

        public void TestAranxi33_04_AddExistsingFileToNewAssembly()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- file", ConsoleColor.DarkCyan);
            Item item = CreateItemAndFile("ItemA", Settings.Instance.CadPart);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(item);


            Message.Log("--- create structure", ConsoleColor.DarkCyan);
            CreateOrUpdateStructureOnServer(item, selectedItems);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.generation);

            Message.Log("--- assembly", ConsoleColor.DarkCyan);
            Item assembly = CreateItemAndFile("AssemblyA", Settings.Instance.CadAssembly);

            assembly.Children.Add(item);

            selectedItems.Clear();
            selectedItems.Add(assembly);
            selectedItems.Add(item);

            Message.Log("--- update structure", ConsoleColor.DarkCyan);
            CreateOrUpdateStructureOnServer(assembly, selectedItems);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.generation);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            foreach (Item i in selectedItems)
            {
                DeleteFileLocally(i);
            }
            Item res = LoadStructure(assembly, selectedItems);

            CheckStructure(res, assembly);
        }

        public void TestAranxi33_05_AddNewFileToNewAssembly()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- file", ConsoleColor.DarkCyan);
            Item item = CreateItemAndFile("ItemA", Settings.Instance.CadPart);

            Message.Log("--- assembly", ConsoleColor.DarkCyan);
            Item assembly = CreateItemAndFile("AssemblyA", Settings.Instance.CadAssembly);

            assembly.Children.Add(item);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(assembly);
            selectedItems.Add(item);

            Message.Log("--- update structure", ConsoleColor.DarkCyan);
            CreateOrUpdateStructureOnServer(assembly, selectedItems);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.generation);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            foreach (Item i in selectedItems)
            {
                DeleteFileLocally(i);
            }
            Item res = LoadStructure(assembly, selectedItems);

            CheckStructure(res, assembly);
        }

        public void TestAranxi33_06_AddExistingFileToExistingAssembly()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- file", ConsoleColor.DarkCyan);
            Item item = CreateItemAndFile("ItemA", Settings.Instance.CadPart);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(item);

            Message.Log("--- create structure (file)", ConsoleColor.DarkCyan);
            CreateOrUpdateStructureOnServer(item, selectedItems);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.generation);


            Message.Log("--- assembly", ConsoleColor.DarkCyan);
            Item assembly = CreateItemAndFile("AssemblyA", Settings.Instance.CadAssembly);

            selectedItems.Clear();
            selectedItems.Add(assembly);

            Message.Log("--- create structure (assembly)", ConsoleColor.DarkCyan);
            CreateOrUpdateStructureOnServer(assembly, selectedItems);
            Backend.Instance.DoQueryItem(assembly);
            Message.Log("item.generation " + assembly.generation);


            Message.Log("--- add item as child", ConsoleColor.DarkCyan);
            assembly.Children.Add(item);
            ModifyFileLocally(assembly, "file modified because child is added");

            selectedItems.Clear();
            selectedItems.Add(assembly);
            selectedItems.Add(item);

            Message.Log("--- update structure", ConsoleColor.DarkCyan);
            CreateOrUpdateStructureOnServer(assembly, selectedItems);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.generation);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            foreach (Item i in selectedItems)
            {
                DeleteFileLocally(i);
            }
            Item res = LoadStructure(assembly, selectedItems);

            CheckStructure(res, assembly);
        }

        public void TestAranxi33_06a_AddExistingFileToExistingAssembly()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- file", ConsoleColor.DarkCyan);
            Item item = CreateItemAndFile("ItemA_06a", Settings.Instance.CadPart);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(item);

            Message.Log("--- create structure (file)", ConsoleColor.DarkCyan);
            CreateOrUpdateStructureOnServer(item, selectedItems);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.generation);


            Message.Log("--- assembly", ConsoleColor.DarkCyan);
            Item root = CreateItemAndFile("Root_06a", Settings.Instance.CadAssembly);
            Item assembly = CreateItemAndFile("AssemblyA_06a", Settings.Instance.CadAssembly);

            root.Children.Add(assembly);

            selectedItems.Clear();
            selectedItems.Add(root);
            selectedItems.Add(assembly);

            Message.Log("--- create structure (assembly)", ConsoleColor.DarkCyan);
            CreateOrUpdateStructureOnServer(root, selectedItems);


            Message.Log("--- add item as child", ConsoleColor.DarkCyan);
            assembly.Children.Add(item);
            ModifyFileLocally(assembly, "file modified because child is added");

            selectedItems.Clear();
            selectedItems.Add(root);
            selectedItems.Add(assembly);
            selectedItems.Add(item);

            Message.Log("--- update structure", ConsoleColor.DarkCyan);
            CreateOrUpdateStructureOnServer(root, selectedItems);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            foreach (Item i in selectedItems)
            {
                DeleteFileLocally(i);
            }
            Item res = LoadStructure(root, selectedItems);

            CheckStructure(res, root);
        }

        public void TestAranxi33_07_AddNewFileToExistingAssembly()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- assembly", ConsoleColor.DarkCyan);
            Item assembly = CreateItemAndFile("AssemblyA_07", Settings.Instance.CadAssembly);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Clear();
            selectedItems.Add(assembly);

            Message.Log("--- create structure (assembly)", ConsoleColor.DarkCyan);
            CreateOrUpdateStructureOnServer(assembly, selectedItems);
            Backend.Instance.DoQueryItem(assembly);
            Message.Log("item.generation " + assembly.generation);

            Message.Log("--- file", ConsoleColor.DarkCyan);
            Item item = CreateItemAndFile("ItemA_07", Settings.Instance.CadPart);

            Message.Log("--- add item as child", ConsoleColor.DarkCyan);
            assembly.Children.Add(item);
            ModifyFileLocally(assembly, "file modified because child is added");

            selectedItems.Clear();
            selectedItems.Add(assembly);
            selectedItems.Add(item);

            Message.Log("--- update structure", ConsoleColor.DarkCyan);
            CreateOrUpdateStructureOnServer(assembly, selectedItems);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.generation);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            foreach (Item i in selectedItems)
            {
                DeleteFileLocally(i);
            }
            Item res = LoadStructure(assembly, selectedItems);

            CheckStructure(res, assembly);
        }

        public void TestAranxi33_07a_AddNewFileToExistingAssembly()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- create assembly", ConsoleColor.DarkCyan);
            Item root = CreateItemAndFile("Root_07a", Settings.Instance.CadAssembly);
            Item assembly = CreateItemAndFile("AssemblyA_07a", Settings.Instance.CadAssembly);

            root.Children.Add(assembly);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Clear();
            selectedItems.Add(root);
            selectedItems.Add(assembly);

            CreateOrUpdateStructureOnServer(assembly, selectedItems);
            Backend.Instance.DoQueryItem(assembly);
            Message.Log("item.generation " + assembly.generation);

            Message.Log("--- file", ConsoleColor.DarkCyan);
            Item item = CreateItemAndFile("ItemA_07a", Settings.Instance.CadPart);

            Message.Log("--- add item as child", ConsoleColor.DarkCyan);
            assembly.Children.Add(item);
            ModifyFileLocally(assembly, "file modified because child is added");

            selectedItems.Clear();
            selectedItems.Add(root);
            selectedItems.Add(assembly);
            selectedItems.Add(item);

            Message.Log("--- update structure", ConsoleColor.DarkCyan);
            CreateOrUpdateStructureOnServer(root, selectedItems);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.generation);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            foreach (Item i in selectedItems)
            {
                DeleteFileLocally(i);
            }
            Item res = LoadStructure(root, selectedItems);

            CheckStructure(res, root);
        }
         
        public void TestAranxi33_08_DeleteFileFromExistingAssembly()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- assembly", ConsoleColor.DarkCyan);
            Item assembly = CreateItemAndFile("AssemblyA", Settings.Instance.CadAssembly);

            Message.Log("--- file", ConsoleColor.DarkCyan);
            Item item = CreateItemAndFile("ItemA", Settings.Instance.CadPart);

            assembly.Children.Add(item);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(assembly);
            selectedItems.Add(item);

            Message.Log("--- create structure", ConsoleColor.DarkCyan);
            CreateOrUpdateStructureOnServer(assembly, selectedItems);
            Backend.Instance.DoQueryItem(item);
            Message.Log("item.generation " + item.generation);
            Backend.Instance.DoQueryItem(assembly);
            Message.Log("assembly.generation " + assembly.generation);

            Message.Log("--- remove file", ConsoleColor.DarkCyan);
            assembly.Children.Remove(item);
            Check(assembly.Children.Count == 0);
            ModifyFileLocally(assembly, "modified contents");

            Message.Log("--- update structure", ConsoleColor.DarkCyan);
            selectedItems.Clear();
            selectedItems.Add(assembly);
            CreateOrUpdateStructureOnServer(assembly, selectedItems);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            foreach (Item i in selectedItems)
            {
                DeleteFileLocally(i);
            }
            Item res = LoadStructure(assembly, selectedItems);

            CheckStructure(res, assembly);
        }

        public void TestAranxi33_08a_DeleteFileFromExistingAssembly()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- assembly", ConsoleColor.DarkCyan);
            Item root = CreateItemAndFile("Root_08a", Settings.Instance.CadAssembly);
            Item assembly = CreateItemAndFile("Assembly_08a", Settings.Instance.CadAssembly);

            Message.Log("--- file", ConsoleColor.DarkCyan);
            Item item = CreateItemAndFile("Item_08a", Settings.Instance.CadPart);

            root.Children.Add(assembly);
            assembly.Children.Add(item);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(root);
            selectedItems.Add(assembly);
            selectedItems.Add(item);

            Message.Log("--- create structure", ConsoleColor.DarkCyan);
            CreateOrUpdateStructureOnServer(assembly, selectedItems);


            Message.Log("--- remove file", ConsoleColor.DarkCyan);
            assembly.Children.Remove(item);
            Check(assembly.Children.Count == 0);
            ModifyFileLocally(assembly, "modified contents");

            Message.Log("--- update structure", ConsoleColor.DarkCyan);
            selectedItems.Clear();
            selectedItems.Add(root);
            selectedItems.Add(assembly);
            CreateOrUpdateStructureOnServer(root, selectedItems);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            foreach (Item i in selectedItems)
            {
                DeleteFileLocally(i);
            }
            Item res = LoadStructure(root, selectedItems);

            CheckStructure(res, root);
        }

        public void TestAranxi33_09_AddExistsingAssemblyToExistingAssembly()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);


            Message.Log("--- create structure A", ConsoleColor.DarkCyan);
            Item assemblyA = CreateItemAndFile("AssemblyA", Settings.Instance.CadAssembly);
            Item itemA = CreateItemAndFile("ItemA", Settings.Instance.CadPart);

            assemblyA.Children.Add(itemA);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(assemblyA);
            selectedItems.Add(itemA);

            CreateOrUpdateStructureOnServer(assemblyA, selectedItems);

            Message.Log("--- create structure B", ConsoleColor.DarkCyan);
            Item assemblyB = CreateItemAndFile("AssemblyB", Settings.Instance.CadAssembly);
            Item itemB = CreateItemAndFile("ItemB", Settings.Instance.CadPart);

            assemblyB.Children.Add(itemB);

            selectedItems = new List<Item>();
            selectedItems.Add(assemblyB);
            selectedItems.Add(itemB);

            CreateOrUpdateStructureOnServer(assemblyB, selectedItems);



            Message.Log("--- add B to A", ConsoleColor.DarkCyan);
            assemblyA.Children.Add(assemblyB);
            ModifyFileLocally(assemblyA, "modified file");
            ModifyFileLocally(assemblyB, "modified file");

            selectedItems = new List<Item>();
            selectedItems.Add(assemblyA);
            selectedItems.Add(assemblyB);
            selectedItems.Add(itemB);


            CreateOrUpdateStructureOnServer(assemblyA, selectedItems);


            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            Item res = LoadStructure(assemblyA, selectedItems);

            Message.Log("--- res", ConsoleColor.DarkCyan);
            CheckStructure(res, assemblyA);
        }

        public void TestAranxi33_09a_AddExistsingAssemblyToExistingAssembly()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- create structure A", ConsoleColor.DarkCyan);
            Item root = CreateItemAndFile("Root_09a", Settings.Instance.CadAssembly);
            Item assemblyA = CreateItemAndFile("AssemblyA_09a", Settings.Instance.CadAssembly);
            Item itemA = CreateItemAndFile("ItemA_09a", Settings.Instance.CadPart);

            root.Children.Add(assemblyA);
            assemblyA.Children.Add(itemA);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(root);
            selectedItems.Add(assemblyA);
            selectedItems.Add(itemA);

            CreateOrUpdateStructureOnServer(root, selectedItems);

            Message.Log("--- create structure B", ConsoleColor.DarkCyan);
            Item assemblyB = CreateItemAndFile("AssemblyB_09a", Settings.Instance.CadAssembly);
            Item itemB = CreateItemAndFile("ItemB_09a", Settings.Instance.CadPart);

            assemblyB.Children.Add(itemB);

            selectedItems = new List<Item>();
            selectedItems.Add(assemblyB);
            selectedItems.Add(itemB);

            CreateOrUpdateStructureOnServer(assemblyB, selectedItems);


            Message.Log("--- add B to A", ConsoleColor.DarkCyan);
            assemblyA.Children.Add(assemblyB);
            ModifyFileLocally(assemblyA, "modified file");
            ModifyFileLocally(assemblyB, "modified file");

            selectedItems = new List<Item>();
            selectedItems.Add(root);
            selectedItems.Add(assemblyA);
            selectedItems.Add(assemblyB);
            selectedItems.Add(itemB);

            CreateOrUpdateStructureOnServer(root, selectedItems);


            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            Item res = LoadStructure(root, selectedItems);

            Message.Log("--- Check result", ConsoleColor.DarkCyan);
            CheckStructure(res, root);
        }

        public void TestAranxi33_10_AddNewAssemblyToExistingAssembly()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);


            Item assemblyA = CreateItemAndFile("AssemblyA", Settings.Instance.CadAssembly);
            Item itemA = CreateItemAndFile("ItemA", Settings.Instance.CadPart);

            assemblyA.Children.Add(itemA);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(assemblyA);
            selectedItems.Add(itemA);

            Message.Log("--- create structure", ConsoleColor.DarkCyan);
            CreateOrUpdateStructureOnServer(assemblyA, selectedItems);
            Backend.Instance.DoQueryItem(itemA);
            Message.Log("item.generation " + itemA.generation);
            Backend.Instance.DoQueryItem(assemblyA);
            Message.Log("assembly.generation " + assemblyA.generation);


            Message.Log("--- AssemblyB", ConsoleColor.DarkCyan);
    
            Item assemblyB = CreateItemAndFile("AssemblyB", Settings.Instance.CadAssembly);
            Item itemB = CreateItemAndFile("ItemB", Settings.Instance.CadPart);

            assemblyB.Children.Add(itemB);



            assemblyA.Children.Add(assemblyB);
            ModifyFileLocally(assemblyA, "modified file");

            selectedItems = new List<Item>();
            selectedItems.Add(assemblyA);
            selectedItems.Add(assemblyB);
            selectedItems.Add(itemB);


            Message.Log("--- create structure", ConsoleColor.DarkCyan);
            CreateOrUpdateStructureOnServer(assemblyA, selectedItems);


            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            Item res = LoadStructure(assemblyA, selectedItems);

            Message.Log("--- res", ConsoleColor.DarkCyan);
            CheckStructure(res, assemblyA);
        }

        public void TestAranxi33_10a_AddNewAssemblyToExistingAssembly()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item root = CreateItemAndFile("Root_10a", Settings.Instance.CadAssembly);
            Item assemblyA = CreateItemAndFile("AssemblyA_10a", Settings.Instance.CadAssembly);
            Item itemA = CreateItemAndFile("ItemA_10a", Settings.Instance.CadPart);

            root.Children.Add(assemblyA);
            assemblyA.Children.Add(itemA);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(root);
            selectedItems.Add(assemblyA);
            selectedItems.Add(itemA);

            Message.Log("--- create structure", ConsoleColor.DarkCyan);
            CreateOrUpdateStructureOnServer(root, selectedItems);


            Message.Log("--- AssemblyB", ConsoleColor.DarkCyan);

            Item assemblyB = CreateItemAndFile("AssemblyB_10a", Settings.Instance.CadAssembly);
            Item itemB = CreateItemAndFile("ItemB_10a", Settings.Instance.CadPart);

            assemblyB.Children.Add(itemB);



            assemblyA.Children.Add(assemblyB);
            ModifyFileLocally(assemblyA, "modified file");

            selectedItems = new List<Item>();
            selectedItems.Add(root);
            selectedItems.Add(assemblyA);
            selectedItems.Add(assemblyB);
            selectedItems.Add(itemB);


            Message.Log("--- create structure", ConsoleColor.DarkCyan);
            CreateOrUpdateStructureOnServer(root, selectedItems);


            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            Item res = LoadStructure(root, selectedItems);

            Message.Log("--- res", ConsoleColor.DarkCyan);
            CheckStructure(res, root);
        }

        public void TestAranxi33_11_DeleteAssemblyFromExistingAssembly()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);


            Message.Log("--- create structure A", ConsoleColor.DarkCyan);
            Item assemblyA = CreateItemAndFile("AssemblyA", Settings.Instance.CadAssembly);
            Item itemA = CreateItemAndFile("ItemA", Settings.Instance.CadPart);            

            Message.Log("--- create structure B", ConsoleColor.DarkCyan);
            Item assemblyB = CreateItemAndFile("AssemblyB", Settings.Instance.CadAssembly);
            Item itemB = CreateItemAndFile("ItemB", Settings.Instance.CadPart);

            assemblyB.Children.Add(itemB);

            assemblyA.Children.Add(itemA);
            assemblyA.Children.Add(assemblyB);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(assemblyA);
            selectedItems.Add(itemA);
            selectedItems.Add(assemblyB);
            selectedItems.Add(itemB);

            CreateOrUpdateStructureOnServer(assemblyA, selectedItems);

            Message.Log("--- delete structure B", ConsoleColor.DarkCyan);
            assemblyA.Children.Remove(assemblyB);
            selectedItems.Clear();
            selectedItems.Add(assemblyA);
            selectedItems.Add(itemA);         

            CreateOrUpdateStructureOnServer(assemblyA, selectedItems);

            
            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            foreach (Item i in selectedItems)
            {
                DeleteFileLocally(i);
            }
            Item loadRes = LoadStructure(assemblyA, selectedItems);

            // recreate assemblyA, because it was deformed by Engine.SetProperties
            assemblyA.Children.Clear();
            assemblyA.Children.Add(itemA);


            CheckStructure(loadRes, assemblyA);
             
        }

        public void TestAranxi33_11a_DeleteAssemblyFromExistingAssembly()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);


            Message.Log("--- create structure A", ConsoleColor.DarkCyan);
            Item root = CreateItemAndFile("Root_11a", Settings.Instance.CadAssembly);
            Item assemblyA = CreateItemAndFile("AssemblyA_11a", Settings.Instance.CadAssembly);
            Item itemA = CreateItemAndFile("ItemA_11a", Settings.Instance.CadPart);

            Message.Log("--- create structure B", ConsoleColor.DarkCyan);
            Item assemblyB = CreateItemAndFile("AssemblyB_11a", Settings.Instance.CadAssembly);
            Item itemB = CreateItemAndFile("ItemB_11a", Settings.Instance.CadPart);

            assemblyB.Children.Add(itemB);

            assemblyA.Children.Add(itemA);
            assemblyA.Children.Add(assemblyB);
            root.Children.Add(assemblyA);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(root);
            selectedItems.Add(assemblyA);
            selectedItems.Add(itemA);
            selectedItems.Add(assemblyB);
            selectedItems.Add(itemB);

            CreateOrUpdateStructureOnServer(root, selectedItems);

            Message.Log("--- delete structure B", ConsoleColor.DarkCyan);
            assemblyA.Children.Remove(assemblyB);
            selectedItems.Clear();
            selectedItems.Add(root);
            selectedItems.Add(assemblyA);
            selectedItems.Add(itemA);

            CreateOrUpdateStructureOnServer(root, selectedItems);


            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            foreach (Item i in selectedItems)
            {
                DeleteFileLocally(i);
            }
            Item loadRes = LoadStructure(root, selectedItems);

            // recreate assemblyA, because it was deformed by Engine.SetProperties
            assemblyA.Children.Clear();
            assemblyA.Children.Add(itemA);


            CheckStructure(loadRes, root);

        }

        public void TestAranxi33_13_ChangeItemWhichIsUsedTwice()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);


            Item assembly = CreateItemAndFile("AssemblyA", Settings.Instance.CadAssembly);
            Item itemA = CreateItemAndFile("ItemA", Settings.Instance.CadPart);
            Item itemB = CreateItemAndFile("ItemA", Settings.Instance.CadPart);
            Item itemC = CreateItemAndFile("ItemA", Settings.Instance.CadPart);

            assembly.Children.Add(itemA);
            assembly.Children.Add(itemB);
            assembly.Children.Add(itemC);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(assembly);
            selectedItems.Add(itemA);
            selectedItems.Add(itemB);
            selectedItems.Add(itemC);

            Message.Log("--- create structure", ConsoleColor.DarkCyan);
            CreateOrUpdateStructureOnServer(assembly, selectedItems);
            Backend.Instance.DoQueryItem(itemA);
            Message.Log("item.generation " + itemA.generation);
            Backend.Instance.DoQueryItem(itemB);
            Message.Log("item.generation " + itemA.generation);
            Backend.Instance.DoQueryItem(itemC);
            Message.Log("item.generation " + itemA.generation);
            Backend.Instance.DoQueryItem(assembly);
            Message.Log("assembly.generation " + assembly.generation);


            ModifyFileLocally(assembly, "modified file");
            ModifyFileLocally(itemB, "modified file");

           // assembly.NeedToUploadFile = true; - we need to add it in Engine.SelectAllParents
            selectedItems.Clear();
            selectedItems.Add(itemB);

            Message.Log("--- create structure", ConsoleColor.DarkCyan);
            CreateOrUpdateStructureOnServer(assembly, selectedItems);


            DeleteFileLocally(itemB);

            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            Item res = LoadStructure(assembly, selectedItems);

            Message.Log("--- res", ConsoleColor.DarkCyan);

            Message.Log("modified?");
            string content = this.ReadFileLocally(itemB);
            Check(content == "modified file");
        }

        public void TestAranxi33_14_DeleteThenRestore()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Message.Log("--- create ", ConsoleColor.DarkCyan);
            Item assembly = CreateItemAndFile("AssemblyA", Settings.Instance.CadAssembly);
            Item item = CreateItemAndFile("ItemA", Settings.Instance.CadPart);

            assembly.Children.Add(item);

            List<Item> selectedItems = new List<Item>();
            selectedItems.Add(assembly);
            selectedItems.Add(item);

            CreateOrUpdateStructureOnServer(assembly, selectedItems);

            Message.Log("--- delete", ConsoleColor.DarkCyan);
            assembly.Children.Remove(item);
            Check(assembly.Children.Count == 0);
            selectedItems.Clear();
            selectedItems.Add(assembly);
            CreateOrUpdateStructureOnServer(assembly, selectedItems);


            Message.Log("--- restore", ConsoleColor.DarkCyan);
            assembly.Children.Clear();
            assembly.Children.Add(item);
            selectedItems.Clear();
            selectedItems.Add(assembly);
            CreateOrUpdateStructureOnServer(assembly, selectedItems);
            
            Message.Log("--- Reload Structure", ConsoleColor.DarkCyan);
            foreach (Item i in selectedItems)
            {
                DeleteFileLocally(i);
            }
            Item res = LoadStructure(assembly, selectedItems);

            CheckStructure(res, assembly);
        }
    }
}
