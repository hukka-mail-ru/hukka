// -----------------------------------------------------------------------
// <copyright file="TestLockUnlock.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Reflection;

    using TSI.PDM.DataStore;
    using TSI.PDM.BL;


    partial class UnitTests
    {
        public void TestLock_LockItem()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item item = this.GetPart("ItemA");
            CreateItemOnServer(item);

            Backend.Instance.DoLockUnlock(item, true);            
            Backend.Instance.DoQueryItem(item);

            Message.Log("Item locked?");
            Check(item.PwbIsCheckedOutBy == "admin");
        }

        public void TestLock_LockAssembly()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item item = this.GetAssembly("AssemblyA");
            CreateItemOnServer(item);

            Backend.Instance.DoLockUnlock(item, true);
            Backend.Instance.DoQueryItem(item);

            Message.Log("Item locked?");
            Check(item.PwbIsCheckedOutBy == "admin");
        }


        public void TestLock_UnlockItem()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item item = this.GetPart("ItemA");
            CreateItemOnServer(item);

            Backend.Instance.DoLockUnlock(item, false);
            Backend.Instance.DoQueryItem(item);

            Message.Log("Item unlocked?");
            Check(item.PwbIsCheckedOutBy == null);
        }

        public void TestLock_DeletedItem()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Item item = this.GetPart("ItemA");

            try
            {
                Backend.Instance.DoLockUnlock(item, true);
            }
            catch (Exception)
            {
                Message.Log("EXCEPTION CATCHED: TEST OK");
                return;
            }

            Check(false);
        }
    }
}
