﻿// -----------------------------------------------------------------------
// <copyright file="UnitTests.Events.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using TSI.PDM.DataStore;
    using TSI.PDM.BL;

    /// <summary>
    /// Event-catching methods
    /// </summary>
    public partial class UnitTests
    {
        public class SynchronizedEvents
        {
            public List<Item> SynchronizedItems       
            {
                get
                {
                    return this.synchronizedItems;
                }
            }

            public void Subscribe()
            {
                // subscribe to Event
                Backend.Instance.EventItemSynchronized +=
                        new Backend.EventHandler(this.OnItemSynchronized);

                synchronizedItems.Clear();
            }

            public void Unsubscribe()
            {
                // unsubscribe from Event
                Backend.Instance.EventItemSynchronized -=
                        new Backend.EventHandler(this.OnItemSynchronized);
            }

            private void OnItemSynchronized(Item item)
            {
                Message.Log("EVENT: " + item.ItemOperationState +
                    " item: " + item.item_number + " ... OK!", ConsoleColor.Blue);

                synchronizedItems.Add(item);
            }

            private List<Item> synchronizedItems = new List<Item>();
        }
    }
}
