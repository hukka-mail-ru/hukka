﻿// -----------------------------------------------------------------------
// <copyright file="TestLicense.cs" company="">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

namespace UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using System.Text;
    using TSI.PDM.BL;

    /// <summary>
    /// TestLicense
    /// </summary>
    partial class UnitTests
    {
        public void TestLicense()
        {
            ShowTestHeaderAndCleanup(MethodBase.GetCurrentMethod().Name);

            Engine.CheckLicense();
        }
    }
}
