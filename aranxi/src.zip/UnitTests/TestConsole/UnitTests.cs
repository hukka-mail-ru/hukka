// -----------------------------------------------------------------------
// <copyright file="UnitTests.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

namespace UnitTests
{
    using System;
    using System.IO;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Diagnostics;
    using System.Xml.Linq;
    using System.Reflection;

    using TSI.PDM.DataStore;
    using TSI.PDM.BL;
    using TSI.PDM.GUI;

/*
  _____                  ____            _______ _______     _________     __  _ 
 / ____|   /\      /\   |  _ \   /\     |__   __|  __ \ \   / /  __ \ \   / / | |
| |       /  \    /  \  | |_) | /  \       | |  | |__) \ \_/ /| |  | \ \_/ /  | |
| |      / /\ \  / /\ \ |  _ < / /\ \      | |  |  ___/ \   / | |  | |\   /   | |
| |____ / /  \ \/ ____ \| |_) / ____ \     | |  | |     _| |  | |__| |_| |    |_|
 \_____/_/    \/_/    \_\____/_/    \_\    |_|  |_|    |___|  |_____/|___|    (_)

*/

    /// <summary>
    /// This class contains all the unit tests
    /// </summary>
    partial class UnitTests
    {
        /// <summary>
        /// Main function
        /// </summary>
        /// <param name="args"></param>
        public static void Main(string[] args)
        {
            UnitTests unitTests = new UnitTests();

            Settings.Instance.UnitTest = true;

            try
            {
                if (args.Length == 0)
                {
                    // Run all tests
                    unitTests.Startup();

                    List<string> methods = unitTests.GetMethodsWhichContain("Test");
                    foreach (string method in methods)
                    {
                        unitTests.InvokeMethod(method);
                    }

                    unitTests.Shutdown();
                }
                else
                {
                    string command = args[0];

                    // Show all tests
                    if (command == "-h" || command == "--help")
                    {
                        List<string> methods = unitTests.GetMethodsWhichContain("Test");
                        foreach (string method in methods)
                        {
                            Console.WriteLine(method);
                        }
                    }
                    else
                    {
                        // Run only one a test
                        unitTests.Startup();

                        List<string> methods = unitTests.GetMethodsWhichContain(args[0]);
                        foreach (string method in methods)
                        {
                            unitTests.InvokeMethod(method);
                        }

                        unitTests.Shutdown();
                    }
                }
            }
            catch (Exception e)
            {
                Message.Log(e);
                Backend.Instance.DoLogout();
            }
        }


        /// <summary>
        /// Startup
        /// </summary>
        private void Startup()
        {
            Message.ClearScreen();

            // Settings must be initialized very first, because all parts of the application use it!
            Settings.Instance.Initialize();

            Backend.Instance.Startup();

            Credentials cred = new Credentials("admin", "innovator",
                                Settings.Instance.Databases.Entries[0].Name);

            Backend.Instance.DoLogin(cred);

            // cleanup Debug dir.
            string[] files = Directory.GetFiles(Settings.Instance.DebugDir, "*.*");
            foreach (string file in files)
            {
                File.Delete(file);
            }
        }

        /// <summary>
        /// Shutdown
        /// </summary>
        private void Shutdown()
        {
            Backend.Instance.DoLogout();
        }

        /// <summary>
        /// invoke method of the class by its name
        /// </summary>
        /// <param name="name"></param>
        private void InvokeMethod(string name)
        {
            try
            {
                MethodInfo mi = typeof(UnitTests).GetMethod(name, new Type[0]);
                mi.Invoke(this, new object[0]);
            }
            catch (TargetInvocationException tie)
            {
                Message.Log(tie.InnerException);
                throw tie.InnerException;
            }
        }

        /// <summary>
        /// Gets methods in the class
        /// </summary>
        /// <param name="item"></param>
        private List<string> GetMethodsWhichContain(string partOfName)
        {
            MethodInfo[] mis = typeof(UnitTests).GetMethods();
            List<string> methods = new List<string>();
           
            foreach (MethodInfo mi in mis)
            {
                if (mi.Name.Contains(partOfName))
                {
                    methods.Add(mi.Name);
                }
            }

            methods.Sort();

            return methods;
        }
 

    }
}
