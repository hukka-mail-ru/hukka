// -----------------------------------------------------------------------
// <copyright file="MainWindow.xaml.cs" company="T-Systems International GmbH">
//    Copyright © T-Systems 2012
// </copyright>
// -----------------------------------------------------------------------

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using TSI.PDM.GUI;
using TSI.PDM.BL;
using TSI.PDM.DataStore;

/*
 ____  ___  ___  ____     __  _  _  __    ──▒▒▒▒▒────▒▒▒▒▒────▄████▄─────
(_  _)(  _)/ __)(_  _)   / _)( )( )(  )   ─▒─▄▒─▄▒──▒─▄▒─▄▒──███▄█▀──────
  )(   ) _)\__ \  )(    ( (/\ )()(  )(    ─▒▒▒▒▒▒▒──▒▒▒▒▒▒▒─▐████──█──█──
 (__) (___)(___/ (__)    \__/ \__/ (__)   ─▒▒▒▒▒▒▒──▒▒▒▒▒▒▒──█████▄──────
                                          ─▒─▒─▒─▒──▒─▒─▒─▒───▀████▀─────
*/

namespace TestGUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
           
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
         //   BusinessLogic.Instance.Initialize();
            Toolbar.Instance.ShowLoginWindow();
        }

        private void QueryButton_Click(object sender, RoutedEventArgs e)
        {
            Toolbar.Instance.ShowQueryWindow();
        }

        private void CreateButton_Click(object sender, RoutedEventArgs e)
        {
            Toolbar.Instance.ShowCreateWindow();
        }


        private void AboutButton_Click(object sender, RoutedEventArgs e)
        {
            Toolbar.Instance.ShowAboutWindow();
        }

        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {

            List<Item> items = new List<Item>();


                Item item = new Item
                {
                    native_file = "D:\\Bullshit\\XMAP\\One.prt",
                    Structure = "PdmStructure PdmStructure PdmStructure PdmStructure",
                    locked_by_id = "admin",
                    ItemServerState = Item.ServerState.New,
                    ItemOperationState = Item.OperationState.Update,
                    Result = "Unknown"
                };


            UpdateWindow window = new UpdateWindow(item, false);


            window.ShowDialog();
            window.Activate();

            
        }
    }
}
