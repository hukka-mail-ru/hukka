# Usage : perl file [filename.h]

# (1) quit unless we have the correct number of command-line args
use File::Basename;


$num_args = $#ARGV + 1;



$flag = 0;

my @intact = ();
my @contents = ();



my $name = basename( $ARGV[0] );

$i = 0;
while ($line = <>) # read a file
{ 
    # namespace starts
    if($line =~ m/^.*(namespace|using).*/)
    {
       $flag = 1;
    }
	
    if( $flag )
    {
	    @contents[$i] = $line;
    }
 
    @intact [$i]  = $line;

    $i++;
}

if( $flag )
{

   print "// -----------------------------------------------------------------------\n";
   print "// <copyright file=\"$name\" company=\"T-Systems International GmbH\">\n";
   print "//    Copyright \xc2\xa9 T-Systems 2012\n";
   print "// </copyright>\n";
   print "// -----------------------------------------------------------------------\n\n";

   print @contents;
}
else
{
   print @intact ;
}





